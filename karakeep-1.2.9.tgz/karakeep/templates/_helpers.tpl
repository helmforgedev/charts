{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{- define "karakeep.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "karakeep.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "karakeep.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "karakeep.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "karakeep.labels" -}}
helm.sh/chart: {{ include "karakeep.chart" . }}
{{ include "karakeep.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "karakeep.selectorLabels" -}}
app.kubernetes.io/name: {{ include "karakeep.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "karakeep.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "karakeep.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "karakeep.image" -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}

{{/* Data PVC claim name */}}
{{- define "karakeep.dataClaimName" -}}
{{- if .Values.persistence.existingClaim -}}
{{- .Values.persistence.existingClaim -}}
{{- else -}}
{{- printf "%s-data" (include "karakeep.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/* Secret name */}}
{{- define "karakeep.secretName" -}}
{{- if .Values.karakeep.existingSecret -}}
{{- .Values.karakeep.existingSecret -}}
{{- else -}}
{{- printf "%s-secret" (include "karakeep.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Generate NEXTAUTH_SECRET: lookup existing secret or generate a new one.
This ensures the value is preserved across upgrades.
*/}}
{{- define "karakeep.nextAuthSecret" -}}
{{- $key := .Values.karakeep.existingSecretNextAuthKey | default "nextauth-secret" -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace (include "karakeep.secretName" .) -}}
{{- if and $existing $existing.data (index $existing.data $key) -}}
{{- index $existing.data $key | b64dec -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}

{{/*
Generate MEILI_MASTER_KEY: lookup existing secret or generate a new one.
*/}}
{{- define "karakeep.meiliMasterKey" -}}
{{- $key := .Values.karakeep.existingSecretMeiliMasterKey | default "meili-master-key" -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace (include "karakeep.secretName" .) -}}
{{- if and $existing $existing.data (index $existing.data $key) -}}
{{- index $existing.data $key | b64dec -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}
{{/* Validate cross-field configuration before rendering workloads. */}}
{{- define "karakeep.validate" -}}
{{- if and .Values.externalSecrets.enabled (not .Values.karakeep.existingSecret) -}}
{{- fail "externalSecrets.enabled requires karakeep.existingSecret to be set to prevent credential drift between the chart-managed Secret and the ExternalSecret." -}}
{{- end -}}
{{- end -}}
