# Filesystem Backup

Enable `nodeAgent.enabled=true` when you need filesystem backup for pod volumes.

## What this chart does

When enabled, the chart deploys the Velero node-agent as a DaemonSet and wires
the host paths required for pod volume access. With the default Kopia uploader,
both the server and node-agent also receive ephemeral writable volumes at
`/home/cnb/udmrepo` and `/home/cnb/.cache`. This preserves the read-only root
filesystem while allowing Kopia to store configuration and cache data.

The DaemonSet is named `node-agent` and its pods always include the
`role: node-agent` label expected by Velero. These compatibility identifiers
are fixed and cannot be changed through release naming or `nodeAgent.podLabels`.

## What to validate

- your cluster policy allows the node-agent hostPath mounts
- your storage and workload patterns are compatible with filesystem backup
- the object storage location is already healthy before enabling schedules
- the node-agent pods reach `Ready` on the intended nodes

## Recommended first validation

1. install Velero with a working `BackupStorageLocation`
2. enable `nodeAgent`
3. create one controlled backup that uses filesystem backup
4. inspect backup status before enabling recurring schedules
