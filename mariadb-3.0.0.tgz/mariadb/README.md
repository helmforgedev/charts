# MariaDB Helm Chart

[![Artifact Hub](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/helmforge)](https://artifacthub.io/packages/search?repo=helmforge)

Helm chart for deploying [MariaDB](https://mariadb.org/) on Kubernetes using the official [`mariadb`](https://hub.docker.com/_/mariadb) Docker image. Supports standalone and GTID-based replication architectures.

## Breaking Change in 3.0.0

Replica bootstrap now fails closed when a non-empty logical replica datadir has
neither HelmForge bootstrap state nor MariaDB replication metadata. Healthy
existing replicas are detected and continue normally. A trusted bootstrap that
was interrupted on an older chart can be resumed once with
`replication.readReplicas.bootstrap.resumeUnmarkedDatadir: true`; unknown PVCs
must not use this escape hatch.

The new opt-in `volumeSnapshot` method creates a distinct replica StatefulSet
and new snapshot-backed PVCs. Existing logical replica PVCs are retained for
rollback only when `retentionPolicy.whenDeleted: Retain` is reconciled before
the method switch; they are not migrated. Read the
[replica bootstrap migration guide](docs/replica-bootstrap.md) before enabling
the method on an existing release.

## Breaking Change in 2.0.0

MariaDB now mounts `/var/lib/mysql` from the data volume subdirectory configured
by `persistence.subPath` instead of the volume root. The default is `mysql`.
This prevents ext4-backed PVCs from exposing the filesystem-created
`lost+found` directory to MariaDB as a candidate database.

Existing installations whose data already lives at the volume root must set the
legacy value during upgrade:

```yaml
persistence:
  subPath: ""
```

Alternatively, migrate the existing volume-root data into the `mysql`
subdirectory before upgrading.

## Supported Architectures

| Architecture | Description |
|---|---|
| **standalone** | Single MariaDB instance with persistent storage (default) |
| **replication** | One fixed source with asynchronous GTID-based read replicas |

## Features

- **Official MariaDB image** from Docker Hub
- **Standalone and replication** modes with explicit configuration
- **GTID-based replication** using MariaDB-native GTID (`MASTER_USE_GTID=slave_pos`)
- **Physical replica bootstrap** from an operator-provided, application-consistent CSI VolumeSnapshot
- **Configuration presets** small, medium, large, oltp, read-heavy, analytics
- **Resource presets** small, medium, large for easy right-sizing
- **Init scripts** support via ConfigMap or inline values
- **TLS** server-side encryption with optional client enforcement
- **Prometheus metrics** via mysqld-exporter sidecar and ServiceMonitor
- **S3-compatible backup** CronJob with mariadb-dump and minio/mc upload
- **NetworkPolicy** for ingress traffic control
- **PodDisruptionBudget** for availability during maintenance
- **Datadir subPath isolation** to keep ext4 `lost+found` out of MariaDB logs
- **Password management** auto-generated or from existing Secret
- **Dual-stack networking** — IPv4/IPv6 service support across all 6 Service objects
- **External Secrets Operator** — ExternalSecret for Vault, AWS Secrets Manager, and more

## Installation

### HTTPS Repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install mariadb helmforge/mariadb
```

### OCI Registry

```bash
helm install mariadb oci://ghcr.io/helmforgedev/helm/mariadb
```

## Examples

The repository includes complete examples for standalone, replication,
production replication, and legacy volume-root upgrades under `examples/`.
The smallest architecture overrides are:

### Architecture selection

```yaml
# Standalone (default)
architecture: standalone

# Replication with 2 read replicas
architecture: replication
replication:
  readReplicas:
    replicaCount: 2
```

## Replica Bootstrap

Read replicas use a GTID-aware logical dump by default. Large installations can
opt into physical bootstrap from one application-consistent CSI
`VolumeSnapshot`; the chart restores only new replica PVCs and requires the
GTID captured at the exact snapshot point. The chart does not pause the source
or create the snapshot.

See the [replica bootstrap guide](docs/replica-bootstrap.md) for prerequisites,
upgrade impact, rollback, validation and failure recovery.

## Main Values

| Key | Default | Description |
|-----|---------|-------------|
| `architecture` | `standalone` | Deployment mode: standalone or replication |
| `image.repository` | `mariadb` | MariaDB image |
| `image.tag` | `13.0.2` | MariaDB version |
| `auth.rootPassword` | `""` | Root password (auto-generated if empty) |
| `auth.database` | `app` | Application database |
| `auth.username` | `app` | Application user |
| `auth.password` | `""` | Application password (auto-generated if empty) |
| `auth.replicationUsername` | `replicator` | Replication user |
| `auth.existingSecret` | `""` | Existing secret with passwords |
| `config.preset` | `none` | Configuration preset |
| `config.myCnf` | `""` | Extra my.cnf content |
| `persistence.subPath` | `mysql` | Data volume subdirectory mounted as `/var/lib/mysql`; set `""` for legacy volume-root installs |
| `persistence.prepareDataDir.enabled` | `false` | Opt-in root initContainer for storage drivers that do not honor `fsGroup`; incompatible with Pod Security `restricted` |
| `standalone.resourcesPreset` | `small` | Default standalone resource requests and limits |
| `standalone.persistence.size` | `8Gi` | Standalone PVC size |
| `replication.source.resourcesPreset` | `small` | Default source resource requests and limits |
| `replication.source.persistence.size` | `20Gi` | Source PVC size |
| `replication.source.affinity` | `{}` | Affinity for the source pod |
| `replication.source.tolerations` | `[]` | Tolerations for the source pod |
| `replication.readReplicas.replicaCount` | `2` | Number of read replicas |
| `replication.readReplicas.bootstrap.method` | `logical` | Replica bootstrap method: logical or volumeSnapshot |
| `replication.readReplicas.bootstrap.resumeUnmarkedDatadir` | `false` | Unsafe one-time escape hatch for a trusted legacy partial logical bootstrap |
| `replication.readReplicas.bootstrap.volumeSnapshot.name` | `""` | Application-consistent source VolumeSnapshot used by new replica PVCs |
| `replication.readReplicas.bootstrap.volumeSnapshot.gtid` | `""` | MariaDB GTID captured at the exact snapshot point |
| `replication.readReplicas.resourcesPreset` | `small` | Default replica resource requests and limits |
| `replication.readReplicas.persistence.size` | `20Gi` | Replica PVC size |
| `replication.readReplicas.affinity` | `{}` | Affinity for the replica pods |
| `replication.readReplicas.tolerations` | `[]` | Tolerations for the replica pods |
| `replication.binlog.format` | `ROW` | Binlog format |
| `service.type` | `ClusterIP` | Service type |
| `service.port` | `3306` | MariaDB port |
| `metrics.enabled` | `false` | Enable mysqld-exporter |
| `tls.enabled` | `false` | Enable server TLS |
| `backup.enabled` | `false` | Enable S3 backup CronJob |
| `backup.schedule` | `"0 3 * * *"` | Backup cron schedule |
| `backup.s3.credentialsFromPodIdentity` | `false` | Use EKS Pod Identity or IRSA instead of static S3 keys |
| `backup.s3.region` | `""` | AWS region required by workload identity |
| `backup.serviceAccount.annotations` | `{}` | Annotations for the dedicated backup identity |
| `networkPolicy.enabled` | `false` | Enable NetworkPolicy |
| `pdb.enabled` | `false` | Enable PodDisruptionBudget |
| `service.ipFamilyPolicy` | `~` | IP family policy (`SingleStack`, `PreferDualStack`, `RequireDualStack`) |
| `service.ipFamilies` | `[]` | IP families override (`IPv4`, `IPv6`) |
| `extraObjects` | `[]` | Extra Kubernetes manifests rendered with the release |
| `externalSecrets.enabled` | `false` | Render ExternalSecret resource |
| `externalSecrets.apiVersion` | `external-secrets.io/v1` | ExternalSecret API version |
| `externalSecrets.refreshInterval` | `1h` | Refresh interval |
| `externalSecrets.secretStoreRef.name` | `""` | SecretStore name (required when enabled) |
| `externalSecrets.secretStoreRef.kind` | `SecretStore` | SecretStore kind |
| `externalSecrets.data` | `[]` | Remote key mappings |

## Dual-Stack Services

MariaDB 13.0.2 is the stable GA release of the 13.0 rolling line. It adds
atomic `CREATE OR REPLACE TABLE`, single-table `UPDATE ... RETURNING`, InnoDB
log archiving and new routine types. Back up databases and validate startup,
replication, application compatibility and restore behavior before this major
upgrade. `mariadb-backup` does not support the new log-archive format while
`innodb_log_archive=ON`.

All 6 Service objects (client, metrics, source, source-metrics, replicas, replicas-metrics)
carry the same `ipFamilyPolicy` and `ipFamilies` settings.

```yaml
service:
  ipFamilyPolicy: PreferDualStack
  ipFamilies:
    - IPv4
    - IPv6
```

## Datadir SubPath and lost+found

Kubernetes storage classes often format PVCs as ext4. ext4 creates
`lost+found` at the filesystem root, and MariaDB scans every datadir
subdirectory as a database. Mounting the PVC root at `/var/lib/mysql` can
therefore produce this non-fatal but noisy log line:

```text
Invalid (old?) table or database name 'lost+found'
```

The chart avoids that on new installs by mounting the `mysql` subdirectory as
the datadir:

```yaml
persistence:
  subPath: mysql
```

For existing installations with data at the PVC root, keep the legacy behavior:

```yaml
persistence:
  subPath: ""
```

See [docs/datadir-subpath.md](docs/datadir-subpath.md) for upgrade guidance.

By default, the chart does not render a root initContainer for `persistence.subPath`.
It relies on `podSecurityContext.fsGroup` and `fsGroupChangePolicy: OnRootMismatch`,
which keeps the default path compatible with Pod Security `restricted`.

Only enable `persistence.prepareDataDir.enabled=true` for storage drivers that do
not honor `fsGroup` for subPath directories. That opt-in path runs as root with
`CHOWN` and `FOWNER` and requires a namespace-level Pod Security exception.

## External Secrets Operator (ESO)

`auth.existingSecret` is required alongside `externalSecrets.enabled=true` to prevent
credential drift between the chart-managed Secret and the ExternalSecret.

```yaml
auth:
  existingSecret: mariadb-credentials

externalSecrets:
  enabled: true
  secretStoreRef:
    name: vault-backend
    kind: ClusterSecretStore
  data:
    - secretKey: mariadb-root-password
      remoteRef:
        key: mariadb/credentials
        property: root-password
    - secretKey: mariadb-user-password
      remoteRef:
        key: mariadb/credentials
        property: user-password
```

## Differences from MySQL Chart

This chart uses MariaDB-native features:

- **GTID replication** uses `MASTER_USE_GTID=slave_pos` (MariaDB GTID is always enabled, no `gtid_mode` toggle)
- **Commands** use `mariadb`, `mariadb-admin`, `mariadb-dump` (not `mysql`, `mysqladmin`, `mysqldump`)
- **Environment variables** use `MARIADB_*` prefix (not `MYSQL_*`)
- **Replication** uses `CHANGE MASTER TO` with MariaDB-specific options
- **No mysqlx** protocol (MySQL-specific)

## CI Scenarios

| File | Description |
|------|-------------|
| `standalone.yaml` | Basic standalone mode |
| `replication.yaml` | Replication with 2 replicas |
| `initdb.yaml` | Init scripts with example table |
| `existing-secret.yaml` | External secret reference |
| `metrics.yaml` | Metrics sidecar enabled |
| `replication-metrics.yaml` | Replication with metrics |
| `config-preset.yaml` | OLTP config preset |
| `resources-preset.yaml` | Resource presets for replication |
| `legacy-volume-root.yaml` | Legacy datadir mount for existing volume-root installs |
| `tls.yaml` | TLS with existingSecret |
| `tls-networkpolicy.yaml` | TLS + replication + NetworkPolicy |
| `backup.yaml` | Backup with S3 |
| `dual-stack.yaml` | Dual-stack service policy |
| `external-secrets.yaml` | External Secrets Operator integration |

## Troubleshooting

Inspect the StatefulSet, MariaDB logs, and recent namespace events before
changing probes or credentials:

```bash
kubectl get statefulset,pod,pvc,service -l app.kubernetes.io/instance=<release>
kubectl logs -l app.kubernetes.io/instance=<release> --all-containers --tail=200 --prefix
kubectl get events --sort-by=.lastTimestamp
```

- If MariaDB reports `lost+found` as a database, preserve an existing
  volume-root installation with `persistence.subPath: ""`; see
  [docs/datadir-subpath.md](docs/datadir-subpath.md).
- If a replica stays unready, verify that the source is writable, the
  replication credentials are stable, and both replication threads are
  running before enabling `requireRunningReplication`.
- If the metrics sidecar cannot connect, verify the password Secret and keep
  `tls.client.enabled` aligned with the server TLS configuration.
- If a `NetworkPolicy` is enabled, allow application traffic on `service.port`.
  Metrics scraping requires both `metrics.enabled: true` and
  `networkPolicy.metrics.enabled: true`; configure
  `networkPolicy.metrics.extraFrom` with the permitted scraper sources.

## More Information

- [MariaDB documentation](https://mariadb.com/kb/en/)
- [Chart source](https://github.com/helmforgedev/charts/tree/main/charts/mariadb)
- [Datadir subPath migration](docs/datadir-subpath.md)

### Security Scan: `mariadb`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **89.898994%** |

Security posture acceptable.

<!-- @AI-METADATA
type: chart-readme
title: MariaDB Helm Chart
description: MariaDB with standalone and GTID-based replication modes, TLS, metrics, backup, and configuration presets

keywords: mariadb, database, replication, gtid, backup, dual-stack, external-secrets

purpose: Chart README with install, config, architecture, and values reference
scope: Chart

relations:
  - charts/mariadb/values.yaml
  - charts/mysql/README.md
path: charts/mariadb/README.md
version: 2.0
date: 2026-06-02
-->
