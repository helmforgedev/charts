{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{- define "mariadb.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "mariadb.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "mariadb.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "mariadb.labels" -}}
helm.sh/chart: {{ include "mariadb.chart" . }}
{{ include "mariadb.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "mariadb.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mariadb.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "mariadb.componentLabels" -}}
{{ include "mariadb.selectorLabels" .root }}
app.kubernetes.io/component: mariadb
app.kubernetes.io/part-of: mariadb
{{- if .role }}
app.kubernetes.io/role: {{ .role }}
{{- end }}
{{- end -}}

{{- define "mariadb.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "mariadb.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.backupServiceAccountName" -}}
{{- if .Values.backup.serviceAccount.create -}}
{{- default (printf "%s-backup" (include "mariadb.fullname" .)) .Values.backup.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.backup.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.secretName" -}}
{{- if .Values.auth.existingSecret -}}
{{- .Values.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-auth" (include "mariadb.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.tlsSecretName" -}}
{{- required "tls.existingSecret is required when tls.enabled=true" .Values.tls.existingSecret -}}
{{- end -}}

{{- define "mariadb.configMapName" -}}
{{- printf "%s-config" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.initdbConfigMapName" -}}
{{- printf "%s-initdb" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.sourceServiceName" -}}
{{- if eq .Values.architecture "replication" -}}
{{- printf "%s-source" (include "mariadb.fullname" .) -}}
{{- else -}}
{{- include "mariadb.fullname" . -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.clientServiceName" -}}
{{- include "mariadb.fullname" . -}}
{{- end -}}

{{- define "mariadb.replicasServiceName" -}}
{{- printf "%s-replicas" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.metricsServiceName" -}}
{{- printf "%s-metrics" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.sourceMetricsServiceName" -}}
{{- printf "%s-source-metrics" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.replicasMetricsServiceName" -}}
{{- printf "%s-replicas-metrics" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.sourceHeadlessServiceName" -}}
{{- if eq .Values.architecture "replication" -}}
{{- printf "%s-source-headless" (include "mariadb.fullname" .) -}}
{{- else -}}
{{- printf "%s-headless" (include "mariadb.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.replicasHeadlessServiceName" -}}
{{- printf "%s-replicas-headless" (include "mariadb.fullname" .) -}}
{{- end -}}

{{- define "mariadb.sourceStatefulSetName" -}}
{{- if eq .Values.architecture "replication" -}}
{{- printf "%s-source" (include "mariadb.fullname" .) -}}
{{- else -}}
{{- include "mariadb.fullname" . -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.replicaStatefulSetName" -}}
{{- if eq .Values.replication.readReplicas.bootstrap.method "volumeSnapshot" -}}
{{- printf "%s-snapshot-replicas" (include "mariadb.fullname" .) -}}
{{- else -}}
{{- printf "%s-replicas" (include "mariadb.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.rootPassword" -}}
{{- $secretName := include "mariadb.secretName" . -}}
{{- if .Values.auth.existingSecret -}}
{{- "" -}}
{{- else if .Values.auth.rootPassword -}}
{{- .Values.auth.rootPassword -}}
{{- else -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing $existing.data (hasKey $existing.data .Values.auth.existingSecretRootPasswordKey) -}}
{{- index $existing.data .Values.auth.existingSecretRootPasswordKey | b64dec -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.userPassword" -}}
{{- $secretName := include "mariadb.secretName" . -}}
{{- if .Values.auth.existingSecret -}}
{{- "" -}}
{{- else if .Values.auth.password -}}
{{- .Values.auth.password -}}
{{- else -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing $existing.data (hasKey $existing.data .Values.auth.existingSecretUserPasswordKey) -}}
{{- index $existing.data .Values.auth.existingSecretUserPasswordKey | b64dec -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.replicationPassword" -}}
{{- $secretName := include "mariadb.secretName" . -}}
{{- if .Values.auth.existingSecret -}}
{{- "" -}}
{{- else if .Values.auth.replicationPassword -}}
{{- .Values.auth.replicationPassword -}}
{{- else -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing $existing.data (hasKey $existing.data .Values.auth.existingSecretReplicationPasswordKey) -}}
{{- index $existing.data .Values.auth.existingSecretReplicationPasswordKey | b64dec -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.probeCommandString" -}}
mariadb-admin ping -h 127.0.0.1 -P {{ .Values.service.port }} -uroot --password="${MARIADB_ROOT_PASSWORD}"
{{- end -}}

{{- define "mariadb.replicaProbeCommandString" -}}
mariadb-admin ping --socket=/run/mysqld/mysqld.sock -uroot --password="${MARIADB_ROOT_PASSWORD}"
{{- end -}}

{{- define "mariadb.sourceReadinessCommandString" -}}
{{- if and (eq .Values.architecture "replication") .Values.replication.source.probes.requireWritable -}}
mariadb -h 127.0.0.1 -P {{ .Values.service.port }} -uroot --password="${MARIADB_ROOT_PASSWORD}" -Nse "SELECT IF(CAST(@@global.read_only AS CHAR) IN ('OFF', '0'), 1, 0)" | grep -qx 1
{{- else -}}
{{ include "mariadb.probeCommandString" . }}
{{- end -}}
{{- end -}}

{{- define "mariadb.replicaReadinessCommandString" -}}
{{- if and (eq .Values.architecture "replication") (or .Values.replication.readReplicas.probes.requireReadOnly .Values.replication.readReplicas.probes.requireRunningReplication) -}}
test -f /tmp/helmforge-replication-started && mariadb --socket=/run/mysqld/mysqld.sock -uroot --password="${MARIADB_ROOT_PASSWORD}" -Nse "SELECT IF(CAST(@@global.read_only AS CHAR) IN ('ON', '1'){{- if .Values.replication.readReplicas.probes.requireRunningReplication }} AND EXISTS (SELECT 1 FROM information_schema.processlist WHERE command = 'Binlog Dump') IS NOT NULL{{- end }}, 1, 0)" | grep -qx 1
{{- else -}}
{{ include "mariadb.replicaProbeCommandString" . }}
{{- end -}}
{{- end -}}

{{- define "mariadb.binlogExpireLogsSeconds" -}}
{{- if gt (int .Values.replication.binlog.retentionDays) 0 -}}
{{- mul (int .Values.replication.binlog.retentionDays) 86400 -}}
{{- else -}}
{{- .Values.replication.binlog.expireLogsSeconds -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.metricsEnv" -}}
- name: MARIADB_ROOT_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "mariadb.secretName" . }}
      key: {{ .Values.auth.existingSecretRootPasswordKey }}
{{- end -}}

{{- define "mariadb.metricsConfigInitContainer" -}}
- name: mysqld-exporter-config
  image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  command:
    - sh
    - -ec
    - |
      umask 077
      cat > /metrics/.my.cnf <<EOF
      [client]
      user=root
      password=${MARIADB_ROOT_PASSWORD}
      host=127.0.0.1
      port={{ .Values.service.port }}
      {{- if include "mariadb.tlsClientEnabled" . }}
      ssl-ca=/tls/{{ .Values.tls.caFilename }}
      {{- end }}
      EOF
  env:
    {{- include "mariadb.metricsEnv" . | nindent 4 }}
  securityContext:
    {{- toYaml .Values.securityContext | nindent 4 }}
  volumeMounts:
    - name: mysqld-exporter-config
      mountPath: /metrics
    {{- if .Values.tls.enabled }}
    - name: tls
      mountPath: /tls
      readOnly: true
    {{- end }}
{{- end -}}

{{- define "mariadb.metricsVolumeMounts" -}}
- name: mysqld-exporter-config
  mountPath: /etc/mysqld-exporter
  readOnly: true
{{- if .Values.tls.enabled }}
- name: tls
  mountPath: /tls
  readOnly: true
{{- end }}
{{- end -}}

{{- define "mariadb.dataVolumeMount" -}}
- name: data
  mountPath: /var/lib/mysql
  {{- with .Values.persistence.subPath }}
  subPath: {{ . | quote }}
  {{- end }}
{{- end -}}

{{- define "mariadb.prepareDataSubPathInitContainer" -}}
{{- if and .Values.persistence.subPath .Values.persistence.prepareDataDir.enabled }}
{{- with .Values.persistence.subPath }}
{{- $runAsUser := int (default 999 $.Values.securityContext.runAsUser) }}
{{- $runAsGroup := int (default $runAsUser $.Values.securityContext.runAsGroup) }}
{{- $fsGroup := int (default $runAsGroup $.Values.podSecurityContext.fsGroup) }}
- name: prepare-datadir-subpath
  image: "{{ $.Values.image.repository }}:{{ $.Values.image.tag }}"
  imagePullPolicy: {{ $.Values.image.pullPolicy }}
  command:
    - sh
    - -ec
    - |
      mkdir -p "/mnt/data/{{ . }}"
      chmod 2770 "/mnt/data/{{ . }}"
      chown {{ $runAsUser }}:{{ $fsGroup }} "/mnt/data/{{ . }}"
  securityContext:
    runAsUser: 0
    runAsGroup: 0
    runAsNonRoot: false
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    capabilities:
      add:
        - CHOWN
        - FOWNER
      drop:
        - ALL
  volumeMounts:
    - name: data
      mountPath: /mnt/data
{{- end }}
{{- end }}
{{- end -}}

{{- define "mariadb.tlsClientEnabled" -}}
{{- if or .Values.tls.client.enabled .Values.tls.requireSecureTransport -}}true{{- end -}}
{{- end -}}

{{- define "mariadb.cliTlsArgs" -}}
{{- if include "mariadb.tlsClientEnabled" . -}}
--ssl --ssl-ca=/tls/{{ .Values.tls.caFilename }}
{{- end -}}
{{- end -}}

{{- define "mariadb.backupSecretName" -}}
{{- if .Values.backup.s3.existingSecret -}}
{{- .Values.backup.s3.existingSecret -}}
{{- else -}}
{{- printf "%s-backup" (include "mariadb.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "mariadb.backupEnabled" -}}
{{- if .Values.backup.enabled -}}
  {{- if not .Values.backup.s3.endpoint -}}
    {{- fail "backup.s3.endpoint is required when backup.enabled is true" -}}
  {{- end -}}
  {{- if not .Values.backup.s3.bucket -}}
    {{- fail "backup.s3.bucket is required when backup.enabled is true" -}}
  {{- end -}}
  {{- if not .Values.backup.s3.credentialsFromPodIdentity -}}
    {{- if and (not .Values.backup.s3.existingSecret) (or (not .Values.backup.s3.accessKey) (not .Values.backup.s3.secretKey)) -}}
      {{- fail "backup requires either backup.s3.existingSecret, both backup.s3.accessKey and backup.s3.secretKey, or backup.s3.credentialsFromPodIdentity=true" -}}
    {{- end -}}
  {{- else -}}
    {{- if not .Values.backup.s3.region -}}
      {{- fail "backup.s3.region is required when backup.s3.credentialsFromPodIdentity is true" -}}
    {{- end -}}
    {{- if and (not .Values.backup.serviceAccount.create) (not .Values.backup.serviceAccount.name) -}}
      {{- fail "backup.serviceAccount.name is required when workload identity is enabled and backup.serviceAccount.create is false" -}}
    {{- end -}}
  {{- end -}}
true
{{- end -}}
{{- end -}}

{{- define "mariadb.backupHost" -}}
{{- include "mariadb.sourceServiceName" . -}}
{{- end -}}

{{- define "mariadb.backupTlsVolumeEnabled" -}}
{{- if include "mariadb.tlsClientEnabled" . -}}true{{- end -}}
{{- end -}}

{{- define "mariadb.replicationTlsClause" -}}
{{- if include "mariadb.tlsClientEnabled" . -}}
MASTER_SSL=1,
MASTER_SSL_CA='/tls/{{ .Values.tls.caFilename }}',
{{- end -}}
{{- end -}}

{{- define "mariadb.configPreset" -}}
{{- if eq .Values.config.preset "small" -}}
max_connections = 100
innodb_buffer_pool_size = 256M
innodb_log_file_size = 128M
{{- else if eq .Values.config.preset "medium" -}}
max_connections = 200
innodb_buffer_pool_size = 512M
innodb_log_file_size = 256M
{{- else if eq .Values.config.preset "large" -}}
max_connections = 400
innodb_buffer_pool_size = 1G
innodb_log_file_size = 512M
{{- else if eq .Values.config.preset "oltp" -}}
max_connections = 300
innodb_buffer_pool_size = 1G
innodb_log_file_size = 512M
innodb_flush_log_at_trx_commit = 1
sync_binlog = 1
innodb_io_capacity = 1000
{{- else if eq .Values.config.preset "read-heavy" -}}
max_connections = 300
innodb_buffer_pool_size = 1G
innodb_log_file_size = 512M
table_open_cache = 4096
tmp_table_size = 128M
max_heap_table_size = 128M
{{- else if eq .Values.config.preset "analytics" -}}
max_connections = 150
innodb_buffer_pool_size = 2G
innodb_log_file_size = 1G
tmp_table_size = 256M
max_heap_table_size = 256M
sort_buffer_size = 4M
{{- end -}}
{{- end -}}

{{- define "mariadb.resourcesPreset" -}}
{{- $preset := default "none" .preset -}}
{{- if eq $preset "small" -}}
requests:
  cpu: 250m
  memory: 512Mi
limits:
  cpu: 500m
  memory: 1Gi
{{- else if eq $preset "medium" -}}
requests:
  cpu: 500m
  memory: 1Gi
limits:
  cpu: "1"
  memory: 2Gi
{{- else if eq $preset "large" -}}
requests:
  cpu: "1"
  memory: 2Gi
limits:
  cpu: "2"
  memory: 4Gi
{{- end -}}
{{- end -}}

{{- define "mariadb.metricsResourcesPreset" -}}
{{- $preset := default "none" .Values.metrics.resourcesPreset -}}
{{- if eq $preset "small" -}}
requests:
  cpu: 25m
  memory: 64Mi
limits:
  cpu: 100m
  memory: 128Mi
{{- else if eq $preset "medium" -}}
requests:
  cpu: 50m
  memory: 128Mi
limits:
  cpu: 200m
  memory: 256Mi
{{- end -}}
{{- end -}}

{{- define "mariadb.volumeClaimTemplate" -}}
- metadata:
    name: data
    labels:
      {{- include "mariadb.selectorLabels" .root | nindent 6 }}
  spec:
    {{- with .dataSource }}
    dataSource:
      apiGroup: {{ .apiGroup }}
      kind: {{ .kind }}
      name: {{ .name }}
    {{- end }}
    accessModes:
      {{- toYaml .persistence.accessModes | nindent 6 }}
    {{- if .persistence.storageClass }}
    storageClassName: {{ .persistence.storageClass | quote }}
    {{- end }}
    resources:
      requests:
        storage: {{ .persistence.size }}
{{- end -}}

{{- define "mariadb.persistenceRetentionPolicy" -}}
{{- $policy := .persistence.retentionPolicy | default dict -}}
{{- $whenDeleted := $policy.whenDeleted | default "" -}}
{{- $whenScaled := $policy.whenScaled | default "" -}}
{{- if and $whenDeleted (not (or (eq $whenDeleted "Retain") (eq $whenDeleted "Delete"))) -}}
{{- fail "persistence.retentionPolicy.whenDeleted must be Retain or Delete" -}}
{{- end -}}
{{- if and $whenScaled (not (or (eq $whenScaled "Retain") (eq $whenScaled "Delete"))) -}}
{{- fail "persistence.retentionPolicy.whenScaled must be Retain or Delete" -}}
{{- end -}}
{{- if or $whenDeleted $whenScaled }}
persistentVolumeClaimRetentionPolicy:
  {{- with $whenDeleted }}
  whenDeleted: {{ . }}
  {{- end }}
  {{- with $whenScaled }}
  whenScaled: {{ . }}
  {{- end }}
{{- end }}
{{- end -}}

{{- define "mariadb.configMapData" -}}
my.cnf: |
  [mysqld]
  port = {{ .Values.service.port }}
  bind-address = 0.0.0.0
  skip-name-resolve = ON
  {{- if .Values.tls.enabled }}
  ssl_ca = /tls/{{ .Values.tls.caFilename }}
  ssl_cert = /tls/{{ .Values.tls.certFilename }}
  ssl_key = /tls/{{ .Values.tls.keyFilename }}
  {{- if .Values.tls.requireSecureTransport }}
  require_secure_transport = ON
  {{- end }}
  {{- end }}
  {{- if ne .Values.config.preset "none" }}
  {{ include "mariadb.configPreset" . | nindent 2 }}
  {{- end }}
  {{- if .Values.config.myCnf }}
  {{ .Values.config.myCnf | nindent 2 }}
  {{- end }}
{{- end -}}

{{- define "mariadb.initdbConfigMapData" -}}
00-bootstrap-users.sh: |
  #!/bin/sh
  set -eu

  mariadb --protocol=socket -uroot -p"${MARIADB_ROOT_PASSWORD}" <<EOSQL
  CREATE DATABASE IF NOT EXISTS \`${MARIADB_DATABASE}\`;
  CREATE USER IF NOT EXISTS '${MARIADB_USER}'@'%' IDENTIFIED BY '${MARIADB_PASSWORD}';
  GRANT ALL PRIVILEGES ON \`${MARIADB_DATABASE}\`.* TO '${MARIADB_USER}'@'%';
  {{- if eq .Values.architecture "replication" }}
  CREATE USER IF NOT EXISTS '${REPLICATION_USERNAME}'@'%' IDENTIFIED BY '${REPLICATION_PASSWORD}';
  GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO '${REPLICATION_USERNAME}'@'%';
  {{- end }}
  FLUSH PRIVILEGES;
  EOSQL
{{- range $name, $content := .Values.initdb.scripts }}
{{ $name }}: |
{{ $content | indent 2 }}
{{- end }}
{{- end -}}

{{- define "mariadb.configChecksum" -}}
{{- printf "%s\n%s" (include "mariadb.configMapData" .) (include "mariadb.initdbConfigMapData" .) | sha256sum -}}
{{- end -}}

{{- define "mariadb.renderAnnotations" -}}
{{- with .root.Values.commonAnnotations }}
annotations:
{{ toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "mariadb.podSpecCommon" -}}
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
serviceAccountName: {{ include "mariadb.serviceAccountName" . }}
{{- with .Values.priorityClassName }}
priorityClassName: {{ . }}
{{- end }}
{{- with .Values.podSecurityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
terminationGracePeriodSeconds: {{ .Values.terminationGracePeriodSeconds }}
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .Values.topologySpreadConstraints }}
topologySpreadConstraints:
  {{- toYaml .Values.topologySpreadConstraints | nindent 2 }}
{{- else if and (eq .Values.architecture "replication") .Values.replication.scheduling.enableDefaultTopologySpread }}
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: {{ .Values.replication.scheduling.topologyKey | quote }}
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      matchLabels:
        {{- include "mariadb.selectorLabels" . | nindent 8 }}
{{- end }}
{{- end -}}

{{- define "mariadb.affinity" -}}
{{- $root := .root }}
{{- $instance := .instance }}
{{- if and (eq $root.Values.architecture "replication") $instance.affinity }}
affinity:
  {{- toYaml $instance.affinity | nindent 2 }}
{{- else if $root.Values.affinity }}
affinity:
  {{- toYaml $root.Values.affinity | nindent 2 }}
{{- else if and (eq $root.Values.architecture "replication") $root.Values.replication.scheduling.enableDefaultPodAntiAffinity }}
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        podAffinityTerm:
          topologyKey: kubernetes.io/hostname
          labelSelector:
            matchLabels:
              {{- include "mariadb.selectorLabels" $root | nindent 14 }}
{{- end }}
{{- end -}}

{{- define "mariadb.tolerations" -}}
{{- $root := .root }}
{{- $instance := .instance }}
{{- if and (eq $root.Values.architecture "replication") $instance.tolerations }}
tolerations:
  {{- toYaml $instance.tolerations | nindent 2 }}
{{- else if $root.Values.tolerations }}
tolerations:
  {{- toYaml $root.Values.tolerations | nindent 2 }}
{{- end }}
{{- end }}

{{- define "mariadb.pdbEnabled" -}}
{{- if eq .Values.architecture "replication" -}}
{{- if .Values.replication.pdb.enabled -}}true{{- end -}}
{{- else -}}
{{- if .Values.pdb.enabled -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Compile all validation warnings and fail if any violation is found
*/}}

{{/*
Compile all validation warnings and fail if any violation is found
*/}}
{{- define "mariadb.validate" -}}
{{- $messages := list -}}
{{- $bootstrap := .Values.replication.readReplicas.bootstrap -}}
{{- if and (eq $bootstrap.method "volumeSnapshot") (ne .Values.architecture "replication") -}}
  {{- $messages = append $messages "replication.readReplicas.bootstrap.method=volumeSnapshot requires architecture=replication." -}}
{{- end -}}
{{- if eq $bootstrap.method "volumeSnapshot" -}}
  {{- if not .Values.replication.readReplicas.persistence.enabled -}}
    {{- $messages = append $messages "replication.readReplicas.persistence.enabled must be true when bootstrap.method=volumeSnapshot." -}}
  {{- end -}}
  {{- if not $bootstrap.volumeSnapshot.name -}}
    {{- $messages = append $messages "replication.readReplicas.bootstrap.volumeSnapshot.name is required when bootstrap.method=volumeSnapshot." -}}
  {{- end -}}
  {{- if not $bootstrap.volumeSnapshot.gtid -}}
    {{- $messages = append $messages "replication.readReplicas.bootstrap.volumeSnapshot.gtid is required when bootstrap.method=volumeSnapshot." -}}
  {{- end -}}
  {{- $replicaStatefulSetName := include "mariadb.replicaStatefulSetName" . -}}
  {{- range $ordinal := until (int .Values.replication.readReplicas.replicaCount) -}}
    {{- $pvcName := printf "data-%s-%d" $replicaStatefulSetName $ordinal -}}
    {{- $pvc := lookup "v1" "PersistentVolumeClaim" $.Release.Namespace $pvcName -}}
    {{- if $pvc -}}
      {{- $existingName := dig "spec" "dataSource" "name" "" $pvc -}}
      {{- $existingKind := dig "spec" "dataSource" "kind" "" $pvc -}}
      {{- if or (ne $existingName $bootstrap.volumeSnapshot.name) (ne $existingKind "VolumeSnapshot") -}}
        {{- $messages = append $messages (printf "Existing replica PVC %s was not provisioned from VolumeSnapshot %s; refusing to reuse it." $pvcName $bootstrap.volumeSnapshot.name) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if and .Values.externalSecrets .Values.externalSecrets.enabled -}}
  {{- if not .Values.auth.existingSecret -}}
    {{- $messages = append $messages "When externalSecrets.enabled is true, auth.existingSecret must be set to prevent credential drift between the chart-managed Secret and the ExternalSecret." -}}
  {{- end -}}
  {{- if not (dig "secretStoreRef" "name" "" .Values.externalSecrets) -}}
    {{- $messages = append $messages "When externalSecrets.enabled is true, externalSecrets.secretStoreRef.name must be provided." -}}
  {{- end -}}
{{- end -}}
{{- if .Values.backup.enabled -}}
  {{- if not .Values.backup.s3.endpoint -}}
    {{- $messages = append $messages "When backup.enabled is true, backup.s3.endpoint must be specified." -}}
  {{- else if not (regexMatch "^https?://[^/]+.*$" .Values.backup.s3.endpoint) -}}
    {{- $messages = append $messages "When backup.enabled is true, backup.s3.endpoint must be a valid URL starting with http:// or https:// with a valid host." -}}
  {{- end -}}
  {{- if not .Values.backup.s3.bucket -}}
    {{- $messages = append $messages "When backup.enabled is true, backup.s3.bucket must be specified." -}}
  {{- end -}}
  {{- if and (not .Values.backup.s3.credentialsFromPodIdentity) (not .Values.backup.s3.existingSecret) (or (not .Values.backup.s3.accessKey) (not .Values.backup.s3.secretKey)) -}}
    {{- $messages = append $messages "When backup.enabled is true, either backup.s3.existingSecret or both backup.s3.accessKey and backup.s3.secretKey must be provided." -}}
  {{- end -}}
  {{- if and .Values.backup.s3.credentialsFromPodIdentity (not .Values.backup.s3.region) -}}
    {{- $messages = append $messages "backup.s3.region is required when backup.s3.credentialsFromPodIdentity=true." -}}
  {{- end -}}
  {{- if and .Values.backup.s3.credentialsFromPodIdentity (not .Values.backup.serviceAccount.create) (not .Values.backup.serviceAccount.name) -}}
    {{- $messages = append $messages "backup.serviceAccount.name is required when workload identity is enabled and backup.serviceAccount.create=false." -}}
  {{- end -}}
{{- end -}}
{{- if .Values.tls.enabled -}}
  {{- if not .Values.tls.existingSecret -}}
    {{- $messages = append $messages "When tls.enabled is true, tls.existingSecret must be provided containing certificates." -}}
  {{- end -}}
{{- end -}}
{{- if $messages -}}
  {{- fail (printf "validation failed:\n%s" (join "\n" $messages)) -}}
{{- end -}}
{{- end -}}
