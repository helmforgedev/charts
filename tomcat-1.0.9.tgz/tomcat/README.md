# Apache Tomcat

Apache Tomcat chart for Kubernetes using the official `docker.io/library/tomcat` image.

## Highlights

- Official Tomcat image, pinned by default to `11.0.27-jdk17-temurin-noble`.
- Stable default install with an optional ROOT health webapp for deterministic probes and Helm tests.
- Preserves WARs or exploded applications baked into immutable Tomcat images before mounting the writable webapps volume.
- Non-root runtime with writable `webapps`, `logs`, `temp`, and `work` volumes.
- Ingress and Gateway API `HTTPRoute` exposure.
- Optional JMX remote port for platform monitoring integrations.
- Dual-stack Service fields, NetworkPolicy, HPA, PDB, persistent webapps/logs, and extra init/sidecar hooks.

### Security Scan: `tomcat`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **95%** |

Security posture: strong. Remaining findings are documented product exceptions
for opt-in NetworkPolicy ingress and egress boundaries.

## Install

```bash
helm install tomcat oci://repo.helmforge.dev/charts/tomcat
```

## Deploying Applications

The official Tomcat image starts without a production application. This chart enables a small default ROOT app so `/health.jsp` works immediately.
For real workloads, mount WAR files or exploded applications through `extraInitContainers`, `extraVolumes`, and `extraVolumeMounts`, or enable `webapps.persistence`.
If you build an immutable Tomcat image with applications under `/usr/local/tomcat/webapps`, keep `webapps.copyImageContent.enabled=true`.
The chart copies those image contents into the writable webapps volume when it is empty.

For production applications that do not expose `/health.jsp`, switch probes to TCP or set probe paths to an application endpoint:

```yaml
webapps:
  defaultRoot:
    enabled: false

startupProbe:
  mode: tcp
livenessProbe:
  mode: tcp
readinessProbe:
  mode: tcp
```

## Gateway API

```yaml
gatewayAPI:
  enabled: true
  parentRefs:
    - name: public-gateway
      namespace: gateway-system
  hostnames:
    - tomcat.example.com
```

## JMX

JMX is opt-in because remote JMX should normally be restricted to trusted networks.

```yaml
jmx:
  enabled: true
  hostname: tomcat.example.local
```

For authenticated or TLS-secured JMX, mount the required files with `extraVolumes`/`extraVolumeMounts` and append JVM flags through `jmx.extraOpts`.
When `jmx.rmiPort` differs from `jmx.port`, the chart exposes the RMI endpoint
through `service.ports.jmxRmi` so the registry and RMI Service ports stay unique.

## Upgrading to 11.0.27

Tomcat 11.0.27 contains bug fixes, dependency updates and stability improvements. No breaking configuration or values changes are introduced.

Upstream release notes: [11.0.27](https://tomcat.apache.org/tomcat-11.0-doc/changelog.html#Tomcat_11.0.27).

Tomcat 11.0.26 improves RewriteValve, TLS/OCSP/ALPN, WebSocket timeout, async
dispatch and DIGEST authentication behavior. Tomcat 11.0.25 required an authority on every HTTP/2 request, reset EL parser
state before reuse, and limits buffering in the bundled WebSocket chat example.
HTTP/2 stream prioritization and the OpenSSL FFM symbol-lookup fix were delivered
in Tomcat 11.0.0-M18. Custom clustering that uses `EncryptInterceptor` must
account for its new `AES/GCM/NoPadding` default before a rolling upgrade.

## Production Notes

- Keep `serviceAccount.automountServiceAccountToken=false` unless your app needs Kubernetes API access.
- Enable `networkPolicy.enabled` and explicitly allow ingress from your gateway or ingress controller namespace.
- Use `networkPolicy.egress.extraTo` to append peers to the built-in egress rules; use `networkPolicy.egress.extraEgress` only for standalone custom egress rules.
- Use persistent `webapps` storage only when applications are installed or mutated at runtime.
- Prefer immutable app images or init containers that fetch versioned WAR artifacts.
- Configure `tomcat.serverXml` or `tomcat.existingServerXmlConfigMap` when you need proxy connector attributes such as `proxyName`, `proxyPort`, or `scheme`.

## Values

| Key | Default | Description |
| --- | --- | --- |
| `replicaCount` | `1` | Number of Tomcat pods when HPA is disabled. |
| `image.repository` | `docker.io/library/tomcat` | Tomcat image repository. |
| `image.tag` | `11.0.27-jdk17-temurin-noble` | Tomcat image tag. |
| `service.type` | `ClusterIP` | Kubernetes Service type. |
| `service.ipFamilyPolicy` | `null` | Optional Service dual-stack policy. |
| `service.ipFamilies` | `[]` | Optional Service IP family ordering. |
| `webapps.defaultRoot.enabled` | `true` | Render a minimal ROOT app for health checks. |
| `webapps.copyImageContent.enabled` | `true` | Copy image-baked webapps into the mounted webapps volume when empty. |
| `webapps.persistence.enabled` | `false` | Persist `/usr/local/tomcat/webapps`. |
| `logs.persistence.enabled` | `false` | Persist `/usr/local/tomcat/logs`. |
| `tomcat.serverXml` | `""` | Inline `server.xml` override. |
| `tomcat.existingServerXmlConfigMap` | `""` | Existing ConfigMap containing `server.xml`. |
| `jmx.enabled` | `false` | Expose JMX remote options and service port. |
| `ingress.enabled` | `false` | Render Ingress. |
| `gatewayAPI.enabled` | `false` | Render Gateway API HTTPRoute. |
| `networkPolicy.enabled` | `false` | Render NetworkPolicy. |
| `networkPolicy.egress.extraTo` | `[]` | Additional peers appended to the built-in egress rules. |
| `networkPolicy.egress.extraEgress` | `[]` | Additional complete NetworkPolicy egress rules. |
| `autoscaling.enabled` | `false` | Render HPA. |
| `pdb.enabled` | `false` | Render PodDisruptionBudget. |

## CI Scenarios

- `ci/standalone.yaml`
- `ci/ingress.yaml`
- `ci/gateway-api.yaml`
- `ci/ip-family-policy.yaml`
- `ci/jmx.yaml`
- `ci/hardening.yaml`

## Artifact Hub

```yaml
artifacthub.io/category: integration-delivery
keywords: tomcat, apache, java, jakarta-ee, servlet, jsp, gateway-api
```
