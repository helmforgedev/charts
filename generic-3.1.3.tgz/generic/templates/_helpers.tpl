{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "chart.name" -}}
{{- default .Release.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name, truncated to 63 chars.
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Release.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels applied to all resources.
*/}}
{{- define "chart.labels" -}}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Selector labels for matchLabels.
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Service account name.
*/}}
{{- define "chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ default (include "chart.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
{{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Primary Service name.
*/}}
{{- define "chart.serviceName" -}}
{{- default (include "chart.fullname" .) .Values.service.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Named child resource.
*/}}
{{- define "chart.namedResource" -}}
{{- printf "%s-%s" (include "chart.fullname" .root) .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Checksum of chart-created ConfigMaps.
*/}}
{{- define "chart.configMapsChecksum" -}}
{{- toYaml (.Values.configMaps | default list) | sha256sum -}}
{{- end -}}

{{/*
Checksum of chart-created Secrets.
*/}}
{{- define "chart.secretsChecksum" -}}
{{- toYaml (.Values.secrets | default list) | sha256sum -}}
{{- end -}}

{{/*
Returns non-empty string if the workload is enabled, empty string if not.
*/}}
{{- define "chart.hasWorkload" -}}
{{- if .Values.workload.enabled -}}true{{- end -}}
{{- end -}}

{{/*
Returns the workload kind (Deployment, StatefulSet, DaemonSet).
*/}}
{{- define "chart.workloadKind" -}}
{{- .Values.workload.type | default "Deployment" -}}
{{- end -}}

{{/*
Returns true if the workload type is the given kind.
Usage: {{ include "chart.isWorkload" (dict "root" . "kind" "Deployment") }}
*/}}
{{- define "chart.isWorkload" -}}
{{- if and .root.Values.workload.enabled (eq (.root.Values.workload.type | default "Deployment") .kind) -}}true{{- end -}}
{{- end -}}

{{/*
Container image string.
Accepts a dict with: root (global context), container (container spec).
If the container defines image.repository, it overrides the global.
*/}}
{{- define "chart.containerImage" -}}
{{- $globalRepo := .root.Values.image.repository -}}
{{- $globalTag := .root.Values.image.tag -}}
{{- $globalDigest := .root.Values.image.digest -}}
{{- $repo := $globalRepo -}}
{{- $tag := $globalTag -}}
{{- $digest := $globalDigest -}}
{{- if .container.image -}}
  {{- if .container.image.repository -}}
    {{- $repo = .container.image.repository -}}
  {{- end -}}
  {{- if .container.image.tag -}}
    {{- $tag = .container.image.tag -}}
  {{- end -}}
  {{- if .container.image.digest -}}
    {{- $digest = .container.image.digest -}}
  {{- end -}}
{{- end -}}
{{- with .root.Values.global.imageRegistry -}}
  {{- $firstSegment := first (splitList "/" $repo) -}}
  {{- if not (or (contains "." $firstSegment) (contains ":" $firstSegment) (eq $firstSegment "localhost")) -}}
    {{- $repo = printf "%s/%s" (. | trimSuffix "/") $repo -}}
  {{- end -}}
{{- end -}}
{{- if $digest -}}
{{ printf "%s@%s" $repo ($digest | toString) }}
{{- else -}}
{{ printf "%s:%s" $repo ($tag | toString) }}
{{- end -}}
{{- end -}}

{{/*
Reusable container spec.
Accepts a dict with: root (global context), container (container spec).
Used by deployment, job, and cronjob templates to avoid duplication.
*/}}
{{- define "chart.containerSpec" -}}
{{- $isFirst := eq (.index | default 0 | int) 0 -}}
{{- $applyGlobalProbes := and $isFirst (not .skipGlobalProbes) -}}
- name: {{ .container.name }}
  image: {{ include "chart.containerImage" (dict "root" .root "container" .container) | quote }}
  imagePullPolicy: {{ .container.imagePullPolicy | default .root.Values.image.pullPolicy | default "Always" }}
  {{- with .container.command }}
  command:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .container.args }}
  args:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .container.workingDir }}
  workingDir: {{ . }}
  {{- end }}
  {{- $allEnv := concat (.root.Values.env | default list) (.container.env | default list) }}
  {{- if $allEnv }}
  env:
    {{- range $allEnv }}
    - name: {{ .name }}
      {{- if hasKey . "value" }}
      value: {{ tpl (.value | toString) $.root | quote }}
      {{- else if .valueFrom }}
      valueFrom:
        {{- toYaml .valueFrom | nindent 8 }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- if or .root.Values.envFrom .container.envFrom }}
  envFrom:
    {{- with .root.Values.envFrom }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
    {{- with .container.envFrom }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- with .container.ports }}
  ports:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if or .container.livenessProbe (and $applyGlobalProbes .root.Values.livenessProbe) }}
  livenessProbe:
    {{- toYaml (.container.livenessProbe | default .root.Values.livenessProbe) | nindent 4 }}
  {{- end }}
  {{- if or .container.readinessProbe (and $applyGlobalProbes .root.Values.readinessProbe) }}
  readinessProbe:
    {{- toYaml (.container.readinessProbe | default .root.Values.readinessProbe) | nindent 4 }}
  {{- end }}
  {{- if or .container.startupProbe (and $applyGlobalProbes .root.Values.startupProbe) }}
  startupProbe:
    {{- toYaml (.container.startupProbe | default .root.Values.startupProbe) | nindent 4 }}
  {{- end }}
  {{- if or .container.resources .root.Values.resources }}
  resources:
    {{- toYaml (.container.resources | default .root.Values.resources) | nindent 4 }}
  {{- end }}
  {{- if or .container.securityContext .root.Values.securityContext }}
  securityContext:
    {{- toYaml (.container.securityContext | default .root.Values.securityContext) | nindent 4 }}
  {{- else if eq .root.Values.securityPreset "baseline" }}
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
    runAsNonRoot: true
  {{- else if eq .root.Values.securityPreset "restricted" }}
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
    readOnlyRootFilesystem: true
    runAsNonRoot: true
    runAsUser: 1000
  {{- end }}
  {{- if or .container.volumeMounts .root.Values.persistence.mounts }}
  volumeMounts:
    {{- with .root.Values.persistence.mounts }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
    {{- with .container.volumeMounts }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
  {{- end }}
  {{- with .container.lifecycle }}
  lifecycle:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .container.terminationMessagePath | default .root.Values.terminationMessagePath }}
  terminationMessagePath: {{ . }}
  {{- end }}
  {{- with .container.terminationMessagePolicy | default .root.Values.terminationMessagePolicy }}
  terminationMessagePolicy: {{ . }}
  {{- end }}
{{- end -}}

{{/*
Pod spec shared by deployment, job, and cronjob.
Accepts a dict with: root (global context), containers (list), podSpec (optional overrides).
*/}}
{{- define "chart.podSpec" -}}
{{- $podSpec := .podSpec | default dict -}}
{{- with .root.Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
serviceAccountName: {{ include "chart.serviceAccountName" .root }}
{{- if hasKey .root.Values.serviceAccount "automountServiceAccountToken" }}
automountServiceAccountToken: {{ .root.Values.serviceAccount.automountServiceAccountToken }}
{{- end }}
{{- with $podSpec.priorityClassName | default .root.Values.priorityClassName }}
priorityClassName: {{ . }}
{{- end }}
{{- with $podSpec.preemptionPolicy | default .root.Values.preemptionPolicy }}
preemptionPolicy: {{ . }}
{{- end }}
{{- if or .root.Values.podSecurityContext $podSpec.podSecurityContext }}
securityContext:
  {{- toYaml ($podSpec.podSecurityContext | default .root.Values.podSecurityContext) | nindent 2 }}
{{- else if eq .root.Values.securityPreset "baseline" }}
securityContext:
  runAsNonRoot: true
  seccompProfile:
    type: RuntimeDefault
{{- else if eq .root.Values.securityPreset "restricted" }}
securityContext:
  fsGroup: 1000
  runAsGroup: 1000
  runAsNonRoot: true
  runAsUser: 1000
  seccompProfile:
    type: RuntimeDefault
{{- end }}
{{- with $podSpec.terminationGracePeriodSeconds | default .root.Values.terminationGracePeriodSeconds }}
terminationGracePeriodSeconds: {{ . }}
{{- end }}
{{- with $podSpec.runtimeClassName | default .root.Values.runtimeClassName }}
runtimeClassName: {{ . }}
{{- end }}
{{- with $podSpec.schedulerName | default .root.Values.schedulerName }}
schedulerName: {{ . }}
{{- end }}
{{- if hasKey .root.Values "hostNetwork" }}
hostNetwork: {{ ternary $podSpec.hostNetwork .root.Values.hostNetwork (hasKey $podSpec "hostNetwork") }}
{{- end }}
{{- if hasKey .root.Values "hostPID" }}
hostPID: {{ ternary $podSpec.hostPID .root.Values.hostPID (hasKey $podSpec "hostPID") }}
{{- end }}
{{- if hasKey .root.Values "hostIPC" }}
hostIPC: {{ ternary $podSpec.hostIPC .root.Values.hostIPC (hasKey $podSpec "hostIPC") }}
{{- end }}
{{- if hasKey .root.Values "shareProcessNamespace" }}
shareProcessNamespace: {{ ternary $podSpec.shareProcessNamespace .root.Values.shareProcessNamespace (hasKey $podSpec "shareProcessNamespace") }}
{{- end }}
{{- if hasKey .root.Values "enableServiceLinks" }}
enableServiceLinks: {{ ternary $podSpec.enableServiceLinks .root.Values.enableServiceLinks (hasKey $podSpec "enableServiceLinks") }}
{{- end }}
{{- if or .root.Values.initContainers $podSpec.initContainers }}
initContainers:
  {{- range $podSpec.initContainers | default .root.Values.initContainers }}
  {{- include "chart.containerSpec" (dict "root" $.root "container" .) | nindent 2 }}
  {{- end }}
{{- end }}
containers:
  {{- $root := .root }}
  {{- $skip := .skipGlobalProbes }}
  {{- range $i, $c := .containers }}
  {{- include "chart.containerSpec" (dict "root" $root "container" $c "index" $i "skipGlobalProbes" $skip) | nindent 2 }}
  {{- end }}
{{- if or .root.Values.persistence.volumes $podSpec.volumes }}
volumes:
  {{- with .root.Values.persistence.volumes }}
  {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- with $podSpec.volumes }}
  {{- toYaml . | nindent 2 }}
  {{- end }}
{{- end }}
{{- with $podSpec.nodeSelector | default .root.Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $podSpec.affinity | default .root.Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $podSpec.tolerations | default .root.Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $podSpec.topologySpreadConstraints | default .root.Values.topologySpreadConstraints }}
topologySpreadConstraints:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $podSpec.hostAliases | default .root.Values.hostAliases }}
hostAliases:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with $podSpec.dnsPolicy | default .root.Values.dnsPolicy }}
dnsPolicy: {{ . }}
{{- end }}
{{- with $podSpec.dnsConfig | default .root.Values.dnsConfig }}
dnsConfig:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "chart.validate" -}}
{{- $namePattern := "^[a-z0-9]([-a-z0-9]*[a-z0-9])?$" -}}
{{- range .Values.containers | default list }}
{{- if not (regexMatch $namePattern .name) }}
{{- fail (printf "containers[].name must be a DNS-1123 label: %s" .name) }}
{{- end }}
{{- if gt (len .name) 63 }}
{{- fail (printf "containers[].name must be 63 characters or fewer: %s" .name) }}
{{- end }}
{{- end }}
{{- range .Values.jobs | default list }}
{{- if not (regexMatch $namePattern .name) }}
{{- fail (printf "jobs[].name must be a DNS-1123 label: %s" .name) }}
{{- end }}
{{- if gt (len .name) 63 }}
{{- fail (printf "jobs[].name must be 63 characters or fewer: %s" .name) }}
{{- end }}
{{- end }}
{{- range .Values.cronjobs | default list }}
{{- if not (regexMatch $namePattern .name) }}
{{- fail (printf "cronjobs[].name must be a DNS-1123 label: %s" .name) }}
{{- end }}
{{- if gt (len .name) 63 }}
{{- fail (printf "cronjobs[].name must be 63 characters or fewer: %s" .name) }}
{{- end }}
{{- if not .schedule }}
{{- fail (printf "cronjobs[%s].schedule is required" .name) }}
{{- end }}
{{- end }}
{{- range .Values.configMaps | default list }}
{{- if not (regexMatch $namePattern .name) }}
{{- fail (printf "configMaps[].name must be a DNS-1123 label: %s" .name) }}
{{- end }}
{{- if gt (len .name) 63 }}
{{- fail (printf "configMaps[].name must be 63 characters or fewer: %s" .name) }}
{{- end }}
{{- end }}
{{- if and .Values.hpa.enabled (eq (.Values.workload.type | default "Deployment") "DaemonSet") }}
{{- fail "hpa.enabled cannot be used with workload.type=DaemonSet" }}
{{- end }}
{{- if and .Values.hpa.enabled (not .Values.hpa.maxReplicas) }}
{{- fail "hpa.maxReplicas is required when hpa.enabled=true" }}
{{- end }}
{{- $pdbHasMinAvailable := hasKey .Values.pdb "minAvailable" -}}
{{- $pdbHasMaxUnavailable := hasKey .Values.pdb "maxUnavailable" -}}
{{- if and .Values.pdb.enabled (not $pdbHasMinAvailable) (not $pdbHasMaxUnavailable) }}
{{- fail "pdb.minAvailable or pdb.maxUnavailable is required when pdb.enabled=true" }}
{{- end }}
{{- if and .Values.pdb.enabled $pdbHasMinAvailable $pdbHasMaxUnavailable }}
{{- fail "set only one of pdb.minAvailable or pdb.maxUnavailable" }}
{{- end }}
{{- if and .Values.serviceMonitor.enabled (not .Values.serviceMonitor.endpoints) }}
{{- fail "serviceMonitor.endpoints is required when serviceMonitor.enabled=true" }}
{{- end }}
{{- if and .Values.ingress.enabled (not .Values.ingress.hosts) (not .Values.ingress.defaultBackend) }}
{{- fail "ingress.hosts or ingress.defaultBackend is required when ingress.enabled=true" }}
{{- end }}
{{- if and .Values.ingress.enabled (eq .Values.service.enabled false) }}
{{- range .Values.ingress.hosts | default list }}
{{- range .paths | default (list "/") }}
{{- if or (kindIs "string" .) (not .backend) }}
{{- fail "ingress paths require an explicit backend when service.enabled=false" }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- if and .Values.gatewayApi.enabled (eq .Values.service.enabled false) }}
{{- range .Values.gatewayApi.httpRoutes | default list }}
{{- range .rules | default list }}
{{- if not .backendRefs }}
{{- fail "gatewayApi.httpRoutes[].rules[].backendRefs is required when service.enabled=false" }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- if and .Values.keda.enabled .Values.keda.scaledObject.enabled (not (include "chart.hasWorkload" .)) }}
{{- fail "keda.scaledObject.enabled requires workload.enabled=true" }}
{{- end }}
{{- range .Values.persistence.storage | default list }}
{{- if not .capacity }}
{{- fail (printf "persistence.storage[%s].capacity is required" .name) }}
{{- end }}
{{- end }}
{{- range .Values.persistence.persistentVolumeClaims | default list }}
{{- if not .storage }}
{{- fail (printf "persistence.persistentVolumeClaims[%s].storage is required" .name) }}
{{- end }}
{{- end }}
{{- end -}}
