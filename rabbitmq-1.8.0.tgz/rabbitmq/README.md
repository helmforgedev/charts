# RabbitMQ

RabbitMQ for Kubernetes with explicit `single-node` and `cluster` modes, optional Management UI, optional TLS, optional metrics, and dedicated operational docs for each architecture.

## Install

### HTTPS repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install rabbitmq helmforge/rabbitmq -f values.yaml
```

### OCI registry

```bash
helm install rabbitmq oci://ghcr.io/helmforgedev/helm/rabbitmq -f values.yaml
```

## Supported architectures

| Architecture | When to use | Document |
|-------------|-------------|----------|
| `single-node` | simple environments, development, staging, and workloads without broker-node failover requirements | [docs/single-node.md](docs/single-node.md) |
| `cluster` | production with multiple nodes, quorum queues, and broker redundancy | [docs/cluster.md](docs/cluster.md) |

## What this chart covers

- explicit architecture selection through `architecture`
- authentication with username, password, and Erlang cookie
- `existingSecret` for credentials managed outside the chart
- transparent `rabbitmq.conf` and `enabled_plugins` modeling
- optional Management UI
- optional TLS for AMQP and Management UI
- optional metrics through the native RabbitMQ Prometheus plugin
- optional `ServiceMonitor`
- optional `PodDisruptionBudget`
- Ingress support for the Management UI with configurable `ingressClassName`
- Gateway API HTTPRoute support for the Management UI
- dual-stack Service fields through `service.ipFamilyPolicy` and `service.ipFamilies`
- External Secrets Operator support for RabbitMQ credentials
- official Alpine RabbitMQ image by default; plugins are controlled by chart values

## How to choose the architecture

- use `single-node` when operational simplicity matters more than broker redundancy
- use `cluster` when queues must survive node loss and the application already handles multi-broker reconnect correctly

Recommended reading before installation:

- [Single Node](docs/single-node.md)
- [Cluster](docs/cluster.md)

## Official product references

- RabbitMQ Downloads: <https://www.rabbitmq.com/docs/download>
- RabbitMQ Cluster Formation: <https://www.rabbitmq.com/docs/cluster-formation>
- RabbitMQ Quorum Queues: <https://www.rabbitmq.com/quorum-queues.html>
- RabbitMQ TLS: <https://www.rabbitmq.com/docs/ssl>

## Operational direction

- for production, the recommended mode is `cluster` with `queueDefaults.type=quorum`
- use `single-node` only when broker-level HA is not a requirement
- do not treat a RabbitMQ cluster as a substitute for good queue design, routing, or consumer reconnect behavior

## Quick start

Minimal example:

```yaml
architecture: single-node

auth:
  existingSecret: rabbitmq-auth

singleNode:
  persistence:
    enabled: true
    size: 8Gi
```

Cluster example:

```yaml
architecture: cluster

auth:
  existingSecret: rabbitmq-auth

queueDefaults:
  type: quorum

cluster:
  replicaCount: 3
  persistence:
    enabled: true
    size: 20Gi

metrics:
  enabled: true
  serviceMonitor:
    enabled: true
```

Management UI ingress example:

```yaml
management:
  ingress:
    enabled: true
    ingressClassName: traefik
    hosts:
      - host: rabbitmq.example.com
        paths:
          - path: /
            pathType: Prefix
```

Management UI Gateway API example:

```yaml
management:
  enabled: true
  gateway:
    enabled: true
    parentRefs:
      - name: public
        namespace: gateway-system
    hostnames:
      - rabbitmq.example.com
```

External Secrets example:

```yaml
auth:
  existingSecret: rabbitmq-credentials

externalSecrets:
  enabled: true
  secretStoreRef:
    name: platform-secrets
    kind: ClusterSecretStore
  data:
    - secretKey: rabbitmq-username
      remoteRef:
        key: rabbitmq/auth
        property: username
    - secretKey: rabbitmq-password
      remoteRef:
        key: rabbitmq/auth
        property: password
    - secretKey: rabbitmq-erlang-cookie
      remoteRef:
        key: rabbitmq/auth
        property: erlang-cookie
```

## Best practices

### Security

- use `auth.existingSecret` in production
- keep the Erlang cookie stable across restarts and upgrades
- enable TLS when clients connect outside a trusted internal network boundary
- restrict Management UI exposure
- the default pod runs as UID 100 and GID 101 with RuntimeDefault seccomp,
  privilege escalation disabled, all Linux capabilities dropped, and a
  read-only root filesystem
- only `/var/lib/rabbitmq` and `/tmp` are writable through explicit volumes
- a non-root init container restores the Erlang cookie to owner-only mode after
  Kubernetes applies the volume filesystem group, including on legacy PVCs
- the ServiceAccount token is not mounted because RabbitMQ 4.1 and later peer
  discovery uses StatefulSet ordinals instead of querying the Kubernetes API

### Upgrades and credential retention

The chart reuses the username, password, and Erlang cookie from its existing
managed Secret during upgrades. This applies to both `--reset-values` and
`--reuse-values`, preventing the Secret from drifting away from credentials
stored in the persistent RabbitMQ database.

Security defaults are merged by the workload template, so they also apply when
`--reuse-values` carries forward the previous chart's empty security-context
maps. Explicit security-context keys and an explicit
`automountServiceAccountToken` value continue to override chart defaults.

Changing `auth.username`, `auth.password`, or `auth.erlangCookie` on an existing
release does not rotate live broker credentials. Perform rotation with RabbitMQ
administration tooling first, then move the synchronized credentials to an
existing Secret or External Secrets provider.

The default official image and earlier public chart versions use UID `100` and
GID `101`, which is the tested in-place upgrade path. Before upgrading a release
that used a custom image or custom process identity, inspect the existing cookie
ownership and keep the pod identity aligned:

```bash
kubectl exec -n <namespace> <rabbitmq-pod> -- stat -c '%u:%g %a' /var/lib/rabbitmq/.erlang.cookie
```

Set `podSecurityContext.runAsUser`, `runAsGroup`, and `fsGroup` to that image's
numeric identity before the upgrade. The non-root init container can then
restore mode `0600`. To migrate the PVC to UID `100`, first use an explicitly
authorized one-time maintenance pod to change ownership while RabbitMQ is
stopped; the hardened chart intentionally does not run a root init container.

### Queues and topology

- in production, prefer quorum queues over mirrored classic queues
- use `cluster` only when the application truly needs a multi-node topology
- validate client reconnect behavior before promoting the topology to production

### Scheduling

- in `cluster`, spread pods across nodes or zones
- enable `pdb.enabled=true` for production clusters
- keep `replicaCount >= 3` for the operational cluster baseline

### Observability

- enable `metrics.enabled=true` in monitored environments
- use `metrics.serviceMonitor.enabled=true` with Prometheus Operator
- monitor memory, disk, connections, queues, consumers, and node-local alarms

### Runtime efficiency

- the default image is `docker.io/library/rabbitmq:4.3.6-alpine`; it contains the management, Prometheus, and Kubernetes peer-discovery plugins, and the chart enables only the plugins requested by values
- RabbitMQ 4.3.6 fixes exchange binding cleanup, quorum reconciliation, classic queue recovery, AMQP 1.0 validation and credential expiry
- `management.referrerPolicy=no-referrer` enables the upstream Referrer-Policy support with a privacy-preserving default; set it to `""` to defer to the browser default
- `runtime.disableSchedulerBusyWait=true` is enabled by default to reduce idle CPU from Erlang scheduler spin-wait in containers
- default Kubernetes probes use lightweight TCP checks against the active AMQP listener instead of recurring `rabbitmq-diagnostics` commands
- use `runtime.additionalErlArgs` for extra Erlang VM flags and reserve `extraEnv` for explicit upstream environment variables or full overrides

## Main values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `architecture` | `single-node` or `cluster` | `single-node` |
| `image.repository` | RabbitMQ image repository | `docker.io/library/rabbitmq` |
| `image.tag` | RabbitMQ image tag | `4.3.6-alpine` |
| `auth.username` | Application username | `user` |
| `auth.password` | Application password | `""` |
| `auth.erlangCookie` | Erlang cookie | `""` |
| `auth.existingSecret` | Existing secret for credentials | `""` |
| `automountServiceAccountToken` | Mount a Kubernetes API token in the pod | `false` |
| `podSecurityContext` | Pod identity, filesystem group, and seccomp defaults | UID `100`, GID/fsGroup `101`, `RuntimeDefault` |
| `securityContext` | Container hardening defaults | non-root, read-only root, no escalation, drop `ALL` |
| `queueDefaults.type` | `quorum` or `classic` | `quorum` |
| `management.enabled` | Enable management plugin/UI | `true` |
| `management.referrerPolicy` | Management UI Referrer-Policy header; empty uses browser default | `no-referrer` |
| `management.ingress.enabled` | Enable management ingress | `false` |
| `management.ingress.ingressClassName` | Ingress class for the Management UI | `traefik` |
| `tls.enabled` | Enable TLS listeners | `false` |
| `singleNode.persistence.enabled` | Enable PVC for single node | `true` |
| `cluster.replicaCount` | Number of cluster nodes | `3` |
| `cluster.partitionHandling` | Cluster partition handling | `pause_minority` |
| `metrics.enabled` | Enable RabbitMQ Prometheus plugin | `false` |
| `metrics.serviceMonitor.enabled` | Enable ServiceMonitor | `false` |
| `runtime.disableSchedulerBusyWait` | Disable Erlang scheduler busy-wait for lower idle CPU | `true` |
| `runtime.additionalErlArgs` | Additional Erlang VM arguments appended to chart defaults | `""` |
| `startupProbe.enabled` | Enable TCP startup probe | `true` |
| `livenessProbe.enabled` | Enable TCP liveness probe | `true` |
| `readinessProbe.enabled` | Enable TCP readiness probe | `true` |
| `pdb.enabled` | Enable PodDisruptionBudget | `false` |
| `service.ipFamilyPolicy` | Service IP family policy for dual-stack clusters | `""` |
| `management.gateway.enabled` | Render Gateway API HTTPRoute for the Management UI | `false` |
| `externalSecrets.enabled` | Render ExternalSecret for credentials | `false` |

## CI scenarios

The `ci/` scenarios validate the main chart behaviors:

- `single-node.yaml`
- `cluster.yaml`
- `secure.yaml`
- `existing-secret.yaml`
- `metrics.yaml`
- `dual-stack.yaml`
- `gateway-api.yaml`
- `external-secrets.yaml`

## Examples

See `examples/`:

- `single-node.yaml`
- `cluster-ha.yaml`
- `management-tls.yaml`
- `gateway-api.yaml`
- `external-secrets.yaml`

## Important notes

- `cluster` is not magical HA abstraction; queues, consumers, and reconnect behavior remain application and operations concerns
- quorum queues are the recommended production direction in this chart
- this chart does not attempt to orchestrate federation, shovel, or advanced policy management in v1
- `management.ingress.ingressClassName` can be set to `traefik`, `nginx`, or any ingress class available in the target cluster
- `externalSecrets.enabled=true` requires `auth.existingSecret` so the chart does not generate credentials that drift from the operator-managed Secret

### Security Scan: `rabbitmq`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **74.24%** |

> Security posture acceptable.

<!-- @AI-METADATA
type: chart-readme
title: RabbitMQ Helm Chart
description: RabbitMQ chart with single-node and cluster modes, management UI, TLS

keywords: rabbitmq, amqp, messaging, queue, cluster

purpose: Usage guide for the RabbitMQ Helm chart with single-node and cluster modes
scope: Chart

relations:
  - charts/rabbitmq/DESIGN.md
  - charts/rabbitmq/docs/single-node.md
  - charts/rabbitmq/docs/cluster.md
path: charts/rabbitmq/README.md
version: 1.1
date: 2026-06-02
-->
