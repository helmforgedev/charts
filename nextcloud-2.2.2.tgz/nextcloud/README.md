# Nextcloud

[Nextcloud](https://nextcloud.com/) provides self-hosted file synchronization,
sharing and collaboration. This chart uses the official Apache image with
PostgreSQL, Redis, managed background jobs and coordinated S3 backups.

## Requirements

- Kubernetes 1.29 or newer and Helm 3 or newer.
- Persistent storage supporting UID/GID 33 and fsGroup ownership.
- Public DNS and a TLS-enabled ingress or Gateway controller for external access.
- Existing private S3-compatible buckets when primary object storage or
  integrated backups are enabled, with Secret or supported workload identity credentials.
- External Secrets Operator only when that integration is enabled.

The application defaults to `nextcloud:35.0.2-apache`, with verified amd64 and
arm64 support. The chart is Apache-2.0 licensed; Nextcloud Server is AGPL-3.0.
One replica and Recreate updates provide an explicit single-writer operating
model. Backups and upgrades have scheduled downtime.

## Installation

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install nextcloud helmforge/nextcloud \
  --namespace nextcloud --create-namespace
```

Alternatively, use OCI:

```bash
helm install nextcloud oci://ghcr.io/helmforgedev/helm/nextcloud \
  --namespace nextcloud --create-namespace
```

Wait for initial installation to complete, then forward the local service:

```bash
kubectl -n nextcloud port-forward service/nextcloud 8080:80
```

Open `http://localhost:8080`. The default administrator login is `admin`. Retrieve
the `admin-password` key from Secret `nextcloud-auth` using your approved Secret
workflow. Prefer `nextcloud.existingSecret` for managed production credentials.
The bootstrap password does not reset existing account passwords.

## Features

- Official application image and official HelmForge PostgreSQL/Redis dependencies.
- Automated native installation and guarded sequential application upgrades.
- Persistent native configuration, instance identity, custom apps, themes and data.
- Non-root Apache, read-only root filesystem, dropped capabilities and seccomp.
- Kubernetes CronJob with native Job logs, status history and overlap prevention.
- Existing Secret and External Secrets Operator contracts.
- S3-compatible primary object storage with static Secret or workload identity credentials.
- Upgrade guards that block accidental primary bucket, endpoint or prefix changes.
- Explicit trusted hosts/proxies, SMTP, Ingress, Gateway API and dualstack Service.
- Coordinated SQL/files backup, checksummed S3 publication and fresh-storage restore.
- Real HTTP/WebDAV acceptance tests and a full backup/recovery scenario.

## Production configuration

Start with [examples/production.yaml](examples/production.yaml). Supply the actual
public hostname, proxy CIDRs, TLS Secret, storage sizes and credential Secrets.
Configure ingress upload limits and timeouts alongside the PHP limits. Verify
email delivery before relying on password recovery or sharing notifications.

Helm uninstall deletes the chart-created application PVC. Use
`persistence.existingClaim` when the volume lifecycle is managed independently,
set `persistence.existingClaimAccessModes` to the claim's actual access modes
when cron or backup is enabled, and retain tested backups before removing a
release or namespace.

PostgreSQL and Redis are enabled by default. To use managed private endpoints,
disable the corresponding subchart and provide `externalDatabase` or
`externalRedis` settings. These external services must already exist. The chart
supports PostgreSQL and standalone Redis; it does not perform database-engine
conversion or configure Redis Sentinel/Cluster discovery.

## Background jobs

The chart runs Nextcloud background processing as a Kubernetes `CronJob` every
five minutes, matching the upstream recommendation. Each one-shot Job uses the
official application image, runs `cron.php` through PHP CLI as UID/GID 33 and
records completion or failure in the Kubernetes Job history. `concurrencyPolicy:
Forbid` prevents overlapping scheduled executions; `backoffLimit: 0` preserves
the first failure for diagnosis rather than silently retrying it. A PVC-backed
exclusive lock also serializes manually instantiated Jobs with scheduled runs.

The CronJob mounts the application PVC and is pinned to the application Pod's
node by default so `ReadWriteOnce` volumes work. `ReadWriteOncePod` cannot be used
while cron or backup is enabled. Existing claims must declare their actual modes
through `persistence.existingClaimAccessModes`; rendering fails when the value is
missing for these multi-Pod paths. Inspect executions with `kubectl get jobs -l
app.kubernetes.io/component=cron` and `kubectl logs job/<job-name> -c cron`.
Set `cron.suspend: true` to retain manual Job support without scheduling runs.

## Optional integrations

Enable `imaginary.enabled` for private image-preview offloading and
`notifyPush.enabled` for the official Client Push daemon. Both are opt-in, run
in the application Pod and use official pinned images. Client Push uses the
existing HTTPS endpoint at `/push` and requires a compatible operator-installed
Nextcloud app plus the upstream setup test.

See [setup, verification and lifecycle instructions](docs/integrations.md) before enabling them.

## Architecture

The chart deliberately runs a single Nextcloud Apache replica with `Recreate`
updates. The application Pod, background CronJob, bundled or external
PostgreSQL, and standalone Redis share one consistency boundary. The complete
application PVC and PostgreSQL database must be backed up and restored
together; Redis is runtime state, not a backup substitute.

Optional Imaginary and Client Push containers share the application Pod
lifecycle. Backup and restore Jobs coordinate the application, background cron,
PVC, PostgreSQL, and S3-compatible backup storage. See [DESIGN.md](DESIGN.md)
for the topology, security boundary, production responsibilities, and explicit
non-goals.

When `primaryObjectStore.enabled=true`, user file contents reside in an
exclusive S3-compatible bucket while the PVC retains application code,
configuration, custom applications and themes. PostgreSQL retains filenames and
the mapping to opaque object keys. See [primary object storage](docs/primary-object-storage.md)
before installation or migration.

## Backup and restore

Integrated backups stop the application and cron, capture PostgreSQL and the
complete PVC, resume service, and publish checksummed objects with a final
completion marker. A failed snapshot retains a volume lock for explicit recovery.
Restore requires a completed backup, matching application version, original
administrator credentials, fresh PVC and empty database.

Primary object storage and integrated backup storage are separate contracts and
must use different buckets. Integrated backups capture PostgreSQL and the PVC;
they do not copy the live primary bucket. Protect and recover that bucket with
provider-native versioning, snapshots or replication.

See [backup and restore](docs/backup-restore.md) before enabling the schedule.
Retain external Secrets separately. Practice restoration and verify non-admin
login, file contents/identities, shares, settings and new writes.

## Troubleshooting

Start with Kubernetes state and the application logs:

```bash
kubectl -n nextcloud get pods,jobs,cronjobs,pvc
kubectl -n nextcloud logs deployment/nextcloud -c nextcloud --tail=200
kubectl -n nextcloud describe pod -l app.kubernetes.io/instance=nextcloud
```

For background processing, inspect the latest cron Job and its `cron`
container. For backup or restore failures, do not remove a retained coordination
lock or scale the application manually until the failure boundary is understood;
follow the recovery procedure in [backup and restore](docs/backup-restore.md).
When optional Client Push setup cannot reach the App Store, distinguish network
policy or upstream availability from application compatibility before retrying;
see [integrations](docs/integrations.md).

## Examples and operational guides

- [Local installation](examples/simple.yaml)
- [Production routing and backups](examples/production.yaml)
- [Gateway API](examples/gateway-api.yaml)
- [External database and Redis](examples/external-services.yaml)
- [Primary S3-compatible object storage](examples/primary-object-storage.yaml)
- [Configuration and exposure](docs/configuration.md)
- [Primary object storage and migration](docs/primary-object-storage.md)
- [Backup, failure recovery and restore](docs/backup-restore.md)
- [Upgrades and migration from another chart](docs/upgrades.md)
- [Architecture and tradeoffs](DESIGN.md)

Nextcloud 35 is a major application upgrade. Release 35.0.1 fixes sharing,
ownership transfer, encryption key-cache, sensitive logging, CalDAV and file
metadata behavior. Back up the database, data PVC and configuration, confirm
app compatibility, and upgrade only one major version at a time.

## Non-goals

This chart does not provision office suites, Talk media relays, full-text search
or horizontal Nextcloud scaling. It does not migrate local user files into S3,
provision buckets or manage object-store lifecycle policies. Custom Nextcloud
apps are operator-managed and must support the selected upstream release. Helm
rollback cannot reverse database migrations.

## Security Scan: `nextcloud`

| Framework | Score |
| --- | --- |
| MITRE + NSA + SOC2 | **92.42424%** |

> Security posture acceptable.

Measured locally on 2026-11-07 with Kubescape 4.0.9 against the default rendered
application and bundled dependencies. The application uses a read-only root
filesystem; the PostgreSQL/Redis subcharts retain their upstream filesystem
defaults. This configuration assessment does not replace image CVE scanning.

## Contributing

See [CONTRIBUTING.md](../../CONTRIBUTING.md).

## Parameters

<!-- BEGIN GENERATED VALUES -->

| Parameter | Description | Default |
| --- | --- | --- |
| `nameOverride` | Override the chart name. | `""` |
| `fullnameOverride` | Override the release resource name. | `""` |
| `commonLabels` | Extra labels on resources. | `{}` |
| `commonAnnotations` | Annotations added to every chart-owned Kubernetes resource. | `{}` |
| `image.repository` | Official image repository. | `"docker.io/library/nextcloud"` |
| `image.tag` | Pinned application release. | `"35.0.2-apache"` |
| `image.pullPolicy` | Image pull policy. | `"IfNotPresent"` |
| `imagePullSecrets` | Registry authentication Secret references. | `[]` |
| `nextcloud.adminUser` | Initial administrator login; changing this does not rename existing users. | `"admin"` |
| `nextcloud.adminPassword` | Initial administrator password; generated and retained when empty. | `""` |
| `nextcloud.existingSecret` | Existing Secret containing the initial administrator password. | `""` |
| `nextcloud.existingSecretPasswordKey` | Password key in the administrator Secret. | `"admin-password"` |
| `nextcloud.trustedDomains` | Allowed HTTP Host names, reconciled on upgrades. | `["localhost"]` |
| `nextcloud.trustedProxies` | Explicit reverse proxy IP addresses or CIDRs. | `[]` |
| `nextcloud.overwriteCliUrl` | Public URL for links generated by background jobs. | `"http://localhost:8080"` |
| `nextcloud.overwriteProtocol` | Proxy protocol override; empty, http or https. | `""` |
| `nextcloud.overwriteHost` | Public host override behind a trusted proxy. | `""` |
| `nextcloud.defaultPhoneRegion` | Default phone region for profile validation. | `"US"` |
| `nextcloud.maintenanceWindowStart` | Start hour in UTC for expensive maintenance background tasks. | `1` |
| `php.memoryLimit` | Maximum memory per PHP request. | `"512M"` |
| `php.uploadLimit` | Maximum upload and POST body size. | `"512M"` |
| `imaginary.enabled` | Enable private preview offloading. | `false` |
| `imaginary.image.repository` | Official Nextcloud Imaginary image. | `"ghcr.io/nextcloud-releases/aio-imaginary"` |
| `imaginary.image.digest` | Immutable multi-platform image digest. | `"sha256:ea96034f97e9921015001c43947ab88ee5516e7e793c4c753a3618feca9e8548"` |
| `imaginary.image.pullPolicy` | Image pull policy. | `"IfNotPresent"` |
| `imaginary.maxAllowedResolution` | Maximum source resolution in megapixels. | `50` |
| `imaginary.previewProviders` | Preview providers when enabled. | `["OC\\Preview\\TXT","OC\\Preview\\MarkDown","OC\\Preview\\OpenDocument","OC\\Preview\\Krita","OC\\Preview\\Imaginary"]` |
| `imaginary.resources.requests.cpu` | CPU request. | `"25m"` |
| `imaginary.resources.requests.memory` | Memory request. | `"128Mi"` |
| `imaginary.resources.limits.cpu` | CPU limit. | `"1"` |
| `imaginary.resources.limits.memory` | Memory limit. | `"512Mi"` |
| `notifyPush.enabled` | Enable the daemon; install and configure the Client Push app separately. | `false` |
| `notifyPush.image.repository` | Official Client Push daemon image. | `"ghcr.io/nextcloud/notify_push"` |
| `notifyPush.image.tag` | Pinned daemon version. | `"v1.4.1"` |
| `notifyPush.image.pullPolicy` | Image pull policy. | `"IfNotPresent"` |
| `notifyPush.resources.requests.cpu` | CPU request. | `"10m"` |
| `notifyPush.resources.requests.memory` | Memory request. | `"32Mi"` |
| `notifyPush.resources.limits.cpu` | CPU limit. | `"500m"` |
| `notifyPush.resources.limits.memory` | Memory limit. | `"128Mi"` |
| `cron.enabled` | Enable Nextcloud cron processing. | `true` |
| `cron.schedule` | Cron schedule; upstream recommends every five minutes. | `"*/5 * * * *"` |
| `cron.suspend` | Suspend scheduling while retaining the CronJob for manual runs. | `false` |
| `cron.startingDeadlineSeconds` | Maximum delay for starting a missed execution. | `300` |
| `cron.activeDeadlineSeconds` | Maximum execution duration. | `900` |
| `cron.successfulJobsHistoryLimit` | Successful Jobs retained for inspection. | `1` |
| `cron.failedJobsHistoryLimit` | Failed Jobs retained for diagnostics. | `3` |
| `cron.backoffLimit` | Pod retries before an execution is marked failed. | `0` |
| `cron.affinity` | Optional affinity override; default pins cron to the application node. | `{}` |
| `cron.resources.requests.cpu` | requests cpu | `"25m"` |
| `cron.resources.requests.memory` | requests memory | `"128Mi"` |
| `cron.resources.limits.cpu` | limits cpu | `"500m"` |
| `cron.resources.limits.memory` | limits memory | `"512Mi"` |
| `resources.requests.cpu` | requests cpu | `"100m"` |
| `resources.requests.memory` | requests memory | `"512Mi"` |
| `resources.limits.cpu` | limits cpu | `"2"` |
| `resources.limits.memory` | limits memory | `"1536Mi"` |
| `initResources.requests.cpu` | requests cpu | `"25m"` |
| `initResources.requests.memory` | requests memory | `"64Mi"` |
| `initResources.limits.cpu` | limits cpu | `"500m"` |
| `initResources.limits.memory` | limits memory | `"128Mi"` |
| `podSecurityContext.runAsNonRoot` | podSecurityContext runAsNonRoot | `true` |
| `podSecurityContext.runAsUser` | podSecurityContext runAsUser | `33` |
| `podSecurityContext.runAsGroup` | podSecurityContext runAsGroup | `33` |
| `podSecurityContext.fsGroup` | podSecurityContext fsGroup | `33` |
| `podSecurityContext.fsGroupChangePolicy` | podSecurityContext fsGroupChangePolicy | `"OnRootMismatch"` |
| `podSecurityContext.seccompProfile.type` | seccompProfile type | `"RuntimeDefault"` |
| `securityContext.allowPrivilegeEscalation` | securityContext allowPrivilegeEscalation | `false` |
| `securityContext.readOnlyRootFilesystem` | securityContext readOnlyRootFilesystem | `true` |
| `securityContext.capabilities.drop` | capabilities drop | `["ALL"]` |
| `persistence.enabled` | Enable the complete /var/www/html PVC. | `true` |
| `persistence.existingClaim` | Reuse a PVC, including a restored instance. | `""` |
| `persistence.existingClaimAccessModes` | Actual access modes of existingClaim; required when cron or backup is enabled. | `[]` |
| `persistence.storageClass` | Storage class; empty uses the cluster default. | `""` |
| `persistence.accessModes` | Access modes for the single application writer. | `["ReadWriteOnce"]` |
| `persistence.size` | Requested volume size. | `"10Gi"` |
| `primaryObjectStore.enabled` | Store user file contents in an S3-compatible bucket. | `false` |
| `primaryObjectStore.provider` | Primary object-store provider; only S3 is supported. | `"s3"` |
| `primaryObjectStore.endpoint` | S3 hostname or HTTP(S) URL without a path. | `""` |
| `primaryObjectStore.port` | S3 endpoint port. | `443` |
| `primaryObjectStore.useSsl` | Use TLS for the S3 endpoint. | `true` |
| `primaryObjectStore.region` | AWS signing region. | `"us-east-1"` |
| `primaryObjectStore.bucket` | Existing exclusive primary data bucket. | `""` |
| `primaryObjectStore.usePathStyle` | Use path-style S3 requests. | `false` |
| `primaryObjectStore.objectPrefix` | Prefix prepended to opaque object IDs. | `"urn:oid:"` |
| `primaryObjectStore.storageClass` | Storage class assigned to new objects. | `"STANDARD"` |
| `primaryObjectStore.legacyAuth` | Use legacy S3 authentication. | `false` |
| `primaryObjectStore.autocreate` | Allow Nextcloud to create a missing bucket. | `false` |
| `primaryObjectStore.credentialsFromPodIdentity` | Discover credentials through the Pod identity. | `false` |
| `primaryObjectStore.existingSecret` | Secret containing primary object-store credentials. | `""` |
| `primaryObjectStore.existingSecretAccessKeyKey` | Access key ID key. | `"access-key"` |
| `primaryObjectStore.existingSecretSecretKeyKey` | Secret access key key. | `"secret-key"` |
| `primaryObjectStore.serviceAccount.create` | Create a dedicated workload-identity ServiceAccount. | `true` |
| `primaryObjectStore.serviceAccount.name` | Existing or created ServiceAccount name override. | `""` |
| `primaryObjectStore.serviceAccount.annotations` | Workload identity annotations. | `{}` |
| `primaryObjectStore.serviceAccount.automountServiceAccountToken` | Mount the token required by the identity provider. | `true` |
| `primaryObjectStore.networkPolicyEgress` | Explicit egress rules for the primary S3 endpoint. | `[]` |
| `primaryObjectStore.protection.acknowledgePreviousConfigurationHash` | Previous guard fingerprint for an intentional migration. | `""` |
| `service.type` | Kubernetes Service type. | `"ClusterIP"` |
| `service.port` | Service port mapped to Apache 8080. | `80` |
| `service.ipFamilyPolicy` | Optional IP family policy. | `""` |
| `service.ipFamilies` | Optional IP family order. | `[]` |
| `postgresql.enabled` | Enable the bundled database. | `true` |
| `postgresql.auth.database` | auth database | `"nextcloud"` |
| `postgresql.auth.username` | auth username | `"nextcloud"` |
| `externalDatabase.host` | PostgreSQL DNS name. | `""` |
| `externalDatabase.port` | PostgreSQL port. | `5432` |
| `externalDatabase.database` | Existing empty database on first installation. | `"nextcloud"` |
| `externalDatabase.username` | Database owner login. | `"nextcloud"` |
| `externalDatabase.existingSecret` | Secret containing the database password. | `""` |
| `externalDatabase.existingSecretPasswordKey` | Database password key. | `"password"` |
| `redis.enabled` | Enable bundled standalone Redis. | `true` |
| `redis.architecture` | Supported topology. | `"standalone"` |
| `externalRedis.host` | Standalone Redis DNS name. | `""` |
| `externalRedis.port` | Redis port. | `6379` |
| `externalRedis.existingSecret` | Secret containing the Redis password. | `""` |
| `externalRedis.existingSecretPasswordKey` | Redis password key. | `"password"` |
| `podLabels` | Pod labels. | `{}` |
| `podAnnotations` | Pod annotations. | `{}` |
| `nodeSelector` | Node scheduling constraints. | `{}` |
| `tolerations` | Tolerations. | `[]` |
| `affinity` | Pod affinity configuration. | `{}` |
| `terminationGracePeriodSeconds` | Grace period for draining HTTP requests and active background jobs. | `120` |
| `ingress.enabled` | Render an Ingress. | `false` |
| `ingress.ingressClassName` | Ingress controller class. | `""` |
| `ingress.annotations` | Controller-specific annotations, including request body size limits. | `{}` |
| `ingress.hosts` | Host/path rules. | `[{"host":"nextcloud.example.com","paths":[{"path":"/","pathType":"Prefix"}]}]` |
| `ingress.tls` | TLS Secret references and hosts. | `[]` |
| `gatewayAPI.enabled` | Render HTTPRoute resources. | `false` |
| `gatewayAPI.httpRoutes` | Complete route definitions; missing backends target Nextcloud. | `[]` |
| `externalSecrets.enabled` | Render ExternalSecret resources. | `false` |
| `externalSecrets.refreshInterval` | Default refresh interval. | `"1h"` |
| `externalSecrets.items` | Complete ExternalSecret definitions with provider spec. | `[]` |
| `smtp.enabled` | Enable SMTP configuration. | `false` |
| `smtp.host` | SMTP server hostname. | `""` |
| `smtp.port` | SMTP port. | `587` |
| `smtp.secure` | Transport security: tls for STARTTLS, ssl for implicit TLS, or empty. | `"tls"` |
| `smtp.fromAddress` | Sender local part. | `"nextcloud"` |
| `smtp.domain` | Sender domain. | `"example.com"` |
| `smtp.username` | Authentication login; empty disables SMTP authentication. | `""` |
| `smtp.existingSecret` | Existing SMTP credential Secret. | `""` |
| `smtp.existingSecretPasswordKey` | SMTP password key. | `"password"` |
| `networkPolicy.enabled` | Enable NetworkPolicy. | `false` |
| `networkPolicy.extraIngress` | Additional inbound rules; default allows same-namespace clients. | `[]` |
| `networkPolicy.extraEgress` | Additional outbound rules for external databases, SMTP and Internet integrations. | `[]` |
| `backup.enabled` | Enable scheduled integrated backups. | `false` |
| `backup.schedule` | Cron schedule. | `"0 2 * * *"` |
| `backup.suspend` | Suspend scheduling, retaining manual job support. | `false` |
| `backup.activeDeadlineSeconds` | Maximum total job duration in seconds. | `7200` |
| `backup.quiesceTimeout` | Maximum time to suspend cron and stop application writers. | `180` |
| `backup.successfulJobsHistoryLimit` | Successful job history. | `1` |
| `backup.failedJobsHistoryLimit` | Failed jobs retained for diagnostics. | `3` |
| `backup.databaseImage` | Official SQL client; must match the PostgreSQL server major. | `"docker.io/library/postgres:18.6-trixie"` |
| `backup.s3Image` | Official AWS CLI for S3-compatible object stores. | `"public.ecr.aws/aws-cli/aws-cli:2.36.43"` |
| `backup.workspaceSize` | Maximum ephemeral staging storage; allow space for the complete archive and dump. | `"20Gi"` |
| `backup.resources.requests.cpu` | requests cpu | `"100m"` |
| `backup.resources.requests.memory` | requests memory | `"256Mi"` |
| `backup.resources.limits.cpu` | limits cpu | `"2"` |
| `backup.resources.limits.memory` | limits memory | `"1Gi"` |
| `backup.serviceAccount.create` | Create the ServiceAccount used by backup and restore Jobs. | `true` |
| `backup.serviceAccount.name` | ServiceAccount name; empty uses the stable backup resource name. | `""` |
| `backup.serviceAccount.annotations` | ServiceAccount annotations, including IRSA role annotations. | `{}` |
| `backup.serviceAccount.automountServiceAccountToken` | Automatically mount the Kubernetes API token. | `false` |
| `backup.s3.endpoint` | Optional endpoint URL for S3-compatible storage. | `""` |
| `backup.s3.allowInsecureHTTP` | Explicitly permit HTTP only on a trusted isolated network; use HTTPS in production. | `false` |
| `backup.s3.bucket` | Existing private bucket. | `""` |
| `backup.s3.prefix` | Backup object prefix, without leading or trailing slash. | `"nextcloud"` |
| `backup.s3.region` | AWS signing region. | `"us-east-1"` |
| `backup.s3.credentialsFromPodIdentity` | Use the AWS CLI workload identity credential chain instead of static keys. | `false` |
| `backup.s3.existingSecret` | Secret containing S3 credentials. | `""` |
| `backup.s3.existingSecretAccessKeyKey` | Access key ID key. | `"access-key"` |
| `backup.s3.existingSecretSecretKeyKey` | Secret access key key. | `"secret-key"` |
| `restore.enabled` | Keep application stopped and create a restore Job. Disable after successful restore. | `false` |
| `restore.backupPath` | Exact S3 prefix for a completed backup, including its unique backup ID. | `""` |

<!-- END GENERATED VALUES -->
