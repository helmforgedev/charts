# Upgrades and migration

## Before an upgrade

Read the upstream release notes and verify installed apps support the target
major version. Take a complete integrated backup and practice restoration.
Record the existing image, chart values, application status and external Secret
references. Schedule an outage: the chart uses one writer and Recreate updates.

Nextcloud requires sequential major-version upgrades. First update to the latest
patch of the installed major, then move one major forward. Finish background
migrations before the next major upgrade. The official image refuses downgrades
and major-version skips. Do not bypass those checks or treat a Helm rollback as
a database rollback.

## Rollout behavior

The init container refreshes image-owned configuration fragments and PHP
extensions. The native image entrypoint synchronizes application code and runs
the native upgrade. The persisted `config.php`, instance identity, custom apps
and data remain on the PVC. Cron Jobs share the initialization lock and will not run
against an uninitialized or upgrade-pending database.

Inspect web logs and Kubernetes cron Job logs, run `php occ status --output=json` inside the application
container, and verify a user login, WebDAV read/write and existing shares. The
startup probe allows up to 15 minutes for installation/upgrade. If this is
insufficient for a large database, investigate progress before changing probe
settings or repeatedly restarting the instance.

## Migrating from the co-located cron worker

Chart 2.0 replaces the continuously running cron sidecar with a native Kubernetes
CronJob. Remove `cron.interval` and `cron.initialDelay` from retained values and
configure `cron.schedule` instead. The default remains every five minutes. Review
the Job history/deadline settings and ensure the application PVC supports a second
Pod on the same node; `ReadWriteOncePod` is not compatible with enabled cron or
backup. Existing claims must declare their real modes through
`persistence.existingClaimAccessModes` before either path can render.

After upgrading, confirm `<fullname>-cron` exists, create a manual Job with
`kubectl create job --from=cronjob/<fullname>-cron <name>`, wait for completion,
and inspect its `cron` container log. The old `cron` container should no longer be
present in the application Deployment.

Existing Secret content used as environment variables requires a rollout to take
effect. Bootstrap administrator settings create the first account only. Change
existing passwords through Nextcloud's supported account management commands.

## Primary object storage changes

Once primary object storage is active, an upgrade guard rejects disabling it or
changing the endpoint, bucket, object prefix, credential source and protocol
options. This includes an upgrade that accidentally omits retained values. Keep
`primaryObjectStore` in the release overrides and use `--reuse-values` only when
the new chart defaults are not required.

For an intentional object-store migration, stop all application and cron
writers, snapshot PostgreSQL, the PVC and both object stores, and complete the
provider-supported copy before changing Helm values. The rejected upgrade
reports the previous configuration hash. Supply that exact value through
`primaryObjectStore.protection.acknowledgePreviousConfigurationHash` for the
planned transition, validate existing and new WebDAV objects, then remove the
acknowledgement from retained overrides.

Never enable primary object storage on an instance that currently stores user
files locally. Upstream Nextcloud states that the existing files become
inaccessible. See [primary object storage](primary-object-storage.md) for the
supported migration from an installation that already uses the same S3 primary
store.

## Migrating from another chart

Do not replace the Helm release in place or adopt an existing database PVC
without understanding the source chart's storage and credential contracts.
Identify the source application version, database engine and version, entire
application data layout, native instance secrets, custom apps and background jobs.
This chart supports PostgreSQL; a MySQL/MariaDB installation needs a separately
planned and verified upstream database conversion before migration.

When the source chart already uses S3 primary storage, preserve the exact bucket,
endpoint, region, object prefix, database and native instance configuration.
Do not run the source and destination against those resources concurrently.

Stop all source web, cron and queue writers before taking a consistent SQL/files
copy. Restore into a separate release with fresh storage, matching application
version and retained instance configuration. Reconcile the destination database
and Redis endpoints and configure the public URL and trusted proxies. Verify
non-admin login, file contents and IDs, shares, app settings and new writes before
switching traffic. Keep the source frozen and recoverable until acceptance.

Source archives from unrelated backup tools are not automatically in the chart's
integrated backup format. Use an explicit offline migration procedure or convert
and validate the data separately; do not fabricate a completion marker.
