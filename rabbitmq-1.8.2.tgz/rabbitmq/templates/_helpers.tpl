{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{- define "rabbitmq.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "rabbitmq.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "rabbitmq.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" -}}
{{- end -}}

{{- define "rabbitmq.labels" -}}
helm.sh/chart: {{ include "rabbitmq.chart" . }}
app.kubernetes.io/name: {{ include "rabbitmq.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "rabbitmq.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rabbitmq.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/* Merge common annotations with resource-specific annotations. */}}
{{- define "rabbitmq.renderAnnotations" -}}
{{- $specific := default dict .specific -}}
{{- $annotations := mergeOverwrite (deepCopy (default dict .root.Values.commonAnnotations)) $specific -}}
{{- with $annotations }}
annotations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "rabbitmq.validateAll" -}}
{{- if hasKey .Values.podLabels "app.kubernetes.io/name" -}}
  {{- fail "podLabels must not override the app.kubernetes.io/name selector label" -}}
{{- end -}}
{{- if hasKey .Values.podLabels "app.kubernetes.io/instance" -}}
  {{- fail "podLabels must not override the app.kubernetes.io/instance selector label" -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.secretName" -}}
{{- if .Values.auth.existingSecret -}}
{{- .Values.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-auth" (include "rabbitmq.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "rabbitmq.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.headlessServiceName" -}}
{{- printf "%s-headless" (include "rabbitmq.fullname" .) -}}
{{- end -}}

{{- define "rabbitmq.configurationName" -}}
{{- printf "%s-config" (include "rabbitmq.fullname" .) -}}
{{- end -}}

{{- define "rabbitmq.tlsSecretName" -}}
{{- .Values.tls.existingSecret -}}
{{- end -}}

{{- define "rabbitmq.replicaCount" -}}
{{- if eq .Values.architecture "cluster" -}}
{{- .Values.cluster.replicaCount | int -}}
{{- else -}}
1
{{- end -}}
{{- end -}}

{{- define "rabbitmq.password" -}}
{{- $secretName := include "rabbitmq.secretName" . -}}
{{- if .Values.auth.existingSecret -}}
{{- "" -}}
{{- else -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing (hasKey $existing.data "rabbitmq-password") -}}
{{- index $existing.data "rabbitmq-password" | b64dec -}}
{{- else if .Values.auth.password -}}
{{- .Values.auth.password -}}
{{- else -}}
{{- randAlphaNum 24 -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.username" -}}
{{- $secretName := include "rabbitmq.secretName" . -}}
{{- if .Values.auth.existingSecret -}}
{{- "" -}}
{{- else -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing (hasKey $existing.data "rabbitmq-username") -}}
{{- index $existing.data "rabbitmq-username" | b64dec -}}
{{- else -}}
{{- .Values.auth.username -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.erlangCookie" -}}
{{- $secretName := include "rabbitmq.secretName" . -}}
{{- if .Values.auth.existingSecret -}}
{{- "" -}}
{{- else -}}
{{- $existing := lookup "v1" "Secret" .Release.Namespace $secretName -}}
{{- if and $existing (hasKey $existing.data "rabbitmq-erlang-cookie") -}}
{{- index $existing.data "rabbitmq-erlang-cookie" | b64dec -}}
{{- else if .Values.auth.erlangCookie -}}
{{- .Values.auth.erlangCookie -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "rabbitmq.plugins" -}}
{{- $plugins := list -}}
{{- if .Values.management.enabled -}}
{{- $plugins = append $plugins "rabbitmq_management" -}}
{{- end -}}
{{- if .Values.metrics.enabled -}}
{{- $plugins = append $plugins "rabbitmq_prometheus" -}}
{{- end -}}
{{- if eq .Values.architecture "cluster" -}}
{{- $plugins = append $plugins "rabbitmq_peer_discovery_k8s" -}}
{{- end -}}
{{- range .Values.plugins.extra }}
{{- if not (has . $plugins) -}}
{{- $plugins = append $plugins . -}}
{{- end -}}
{{- end -}}
[{{ join "," $plugins }}].
{{- end -}}

{{- define "rabbitmq.nodenameSuffix" -}}
{{- printf ".%s.%s.svc.%s" (include "rabbitmq.headlessServiceName" .) .Release.Namespace .Values.clusterDomain -}}
{{- end -}}

{{- define "rabbitmq.serverAdditionalErlArgs" -}}
{{- $args := list -}}
{{- if .Values.runtime.disableSchedulerBusyWait -}}
{{- $args = append $args "+sbwt none +sbwtdcpu none +sbwtdio none" -}}
{{- end -}}
{{- with .Values.runtime.additionalErlArgs -}}
{{- $args = append $args . -}}
{{- end -}}
{{- join " " $args -}}
{{- end -}}

{{- define "rabbitmq.probePortName" -}}
{{- if and .Values.tls.enabled .Values.tls.disableNonTLSListeners -}}
amqps
{{- else -}}
amqp
{{- end -}}
{{- end -}}

{{/*
Merge security defaults in the template so they also apply when Helm
--reuse-values carries forward the previous chart's empty context maps.
Explicit keys from the release values always win.
*/}}
{{- define "rabbitmq.podSecurityContext" -}}
{{- $defaults := dict
  "runAsUser" 100
  "runAsGroup" 101
  "fsGroup" 101
  "fsGroupChangePolicy" "OnRootMismatch"
  "seccompProfile" (dict "type" "RuntimeDefault")
-}}
{{- toYaml (mergeOverwrite (deepCopy $defaults) (default (dict) .Values.podSecurityContext)) -}}
{{- end -}}

{{- define "rabbitmq.securityContext" -}}
{{- $defaults := dict
  "runAsNonRoot" true
  "allowPrivilegeEscalation" false
  "readOnlyRootFilesystem" true
  "capabilities" (dict "drop" (list "ALL"))
-}}
{{- toYaml (mergeOverwrite (deepCopy $defaults) (default (dict) .Values.securityContext)) -}}
{{- end -}}

{{- define "rabbitmq.ingressPortName" -}}
{{- if and .Values.tls.enabled .Values.management.ingress.useTlsPort -}}
management-tls
{{- else -}}
management
{{- end -}}
{{- end -}}
