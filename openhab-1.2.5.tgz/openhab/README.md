# openHAB

Production-ready openHAB home automation platform for Kubernetes.

openHAB is an open-source home automation platform that integrates with hundreds
of smart home technologies and provides a unified interface for all your devices.

> **Note**: openHAB does not support horizontal scaling. This chart deploys a
> single instance backed by three persistent volumes.

## Installation

### Using HTTPS Repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install my-openhab helmforge/openhab
```

### Using OCI Repository

```bash
helm install my-openhab oci://ghcr.io/helmforgedev/helm/openhab --version 0.1.0
```

## Quick Start

### Minimal Installation

```bash
helm install my-openhab helmforge/openhab
```

After installation, port-forward and open the setup wizard:

```bash
kubectl port-forward svc/my-openhab 8080:8080
# Open http://127.0.0.1:8080 and complete the admin setup wizard
```

### With Ingress

```bash
helm install my-openhab helmforge/openhab \
  --set ingress.enabled=true \
  --set ingress.ingressClassName=nginx \
  --set "ingress.hosts[0].host=openhab.myhouse.com" \
  --set "ingress.hosts[0].paths[0].path=/" \
  --set "ingress.hosts[0].paths[0].pathType=Prefix"
```

### With GitOps Configuration (ConfigMaps)

```yaml
# values.yaml
configMaps:
  sitemaps:
    enabled: true
    files:
      myhome.sitemap: |
        sitemap myhome label="My Home" {
          Frame label="Lights" {
            Switch item=Light_Living label="Living Room"
          }
        }
  items:
    enabled: true
    files:
      lights.items: |
        Switch Light_Living "Living Room" <light>
```

```bash
helm install my-openhab helmforge/openhab -f values.yaml
```

## Features

- Single-instance StatefulSet with stable PVC attachment
- Three persistent volumes (userdata, conf, addons) with configurable sizes
- ConfigMap-based startup sync for sitemaps, things, and items into the writable conf PVC
- Correct security context (`fsGroup: 9001`; `runAsUser`/`runAsGroup` intentionally unset — entrypoint manages privilege drop via gosu)
- Capability-free, non-escalating helper containers with read-only root filesystems
- Startup/liveness/readiness probes via `/rest/uuid` (returns 200, no auth required)
- Optional Ingress with websocket annotation guidance for `/rest/events`
- Optional Gateway API HTTPRoute for shared Gateway deployments
- Optional Karaf SSH admin console (port 8101)
- Namespace override support for pre-created operational namespaces
- Optional admin credentials Secret
- Prometheus metrics via `/rest/metrics/prometheus` (pod annotations + ServiceMonitor)
- Automated S3 backup via CronJob (tar + MinIO client)
- Fail-fast validation (replicaCount must be 1)

## Configuration

### Profile Presets

openHAB does not support clustering, so this chart does not use profile presets.
Use feature flags instead to enable optional components.

### Key Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.tag` | openHAB image tag | `5.2.4` |
| `image.repository` | Image repository | `docker.io/openhab/openhab` |
| `replicaCount` | Must be 1 — no clustering support | `1` |
| `namespaceOverride` | Namespace for chart-managed resources | `""` |
| `commonAnnotations` | Annotations added to every chart-managed resource | `{}` |
| `serviceAccount.automountServiceAccountToken` | Mount Kubernetes API token into the pod | `false` |
| `podSecurityContext.fsGroup` | fsGroup for PVC ownership after privilege drop | `9001` |
| `podSecurityContext.seccompProfile.type` | Pod seccomp profile | `RuntimeDefault` |
| `securityContext.allowPrivilegeEscalation` | Prevent privilege escalation in the application container | `false` |
| `securityContext.readOnlyRootFilesystem` | Remains writable for openHAB OSGi/Karaf runtime state | `false` |
| `securityContext.capabilities.drop` | Drop the ambient Linux capability set | `[ALL]` |
| `securityContext.capabilities.add` | Entrypoint bootstrap capabilities | `[CHOWN, DAC_OVERRIDE, FOWNER, SETGID, SETUID]` |
| `service.type` | Service type | `ClusterIP` |
| `service.port` | HTTP port | `8080` |
| `service.ipFamilyPolicy` | HTTP Service dual-stack policy | `""` |
| `service.ipFamilies` | HTTP Service IP families | `[]` |
| `ingress.enabled` | Enable Ingress | `false` |
| `ingress.ingressClassName` | Ingress class name | `""` |
| `env.TZ` | Timezone | `UTC` |
| `env.EXTRA_JAVA_OPTS` | Extra JVM options | `""` |
| `karaf.enabled` | Enable Karaf SSH console | `false` |
| `karaf.service.ipFamilyPolicy` | Karaf Service dual-stack policy | `""` |
| `karaf.service.ipFamilies` | Karaf Service IP families | `[]` |
| `admin.secretEnabled` | Create admin credentials Secret | `false` |

### Gateway API Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `gateway.enabled` | Enable HTTPRoute creation | `false` |
| `gateway.hostnames` | HTTPRoute hostnames | `[openhab.local]` |
| `gateway.parentRefs` | Parent Gateway references | `[]` |

### Persistence Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `persistence.userdata.enabled` | Enable userdata PVC | `true` |
| `persistence.userdata.size` | userdata PVC size | `5Gi` |
| `persistence.userdata.storageClass` | Storage class | `""` (cluster default) |
| `persistence.userdata.existingClaim` | Use existing PVC | `""` |
| `persistence.userdata.subPath` | Relative directory in the userdata PVC | `""` |
| `persistence.conf.enabled` | Enable conf PVC | `true` |
| `persistence.conf.size` | conf PVC size | `1Gi` |
| `persistence.conf.existingClaim` | Use existing PVC | `""` |
| `persistence.conf.subPath` | Relative directory in the conf PVC | `""` |
| `persistence.addons.enabled` | Enable addons PVC | `true` |
| `persistence.addons.size` | addons PVC size | `2Gi` |
| `persistence.addons.existingClaim` | Use existing PVC | `""` |
| `persistence.addons.subPath` | Relative directory in the addons PVC | `""` |

> **Warning:** A new PVC may contain a `lost+found` directory at its root.
> openHAB then does not recognize the mounted directory as empty on its first
> start, skips initialization, and fails to start. Use a dedicated, empty
> `subPath` instead of mounting the PVC root in this case.

### ConfigMap Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `configMaps.sitemaps.enabled` | Enable sitemaps ConfigMap | `false` |
| `configMaps.sitemaps.files` | Map of filename → content | `{}` |
| `configMaps.things.enabled` | Enable things ConfigMap | `false` |
| `configMaps.things.files` | Map of filename → content | `{}` |
| `configMaps.items.enabled` | Enable items ConfigMap | `false` |
| `configMaps.items.files` | Map of filename → content | `{}` |
| `configMaps.syncImage.tag` | BusyBox tag used by the ConfigMap sync init container | `1.37` |
| `configMaps.syncResources` | Resource guardrails for the ConfigMap sync init container | requests/limits set |

### Metrics Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `metrics.enabled` | Enable Prometheus metrics support | `false` |
| `metrics.podAnnotations.enabled` | Add `prometheus.io/*` pod annotations | `true` |
| `metrics.serviceMonitor.enabled` | Create ServiceMonitor for Prometheus Operator | `false` |
| `metrics.serviceMonitor.namespace` | ServiceMonitor namespace | release namespace |
| `metrics.serviceMonitor.interval` | Scrape interval | `60s` |
| `metrics.serviceMonitor.scrapeTimeout` | Scrape timeout | `10s` |
| `metrics.serviceMonitor.additionalLabels` | Extra labels on ServiceMonitor | `{}` |

### Backup Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `backup.enabled` | Enable automated backup CronJob | `false` |
| `backup.schedule` | Cron schedule | `0 3 * * *` |
| `backup.suspend` | Suspend the CronJob | `false` |
| `backup.concurrencyPolicy` | CronJob concurrency policy | `Forbid` |
| `backup.successfulJobsHistoryLimit` | Successful job history to retain | `3` |
| `backup.failedJobsHistoryLimit` | Failed job history to retain | `3` |
| `backup.backoffLimit` | Job backoff limit | `1` |
| `backup.archivePrefix` | Archive filename prefix | `openhab` |
| `backup.serviceAccount.create` | Create a dedicated backup ServiceAccount | `true` |
| `backup.serviceAccount.automountServiceAccountToken` | Mount the Kubernetes API token in backup pods | `false` |
| `backup.serviceAccount.annotations` | Backup ServiceAccount annotations (for example, an IRSA role) | `{}` |
| `backup.serviceAccount.name` | Backup ServiceAccount name override | `""` |
| `backup.include.userdata` | Back up `/openhab/userdata` | `true` |
| `backup.include.conf` | Back up `/openhab/conf` | `true` |
| `backup.images.utility.repository` | Backup utility image | `docker.io/library/alpine` |
| `backup.images.utility.tag` | Backup utility tag | `3.22` |
| `backup.images.uploader.repository` | S3 uploader image | `docker.io/helmforge/mc` |
| `backup.images.uploader.tag` | S3 uploader tag | `1.0.0` |
| `backup.resources` | Resource requests/limits for backup containers | requests/limits set |
| `backup.s3.endpoint` | S3-compatible endpoint URL | `""` |
| `backup.s3.bucket` | Target bucket name | `""` |
| `backup.s3.prefix` | Key prefix within the bucket | `openhab` |
| `backup.s3.region` | AWS region used by Pod Identity or IRSA | `""` |
| `backup.s3.accessKey` | S3 access key | `""` |
| `backup.s3.secretKey` | S3 secret key | `""` |
| `backup.s3.existingSecret` | Existing Secret name (keys: `access-key`, `secret-key`) | `""` |
| `backup.s3.credentialsFromPodIdentity` | Use EKS Pod Identity or IRSA instead of static credentials | `false` |

## Prometheus Metrics

openHAB exposes Prometheus metrics via the **Metrics addon** at:

```text
GET /rest/metrics/prometheus   (port 8080, no authentication required)
```

**Step 1** — Install the Metrics addon in openHAB:
*Settings → Add-on Store → Integrations → Metrics*

**Step 2** — Enable metrics in chart values:

```yaml
# Annotation-based scraping (works without Prometheus Operator)
metrics:
  enabled: true
  podAnnotations:
    enabled: true

# --- OR ---

# Prometheus Operator (ServiceMonitor)
metrics:
  enabled: true
  podAnnotations:
    enabled: false
  serviceMonitor:
    enabled: true
    interval: 60s
    additionalLabels:
      release: prometheus   # must match your Prometheus selector
```

**Metrics exposed**: openHAB events (per topic), bundle states, thing states,
rule executions, threadpool statistics, JVM metrics (memory, GC, threads).

See [Prometheus Metrics Guide](docs/metrics.md) for full details.

## Upgrade Notes

openHAB `5.2.4` includes the security fixes introduced in `5.2.2`, plus fixes
for authentication through openHAB Cloud and reverse proxies and the Main UI
map tile provider. Back up the `userdata`, `conf`, and `addons` PVCs before
upgrading. openHAB 5.x still requires Java 21, which is provided by the official
container image used by this chart.

This upgrade changes security-sensitive behavior. Configure the Sitemap
`allowedHosts` setting for every host used through the `/proxy` endpoint; the
new allowlist is empty by default. Reassess `trustedNetworks` behind a reverse
proxy because it now uses the actual client address and no longer trusts
`X-Forwarded-For`. Third-party OAuth2 clients using `/auth` must use a same-origin
redirect URI and PKCE `S256`. IP Camera binding users whose ONVIF events arrive
through NAT or a proxy must add those source addresses to `ipWhitelist`.

### Security Scan: openhab

| Framework          | Score   |
| ------------------ | ------- |
| MITRE + NSA + SOC2 | **88%** |

Security posture: acceptable with documented openHAB runtime exceptions for
root bootstrap, writable runtime filesystem, and network policy delegation.

## Examples

- [Simple Deployment](examples/simple.yaml)
- [With Ingress + TLS](examples/with-ingress.yaml)
- [With ConfigMaps (GitOps)](examples/with-configmaps.yaml)
- [Full Production](examples/production.yaml)

## Automated Backup

The chart includes an optional CronJob that archives your openHAB data and uploads it to any S3-compatible storage using the MinIO client.

```yaml
backup:
  enabled: true
  schedule: "0 3 * * *"
  s3:
    endpoint: "https://minio.example.com"
    bucket: "openhab-backups"
    prefix: "prod"
    accessKey: "AKIAEXAMPLE"
    secretKey: "supersecretkey"
```

To avoid storing credentials in values, use an existing Secret:

```yaml
backup:
  enabled: true
  s3:
    endpoint: "https://minio.example.com"
    bucket: "openhab-backups"
    existingSecret: "my-s3-credentials"   # keys: access-key, secret-key
```

For IRSA, annotate the dedicated backup ServiceAccount and enable ambient
credentials:

```yaml
backup:
  enabled: true
  serviceAccount:
    annotations:
      eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/openhab-backup
  s3:
    endpoint: "https://s3.amazonaws.com"
    bucket: "openhab-backups"
    region: "us-east-1"
    credentialsFromPodIdentity: true
```

For EKS Pod Identity, keep the same S3 values but omit the ServiceAccount role
annotation. Install the EKS Pod Identity Agent and create an association for
the rendered backup ServiceAccount. For release `my-openhab`, the default name
is `my-openhab-backup`:

```bash
aws eks create-pod-identity-association \
  --cluster-name <cluster-name> \
  --namespace <namespace> \
  --service-account my-openhab-backup \
  --role-arn <role-arn>
```

If `fullnameOverride` or `backup.serviceAccount.name` is set, use the
ServiceAccount name rendered by the chart instead.

See [Automated Backup Guide](docs/backup.md) for full details including restore instructions.

## Architecture Guides

- [ConfigMaps & Startup Sync](docs/configmaps-startup-sync.md)
- [Storage](docs/storage.md)
- [Security](docs/security.md)
- [Prometheus Metrics](docs/metrics.md)
- [Automated Backup](docs/backup.md)

## First Boot — Admin Setup

openHAB does not support injecting admin credentials via environment variables.
On first boot, navigate to the web UI and complete the setup wizard to create
your administrator account.

Credentials are stored persistently in `/openhab/userdata/jsondb/auth.json`.

## Startup Time

openHAB loads OSGi bundles at startup. Expect:

- **First boot**: 60-120 seconds
- **Subsequent starts**: 30-60 seconds (warm cache)

The chart configures a startup probe with a 10-minute window to accommodate this.

## Ingress & WebSocket

openHAB's `/rest/events` endpoint uses Server-Sent Events (SSE). When using
nginx Ingress, add these annotations for proper websocket/SSE support:

```yaml
ingress:
  annotations:
    nginx.ingress.kubernetes.io/proxy-read-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-http-version: "1.1"
    nginx.ingress.kubernetes.io/configuration-snippet: |
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
```

## Non-Goals

This chart intentionally does NOT:

- Support multiple replicas (openHAB does not support clustering)
- Automatically inject admin credentials (not supported by openHAB)
- Manage openHAB addon installation (use the web UI or Karaf console)

## Contributing

See [CONTRIBUTING.md](../../CONTRIBUTING.md)
