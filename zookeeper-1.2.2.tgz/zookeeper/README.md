# Apache ZooKeeper

Apache ZooKeeper for Kubernetes using the official `docker.io/library/zookeeper` image.

This chart deploys a stable StatefulSet ensemble with explicit quorum ports, a client Service, optional secure client port,
Prometheus metrics, NetworkPolicy, PDB, External Secrets, and dual-stack Service fields.

## Install

### HTTPS repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install zookeeper helmforge/zookeeper -f values.yaml
```

### OCI registry

```bash
helm install zookeeper oci://ghcr.io/helmforgedev/helm/zookeeper -f values.yaml
```

## Features

- official Apache ZooKeeper image with pinned `3.9.6` default tag
- replicated StatefulSet ensemble with stable pod DNS
- default three-node quorum and validation against accidental even replica counts
- standalone development mode with `replicaCount: 1`
- client, headless, and metrics Services with optional dual-stack fields
- optional Prometheus metrics provider, `ServiceMonitor`, and `PrometheusRule`
- optional SASL/Digest client authentication with generated or existing JAAS Secret
- optional secure client port using existing JKS keystore and truststore Secrets
- optional External Secrets Operator v1 integration for credential material
- optional NetworkPolicy for quorum, client, metrics, and DNS flows
- PDB, hardened container security context, explicit probes, and extension hooks

## Topologies

| Topology | Values | Typical Use |
|----------|--------|-------------|
| Ensemble | `replicaCount: 3` | Production and shared platform workloads that need quorum durability. |
| Standalone | `replicaCount: 1` | Local development, CI, and non-critical tests. |

Keep production replica counts odd. The chart blocks even replica counts unless `allowEvenReplicas=true` is set deliberately.

## Upgrade notes for 3.9.6

ZooKeeper 3.9.6 is an upstream bugfix and security release. It updates Netty to
address reported vulnerabilities, prevents metrics logging from exposing
keystore and truststore passwords, fixes C-client and Kerberos thread leaks,
restores custom TLS context and FIPS startup paths, and improves shutdown and
CLI behavior. No chart contract change is required for the 3.9.5 to 3.9.6
upgrade, but back up snapshots and transaction logs and verify quorum health
before and after rolling the ensemble.

See the [Apache ZooKeeper 3.9.6 release notes](https://zookeeper.apache.org/doc/r3.9.6/releasenotes.html)
for the complete upstream issue list.

## Quick Start

Ephemeral standalone:

```yaml
replicaCount: 1
persistence:
  enabled: false
```

Production-oriented ensemble:

```yaml
replicaCount: 3

persistence:
  enabled: true
  size: 20Gi
  dataLogDir:
    enabled: true
    size: 10Gi

podDisruptionBudget:
  enabled: true
  maxUnavailable: 1

networkPolicy:
  enabled: true
  egress:
    allowSameNamespace: true

metrics:
  enabled: true
  serviceMonitor:
    enabled: true
```

## Example Configurations

- [`examples/standalone.yaml`](examples/standalone.yaml) provides an ephemeral single-node development deployment.
- [`examples/production.yaml`](examples/production.yaml) provides a persistent three-node ensemble with quorum-safe disruption settings.
- [`examples/monitoring.yaml`](examples/monitoring.yaml) enables the Prometheus provider, ServiceMonitor, and alert rules.

Review every example against the target cluster's StorageClass, failure domains, security policy, and monitoring labels
before production use.

## Client Endpoint

Use the client Service for applications:

```text
zookeeper.<namespace>.svc.cluster.local:2181
```

StatefulSet pods also have stable DNS names:

```text
zookeeper-0.zookeeper-headless.<namespace>.svc.cluster.local
zookeeper-1.zookeeper-headless.<namespace>.svc.cluster.local
zookeeper-2.zookeeper-headless.<namespace>.svc.cluster.local
```

## Metrics

ZooKeeper 3.9 includes a Prometheus metrics provider. Enable it with:

```yaml
metrics:
  enabled: true
  serviceMonitor:
    enabled: true
  prometheusRule:
    enabled: true
```

Metrics are exposed on `/metrics` through the metrics Service.

## Architecture Guides

- [Design](DESIGN.md)
- [Operations](docs/operations.md)
- [Security](docs/security.md)
- [Observability](docs/observability.md)

## Authentication

SASL/Digest client authentication is optional.

```yaml
auth:
  client:
    enabled: true
    username: app
    password: change-me
```

Existing JAAS Secret:

```yaml
auth:
  client:
    enabled: true
    existingSecret: zookeeper-jaas
    existingSecretJaasKey: jaas.conf
```

The JAAS key should contain a ZooKeeper `Server` login context.

## TLS

The chart supports ZooKeeper's secure client port with existing JKS material.

```yaml
tls:
  client:
    enabled: true
    port: 3181
    existingSecret: zookeeper-client-tls
    keystoreKey: zookeeper.keystore.jks
    truststoreKey: zookeeper.truststore.jks
    keystorePassword: changeit
    truststorePassword: changeit
```

The chart does not generate private keys or truststores.

## External Secrets

External Secrets Operator integration uses `external-secrets.io/v1`.

```yaml
auth:
  client:
    enabled: true

externalSecrets:
  enabled: true
  secretStoreRef:
    name: platform-secrets
    kind: ClusterSecretStore
  data:
    - secretKey: jaas.conf
      remoteRef:
        key: zookeeper/jaas
```

When SASL client auth and TLS are enabled together, the default ExternalSecret target is the auth Secret.
Include `jaas.conf`, `keystore-password`, and `truststore-password` in `externalSecrets.data`, or set
`externalSecrets.target.name` to a shared Secret name.
When `auth.client.existingSecret` is set, the default ExternalSecret target remains the TLS password Secret so the
chart does not mutate the user-managed JAAS Secret.

## Dual Stack

Dual-stack Service fields are available across headless, client, and metrics Services:

```yaml
service:
  ipFamilyPolicy: PreferDualStack
```

Omit `service.ipFamilies` with `PreferDualStack` when the target cluster may be single-stack; Kubernetes rejects
explicit families that the cluster does not advertise. Set `service.ipFamilies` only on clusters configured for the
listed families.

## Main Values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of ZooKeeper servers | `3` |
| `allowEvenReplicas` | Permit even replica counts | `false` |
| `image.repository` | ZooKeeper image repository | `docker.io/library/zookeeper` |
| `image.tag` | ZooKeeper image tag | `3.9.6` |
| `zookeeper.tickTime` | ZooKeeper tick time in milliseconds | `2000` |
| `zookeeper.initLimit` | ZooKeeper init limit | `10` |
| `zookeeper.syncLimit` | ZooKeeper sync limit | `5` |
| `zookeeper.fourLetterWordWhitelist` | Four-letter-word command whitelist | `srvr,stat,ruok,mntr,conf,isro` |
| `service.ipFamilyPolicy` | Service IP family policy | `""` |
| `service.ipFamilies` | Ordered Service IP families | `[]` |
| `persistence.enabled` | Create data PVCs | `true` |
| `persistence.dataLogDir.enabled` | Create a separate transaction log PVC | `false` |
| `auth.client.enabled` | Enable SASL/Digest client authentication | `false` |
| `tls.client.enabled` | Enable secure client port | `false` |
| `metrics.enabled` | Enable Prometheus metrics provider | `false` |
| `metrics.serviceMonitor.enabled` | Create ServiceMonitor | `false` |
| `metrics.prometheusRule.enabled` | Create PrometheusRule | `false` |
| `networkPolicy.enabled` | Create NetworkPolicy | `false` |
| `networkPolicy.egress.allowSameNamespace` | Allow same-namespace egress on client/admin/metrics ports | `false` |
| `externalSecrets.enabled` | Create ExternalSecret | `false` |

## Troubleshooting

If pods do not form quorum, confirm that the replica count is odd, every pod can resolve the headless Service, and TCP
ports 2888 and 3888 are allowed between ensemble members. Check `kubectl logs` on every ordinal because the elected
leader may not be pod zero.

If clients cannot connect, verify the client Service endpoints and match the client authentication and TLS settings to
the application. SASL clients need the configured username and JAAS password; TLS clients need a truststore that trusts
the certificate mounted by `tls.client.existingSecret`.

If a pod cannot remount existing data after scheduling changes, inspect PVC binding, StorageClass topology, file
ownership, and the configured `podSecurityContext.fsGroup`. Do not delete PVCs while diagnosing quorum or recovery.

See [`docs/operations.md`](docs/operations.md), [`docs/security.md`](docs/security.md), and
[`docs/observability.md`](docs/observability.md) for operational commands and production checks.

## CI Scenarios

The `ci/` directory covers:

- `standalone.yaml`
- `metrics.yaml`
- `dual-stack.yaml`
- `auth.yaml`
- `tls.yaml`
- `network-policy.yaml`
- `external-secrets.yaml`

## Security Scan

### Security Scan: `zookeeper`

| Framework | Score |
|-----------|-------|
| MITRE + NSA + SOC2 | **84.34343%** |

Security posture acceptable.

## References

- [Apache ZooKeeper](https://zookeeper.apache.org)
- [Apache ZooKeeper Administrator's Guide](https://zookeeper.apache.org/doc/current/zookeeperAdmin.html)
- [Apache ZooKeeper Getting Started](https://zookeeper.apache.org/doc/current/zookeeperStarted.html)
- [ZooKeeper releases](https://zookeeper.apache.org/releases.html)
- [ZooKeeper 3.9.6 release notes](https://zookeeper.apache.org/doc/r3.9.6/releasenotes.html)
- [Official Docker image](https://hub.docker.com/_/zookeeper)
