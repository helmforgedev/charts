# ArchiveBox Helm Chart

Deploy [ArchiveBox](https://archivebox.io) on Kubernetes using the official
[archivebox/archivebox](https://hub.docker.com/r/archivebox/archivebox)
container image.

ArchiveBox is a self-hosted web archiving platform that captures websites in
multiple formats, including HTML, PDF, PNG, WARC, and media, using Chromium
headless.

## Features

- **Multi-format archiving** - HTML, PDF, screenshot, WARC, media extraction
- **Chromium headless** - full page rendering with `/dev/shm` tmpfs
- **SQLite embedded** - no external database needed
- **Persistent storage** - archived content and SQLite database on PVC
- **Admin credentials** - managed via Kubernetes Secret
- **Ingress support** - TLS with cert-manager
- **S3-compatible backups** - optional CronJob for `/data` archives

## Installation

**HTTPS repository:**

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install archivebox helmforge/archivebox -f values.yaml
```

**OCI registry:**

```bash
helm install archivebox oci://ghcr.io/helmforgedev/helm/archivebox -f values.yaml
```

## Basic Example

```yaml
# values.yaml
archivebox:
  adminUsername: admin
  adminPassword: "your-secure-password"
```

After deploying:

```bash
kubectl port-forward svc/<release>-archivebox 8000:80
# Open http://localhost:8000
```

## Architecture Guides

- [Chart design](DESIGN.md)
- [Runtime architecture](docs/architecture.md)
- [Backup guide](docs/backup.md)

## Examples

- [Minimal local installation](examples/simple.yaml)
- [Ingress with TLS](examples/ingress.yaml)
- [Scheduled S3 backup](examples/s3-backup.yaml)

## Using an Existing Secret

```yaml
archivebox:
  existingSecret: my-archivebox-secret
  existingSecretUsernameKey: admin-username
  existingSecretPasswordKey: admin-password
```

## Key Values

| Key | Default | Description |
|-----|---------|-------------|
| `archivebox.port` | `5797` | Application port |
| `archivebox.adminUsername` | `admin` | Admin username |
| `archivebox.adminPassword` | `""` | Admin password (auto-generated if empty) |
| `archivebox.allowedHosts` | `*` | Allowed hostnames |
| `archivebox.publicIndex` | `True` | Public index page |
| `archivebox.publicSnapshots` | `True` | Public snapshot access |
| `archivebox.searchBackendEngine` | `ripgrep` | Search engine (ripgrep, sqlite, sonic) |
| `archivebox.mediaMaxSize` | `750m` | Max media download size |
| `archivebox.timeout` | `60` | URL archiving timeout (seconds) |
| `persistence.enabled` | `true` | Enable persistence for /data |
| `persistence.size` | `50Gi` | PVC size (plan for large archives) |
| `ingress.enabled` | `false` | Enable ingress |
| `service.port` | `80` | Service port |
| `backup.enabled` | `false` | Enable scheduled S3-compatible backup |
| `backup.schedule` | `0 3 * * *` | Backup CronJob schedule |

## Security Scan

ArchiveBox 0.9 requires `/data` to be owned by UID/GID 911. A narrowly scoped
init container applies ownership to the mount root; the application container
then starts and remains non-root as UID/GID 911.

Security Scan:

Kubescape scan for `MITRE,NSA,SOC2` during this standards backfill:

| Framework | Score |
|-----------|-------|
| MITRE | 100.00% |
| NSA | 65.00% |
| SOC2 | 80.00% |
| Aggregate resource score | 75.76% |

Expected follow-up hardening is operator-dependent:

- Set explicit CPU and memory requests and limits for the ArchiveBox workload.
- Add namespace-level NetworkPolicy where the platform requires restricted
  ingress and egress.
- Use an existing Secret for admin and S3 credentials in production.

## Limitations

- **Single instance only** - SQLite is single-writer; horizontal scaling is not
  supported
- **Storage-heavy** - each archived snapshot is commonly 2-50MB; plan PVC size
  accordingly
- **Chromium resources** - requires at least 2Gi RAM for Chromium headless
  rendering
- **`/dev/shm`** - automatically mounted as memory-backed tmpfs for Chromium

## More Information

- [ArchiveBox documentation](https://docs.archivebox.io)
- [Source code](https://github.com/helmforgedev/charts/tree/main/charts/archivebox)

<!-- @AI-METADATA
type: chart-readme
title: ArchiveBox Helm Chart
description: README for the ArchiveBox web archiving platform Helm chart

keywords: archivebox, archive, web-archiving, chromium, wayback, self-hosted

purpose: Chart installation, configuration, and usage documentation
scope: Chart

relations:
  - charts/archivebox/values.yaml
path: charts/archivebox/README.md
version: 1.0
date: 2026-04-01
-->
