# RabbitMQ

RabbitMQ for Kubernetes with explicit `single-node` and `cluster` modes, optional Management UI, optional TLS, optional metrics, and dedicated operational docs for each architecture.

## Install

### HTTPS repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install rabbitmq helmforge/rabbitmq -f values.yaml
```

### OCI registry

```bash
helm install rabbitmq oci://ghcr.io/helmforgedev/helm/rabbitmq -f values.yaml
```

## Supported architectures

| Architecture | When to use | Document |
|-------------|-------------|----------|
| `single-node` | simple environments, development, staging, and workloads without broker-node failover requirements | [docs/single-node.md](docs/single-node.md) |
| `cluster` | production with multiple nodes, quorum queues, and broker redundancy | [docs/cluster.md](docs/cluster.md) |

## What this chart covers

- explicit architecture selection through `architecture`
- authentication with username, password, and Erlang cookie
- `existingSecret` for credentials managed outside the chart
- transparent `rabbitmq.conf` and `enabled_plugins` modeling
- optional Management UI
- optional TLS for AMQP and Management UI
- optional metrics through the native RabbitMQ Prometheus plugin
- optional `ServiceMonitor`
- optional `PodDisruptionBudget`
- Ingress support for the Management UI with configurable `ingressClassName`
- Gateway API HTTPRoute support for the Management UI
- dual-stack Service fields through `service.ipFamilyPolicy` and `service.ipFamilies`
- External Secrets Operator support for RabbitMQ credentials
- official Alpine RabbitMQ image by default; plugins are controlled by chart values

## How to choose the architecture

- use `single-node` when operational simplicity matters more than broker redundancy
- use `cluster` when queues must survive node loss and the application already handles multi-broker reconnect correctly

Recommended reading before installation:

- [Single Node](docs/single-node.md)
- [Cluster](docs/cluster.md)

## Official product references

- RabbitMQ Downloads: <https://www.rabbitmq.com/docs/download>
- RabbitMQ Cluster Formation: <https://www.rabbitmq.com/docs/cluster-formation>
- RabbitMQ Quorum Queues: <https://www.rabbitmq.com/quorum-queues.html>
- RabbitMQ TLS: <https://www.rabbitmq.com/docs/ssl>

## Operational direction

- for production, the recommended mode is `cluster` with `queueDefaults.type=quorum`
- use `single-node` only when broker-level HA is not a requirement
- do not treat a RabbitMQ cluster as a substitute for good queue design, routing, or consumer reconnect behavior

## Quick start

Minimal example:

```yaml
architecture: single-node

auth:
  existingSecret: rabbitmq-auth

singleNode:
  persistence:
    enabled: true
    size: 8Gi
```

Cluster example:

```yaml
architecture: cluster

auth:
  existingSecret: rabbitmq-auth

queueDefaults:
  type: quorum

cluster:
  replicaCount: 3
  persistence:
    enabled: true
    size: 20Gi

metrics:
  enabled: true
  serviceMonitor:
    enabled: true
```

Management UI ingress example:

```yaml
management:
  ingress:
    enabled: true
    ingressClassName: traefik
    hosts:
      - host: rabbitmq.example.com
        paths:
          - path: /
            pathType: Prefix
```

Management UI Gateway API example:

```yaml
management:
  enabled: true
  gateway:
    enabled: true
    parentRefs:
      - name: public
        namespace: gateway-system
    hostnames:
      - rabbitmq.example.com
```

External Secrets example:

```yaml
auth:
  existingSecret: rabbitmq-credentials

externalSecrets:
  enabled: true
  secretStoreRef:
    name: platform-secrets
    kind: ClusterSecretStore
  data:
    - secretKey: rabbitmq-username
      remoteRef:
        key: rabbitmq/auth
        property: username
    - secretKey: rabbitmq-password
      remoteRef:
        key: rabbitmq/auth
        property: password
    - secretKey: rabbitmq-erlang-cookie
      remoteRef:
        key: rabbitmq/auth
        property: erlang-cookie
```

## Best practices

### Security

- use `auth.existingSecret` in production
- keep the Erlang cookie stable across restarts and upgrades
- enable TLS when clients connect outside a trusted internal network boundary
- restrict Management UI exposure

### Queues and topology

- in production, prefer quorum queues over mirrored classic queues
- use `cluster` only when the application truly needs a multi-node topology
- validate client reconnect behavior before promoting the topology to production

### Scheduling

- in `cluster`, spread pods across nodes or zones
- enable `pdb.enabled=true` for production clusters
- keep `replicaCount >= 3` for the operational cluster baseline

### Observability

- enable `metrics.enabled=true` in monitored environments
- use `metrics.serviceMonitor.enabled=true` with Prometheus Operator
- monitor memory, disk, connections, queues, consumers, and node-local alarms

### Runtime efficiency

- the default image is `docker.io/library/rabbitmq:4.3.5-alpine`; it contains the management, Prometheus, and Kubernetes peer-discovery plugins, and the chart enables only the plugins requested by values
- RabbitMQ 4.3.5 fixes quorum queue recovery, AMQP 1.0 validation, rolling-upgrade queries, direct reply-to duplicates, and protocol frame limits
- `management.referrerPolicy=no-referrer` enables the upstream Referrer-Policy support with a privacy-preserving default; set it to `""` to defer to the browser default
- `runtime.disableSchedulerBusyWait=true` is enabled by default to reduce idle CPU from Erlang scheduler spin-wait in containers
- default Kubernetes probes use lightweight TCP checks against the active AMQP listener instead of recurring `rabbitmq-diagnostics` commands
- use `runtime.additionalErlArgs` for extra Erlang VM flags and reserve `extraEnv` for explicit upstream environment variables or full overrides

## Main values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `architecture` | `single-node` or `cluster` | `single-node` |
| `image.repository` | RabbitMQ image repository | `docker.io/library/rabbitmq` |
| `image.tag` | RabbitMQ image tag | `4.3.5-alpine` |
| `auth.username` | Application username | `user` |
| `auth.password` | Application password | `""` |
| `auth.erlangCookie` | Erlang cookie | `""` |
| `auth.existingSecret` | Existing secret for credentials | `""` |
| `queueDefaults.type` | `quorum` or `classic` | `quorum` |
| `management.enabled` | Enable management plugin/UI | `true` |
| `management.referrerPolicy` | Management UI Referrer-Policy header; empty uses browser default | `no-referrer` |
| `management.ingress.enabled` | Enable management ingress | `false` |
| `management.ingress.ingressClassName` | Ingress class for the Management UI | `traefik` |
| `tls.enabled` | Enable TLS listeners | `false` |
| `singleNode.persistence.enabled` | Enable PVC for single node | `true` |
| `cluster.replicaCount` | Number of cluster nodes | `3` |
| `cluster.partitionHandling` | Cluster partition handling | `pause_minority` |
| `metrics.enabled` | Enable RabbitMQ Prometheus plugin | `false` |
| `metrics.serviceMonitor.enabled` | Enable ServiceMonitor | `false` |
| `runtime.disableSchedulerBusyWait` | Disable Erlang scheduler busy-wait for lower idle CPU | `true` |
| `runtime.additionalErlArgs` | Additional Erlang VM arguments appended to chart defaults | `""` |
| `startupProbe.enabled` | Enable TCP startup probe | `true` |
| `livenessProbe.enabled` | Enable TCP liveness probe | `true` |
| `readinessProbe.enabled` | Enable TCP readiness probe | `true` |
| `pdb.enabled` | Enable PodDisruptionBudget | `false` |
| `service.ipFamilyPolicy` | Service IP family policy for dual-stack clusters | `""` |
| `management.gateway.enabled` | Render Gateway API HTTPRoute for the Management UI | `false` |
| `externalSecrets.enabled` | Render ExternalSecret for credentials | `false` |

## CI scenarios

The `ci/` scenarios validate the main chart behaviors:

- `single-node.yaml`
- `cluster.yaml`
- `secure.yaml`
- `existing-secret.yaml`
- `metrics.yaml`
- `dual-stack.yaml`
- `gateway-api.yaml`
- `external-secrets.yaml`

## Examples

See `examples/`:

- `single-node.yaml`
- `cluster-ha.yaml`
- `management-tls.yaml`
- `gateway-api.yaml`
- `external-secrets.yaml`

## Important notes

- `cluster` is not magical HA abstraction; queues, consumers, and reconnect behavior remain application and operations concerns
- quorum queues are the recommended production direction in this chart
- this chart does not attempt to orchestrate federation, shovel, or advanced policy management in v1
- `management.ingress.ingressClassName` can be set to `traefik`, `nginx`, or any ingress class available in the target cluster
- `externalSecrets.enabled=true` requires `auth.existingSecret` so the chart does not generate credentials that drift from the operator-managed Secret

### Security Scan: `rabbitmq`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **74.24%** |

> Security posture acceptable.

<!-- @AI-METADATA
type: chart-readme
title: RabbitMQ Helm Chart
description: RabbitMQ chart with single-node and cluster modes, management UI, TLS

keywords: rabbitmq, amqp, messaging, queue, cluster

purpose: Usage guide for the RabbitMQ Helm chart with single-node and cluster modes
scope: Chart

relations:
  - charts/rabbitmq/DESIGN.md
  - charts/rabbitmq/docs/single-node.md
  - charts/rabbitmq/docs/cluster.md
path: charts/rabbitmq/README.md
version: 1.1
date: 2026-06-02
-->
