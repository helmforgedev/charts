<!-- SPDX-License-Identifier: Apache-2.0 -->

# Redis Chart Design

Status: implemented and maintained

Date: 2026-05-05

## Scope

The Redis chart provides explicit, production-oriented Redis topologies without hiding operational tradeoffs behind generic StatefulSet defaults. The chart supports four runtime contracts:

- `standalone`
- `replication`
- `sentinel`
- `cluster`

Each mode renders a different Kubernetes resource model because each mode has different client behavior, failover expectations, persistence patterns, and operational risk.

## Decisions

- Make topology the first decision through `architecture`.
- Keep Redis data-plane resources separate from optional observability and extension resources.
- Prefer stable DNS names for internal Redis discovery instead of pod IPs.
- Support custom Kubernetes cluster domains through `clusterDomain`.
- Keep services dual-stack capable through `service.ipFamilyPolicy` and `service.ipFamilies`.
- Keep authentication explicit and reusable through generated Secrets, `existingSecret`, or External Secrets Operator integration.
- Use StatefulSets for Redis data nodes to preserve stable identities and storage.
- Use startup checks where Redis role discovery depends on another component becoming reachable.
- Make generated names predictable through shared helpers.
- Keep chart validation representative by covering every supported topology in CI values and unit tests.

## Topology Selection

```yaml
architecture: standalone | replication | sentinel | cluster
```

Use `standalone` for development, small environments, caches where downtime is acceptable, or single-node production scenarios with external recovery procedures.

Use `replication` when applications can read from replicas or when operators want a primary/replica layout without Sentinel-managed failover.

Use `sentinel` when applications expect a single writable primary and can integrate with Sentinel discovery/failover.

Use `cluster` when applications are Redis Cluster aware and need sharding at the Redis protocol level.

## Architecture Diagrams

### Standalone

```mermaid
flowchart LR
  Client[Client] --> Service[Redis Service]
  Service --> Pod[redis-standalone-0]
  Pod --> PVC[(Redis PVC)]
  Pod --> Config[ConfigMap]
  Pod --> Secret[Secret or existingSecret]
```

Standalone keeps the resource graph intentionally small. It is easy to operate, but it has no in-chart failover target.

### Replication

```mermaid
flowchart LR
  Client[Client] --> ClientSvc[Client Service]
  ClientSvc --> Primary[redis-primary-0]
  ReplicaSvc[Replica Headless Service] --> Replica0[redis-replica-0]
  ReplicaSvc --> Replica1[redis-replica-1]
  Replica0 --> Primary
  Replica1 --> Primary
  Primary --> PrimaryPVC[(Primary PVC)]
  Replica0 --> ReplicaPVC0[(Replica PVC)]
  Replica1 --> ReplicaPVC1[(Replica PVC)]
```

Replication separates primary and replica StatefulSets. This keeps role-specific configuration and persistence clear, and lets operators tune scheduling, resources, and storage per role.

### Sentinel

```mermaid
flowchart LR
  Client[Sentinel-aware Client] --> SentinelSvc[Sentinel Service]
  SentinelSvc --> Sentinel0[sentinel-0]
  SentinelSvc --> Sentinel1[sentinel-1]
  SentinelSvc --> Sentinel2[sentinel-2]
  Sentinel0 --> Nodes[redis-node-0..N]
  Sentinel1 --> Nodes
  Sentinel2 --> Nodes
  Nodes --> Data[(Optional per-node PVCs)]
```

Sentinel is a distinct architecture because it changes the client contract. Data nodes are role-neutral and discover the elected master through Sentinel or peer replication state.
Stable announced hostnames, graceful failover, and the startup anti-wipe guard keep topology safe across pod IP churn and voluntary disruption.

### Redis Cluster

```mermaid
flowchart LR
  Client[Cluster-aware Client] --> ClusterSvc[Cluster Client Service]
  ClusterSvc --> Node0[redis-cluster-0]
  ClusterSvc --> Node1[redis-cluster-1]
  ClusterSvc --> Node2[redis-cluster-2]
  Headless[Headless Service] --> Node0
  Headless --> Node1
  Headless --> Node2
  Init[Cluster Init Job] --> Headless
  Node0 --> PVC0[(PVC 0)]
  Node1 --> PVC1[(PVC 1)]
  Node2 --> PVC2[(PVC 2)]
```

Cluster mode uses stable pod FQDNs for `cluster-announce-hostname` and a bootstrap Job for initial cluster creation.
It does not try to replace dedicated Redis Cluster operational tooling for resharding or complex node replacement.

## Kubernetes Resource Model

### Shared Resources

- `Secret` or references to `existingSecret`
- optional `ExternalSecret`
- `ConfigMap`
- client and headless `Service` resources
- optional `ServiceMonitor`
- optional `PodDisruptionBudget`
- optional `extraManifests`

### Standalone Resources

- one Redis StatefulSet
- one PVC per pod when persistence is enabled
- one client Service

### Replication Resources

- primary StatefulSet
- replica StatefulSet
- primary and replica DNS helpers
- role-specific persistence

### Sentinel Resources

- role-neutral Redis node StatefulSet, independently sized with `node.replicaCount`
- Sentinel StatefulSet, independently sized with `sentinel.replicaCount`
- Sentinel service as the client discovery contract
- hostname-based Redis and Sentinel announcements
- peer-aware bootstrap, graceful failover, and startup anti-wipe guard

### Cluster Resources

- Redis Cluster StatefulSet
- headless service for stable pod DNS
- client service for cluster-aware clients
- bootstrap Job
- per-node persistence

## DNS And Cluster Domain

Redis internals must not hardcode `svc.cluster.local`. The chart centralizes FQDN generation in helper templates and uses:

```yaml
clusterDomain: cluster.local
```

Operators running clusters with a non-default domain can set `clusterDomain` once and have replication, Sentinel, Cluster announce names, bootstrap jobs, and NOTES output use the same domain.

## Service Networking

Services support single-stack and dual-stack clusters through Kubernetes service family fields:

```yaml
service:
  ipFamilyPolicy: PreferDualStack
  ipFamilies:
    - IPv4
    - IPv6
```

Best practices:

- Leave the defaults empty unless the cluster supports the requested families.
- Use `PreferDualStack` for portable dual-stack behavior.
- Use `RequireDualStack` only when both families are guaranteed.
- Keep headless and client services aligned so DNS behavior is predictable.

`containerPorts.redis`, `containerPorts.sentinel`,
`containerPorts.clusterBus`, and `containerPorts.metrics` configure the actual
process listeners. `service.ports.*` configures the stable client-facing
Service ports and targets the named container ports. Headless peer discovery
uses the container listeners directly because it does not provide kube-proxy
port translation. Cluster mode explicitly configures and announces both the
client and cluster bus ports.

## Security Boundary

- Authentication is enabled by default for production-oriented usage.
- `existingSecret` avoids chart-owned credential rotation when an external secret manager is authoritative.
- External Secrets Operator integration lets the chart reference externally managed credentials while still rendering Kubernetes-native Secret consumers.
- Pods run with restricted security contexts by default where Redis compatibility allows it.
- The chart avoids privileged containers and host namespace access.
- RuntimeDefault seccomp, dropped Linux capabilities, non-root execution, and
  disabled ServiceAccount token automount are secure defaults.
- Optional ingress-only NetworkPolicies isolate Redis and Sentinel pods while
  preserving required topology peer traffic. Operators must add external
  client and metrics sources when same-namespace access is disabled.
- Redis Cluster bus traffic is authenticated when TLS is enabled. Without TLS,
  operators must restrict the bus port to trusted peers with NetworkPolicy or
  equivalent infrastructure controls.
- Sensitive values should not be embedded in examples, CI values, or NOTES.

## Persistence

Stateful Redis nodes use PVCs because identity and data continuity matter for Redis operations.

Best practices:

- Use persistence for production data-bearing nodes.
- Keep storage class and size explicit in production values.
- Disable persistence only for tests, ephemeral caches, or local k3d validation.
- Treat backup/restore as an application-level operational procedure, not as an implicit chart side effect.

## Production Boundary

HA topologies should spread pods across nodes and failure domains where the cluster has enough capacity.

Recommended production controls:

- pod anti-affinity for Redis replicas and Sentinel pods
- topology spread constraints across zones or hosts
- PodDisruptionBudgets for HA modes
- explicit resource requests and limits
- node selectors or tolerations only when they reflect real platform policy

## Observability Boundary

Metrics are optional and should be enabled only when the Prometheus Operator or a compatible scraper is present.

When enabled, exporter resources should follow the selected architecture and expose a stable ServiceMonitor target. The chart should not render CRDs owned by observability operators.

## Extension Points

The chart exposes extension points for advanced operators without making them required:

- `extraEnv`
- `extraVolumes`
- `extraVolumeMounts`
- `extraManifests`
- pod annotations and labels
- service annotations
- topology-specific resource overrides

Extension points are escape hatches. Common operational paths should remain first-class values with schema validation.

## Validation Strategy

Every change to the chart should keep the following checks passing:

- `helm dependency build charts/redis`
- `helm lint charts/redis --strict`
- `helm unittest charts/redis`
- `helm template redis charts/redis`
- `helm template redis charts/redis -f charts/redis/ci/*.yaml`
- strict Kubernetes schema validation for default and CI renders
- documentation linting for changed Markdown files
- runtime k3d validation for behavior-changing chart changes

The CI values must cover standalone, replication, sentinel, cluster, metrics, existing secrets, and networking variants that affect rendered resources.

## Known Gaps

- The chart does not automate backups, restores, resharding, or cluster node
  replacement; operators must provide those procedures.
- NetworkPolicy enforcement depends on a compatible cluster network plugin.
- TLS identity is only as strong as the supplied CA and certificate lifecycle.

## Non-Goals

- Redis Enterprise or active-active Redis
- arbitrary Redis modules as first-class chart features
- operator-grade resharding or node replacement automation
- hiding Redis Cluster complexity from non-cluster-aware clients
- rendering third-party CRDs owned by other operators

## Related Documents

- [`README.md`](README.md)
- [`values.yaml`](values.yaml)
- [`values.schema.json`](values.schema.json)
- [`templates/NOTES.txt`](templates/NOTES.txt)

<!-- @AI-METADATA
type: design
title: Redis Chart Design
description: Architecture and operational design document for the Redis Helm chart

keywords: redis, design, architecture, standalone, replication, sentinel, cluster, dual-stack, clusterDomain

purpose: Document Redis chart architecture, resource model, diagrams, best practices, and validation expectations
scope: Chart Design

relations:
  - charts/redis/README.md
  - charts/redis/values.yaml
  - charts/redis/templates/NOTES.txt
path: charts/redis/DESIGN.md
version: 2.0
date: 2026-05-05
-->
