# changedetection.io Helm Chart

Deploy [changedetection.io](https://changedetection.io) on Kubernetes using the
official [dgtlmoon/changedetection.io](https://github.com/dgtlmoon/changedetection.io)
container image. Monitor websites for changes, track price or stock updates,
run selective content filters, and send notifications through email, Slack,
Discord, Telegram, webhooks, and 90+ Apprise services.

## Features

- **Website monitoring** — detect content changes on any URL
- **90+ notification channels** — via built-in Apprise library
- **Optional JavaScript rendering** — Playwright browser sidecar for dynamic sites
- **JSON datastore** — zero external database dependencies
- **Persistent storage** — snapshots and history on PVC
- **Ingress support** — TLS with cert-manager
- **Gateway API support** — optional HTTPRoute for platform Gateway deployments
- **Dual-stack Service support** — optional `ipFamilyPolicy` and `ipFamilies`
- **External Secrets integration** — render ESO resources for environment-backed configuration
- **Configurable probes** — startup, readiness, and liveness checks
- **Runtime tuning** — fetch workers, recheck interval, timezone, labels, annotations, resources, scheduling, and extra manifests

## Installation

**HTTPS repository:**

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install changedetection helmforge/changedetection -f values.yaml
```

**OCI registry:**

```bash
helm install changedetection oci://ghcr.io/helmforgedev/helm/changedetection -f values.yaml
```

## Basic Example

```yaml
# values.yaml — default values are sufficient for basic usage
changedetection:
  baseUrl: "https://cd.example.com"
```

After deploying:

```bash
kubectl port-forward svc/<release>-changedetection 5000:80
# Open http://localhost:5000
```

## JavaScript Rendering

Enable the Playwright browser sidecar for monitoring JavaScript-heavy sites:

```yaml
browser:
  enabled: true
```

The sidecar runs `ghcr.io/browserless/chromium` and the main container receives
`PLAYWRIGHT_DRIVER_URL` automatically. Keep browser resources sized separately
from the application container when JavaScript rendering is used heavily.

## Persistence

changedetection.io stores its JSON settings and watch files, snapshots, and watch history in
`/datastore`. Persistence is enabled by default:

```yaml
persistence:
  enabled: true
  size: 10Gi
  storageClass: ""
```

For disposable test environments, disable persistence to use an `emptyDir`:

```yaml
persistence:
  enabled: false
```

Because the datastore is written by one application instance, this chart intentionally deploys a single replica with
the `Recreate` strategy. Do not scale the workload horizontally unless the
upstream application storage model changes.

## Ingress

```yaml
changedetection:
  baseUrl: "https://cd.example.com"

ingress:
  enabled: true
  ingressClassName: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt
  hosts:
    - host: cd.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - hosts:
        - cd.example.com
      secretName: changedetection-tls
```

Set `changedetection.baseUrl` to the public URL used by users and notification
links.

## Gateway API

Use Gateway API when your platform routes applications through shared Gateway
resources:

```yaml
changedetection:
  baseUrl: "https://cd.example.com"

gateway:
  enabled: true
  parentRefs:
    - name: shared-gateway
      namespace: ingress
  hostnames:
    - cd.example.com
```

The chart renders a single `HTTPRoute` named after the release and points it to
the chart Service. Keep Ingress and Gateway API disabled by default and enable
only the routing path managed by the cluster.

## External Secrets

The chart can render ExternalSecret resources for upstream-supported
environment variables and automatically consume the produced Secret:

```yaml
externalSecrets:
  enabled: true
  secretStoreRef:
    name: vault
    kind: ClusterSecretStore
  target:
    name: changedetection-env
    creationPolicy: Owner
  data:
    - secretKey: LOGGER_LEVEL
      remoteRef:
        key: changedetection/app
        property: loggerLevel
```

Use this for notification credentials or other sensitive values that should be
owned by External Secrets Operator instead of committed into values files.

## Dual-Stack Service

Clusters with IPv4/IPv6 networking can opt into Kubernetes Service dual-stack:

```yaml
service:
  ipFamilyPolicy: PreferDualStack
  ipFamilies:
    - IPv4
    - IPv6
```

## Runtime Configuration

```yaml
changedetection:
  fetchWorkers: 10
  minimumSecondsRecheckTime: "180"
  timezone: "America/Sao_Paulo"
  locale: C
  envFrom:
    - secretRef:
        name: changedetection-env
  extraEnv:
    - name: LOGGER_LEVEL
      value: INFO
```

Use `changedetection.extraEnv` for upstream-supported environment variables that
are not exposed as first-class chart values, and `changedetection.envFrom` for
pre-created or externally materialized Secrets.

The chart keeps the container non-root by default and sets `PIP_USER=true` with
`PYTHONUSERBASE=/datastore/.python-userbase`. This gives the upstream
`EXTRA_PACKAGES` entrypoint hook a writable Python user install path without
requiring root privileges:

```yaml
changedetection:
  extraEnv:
    - name: EXTRA_PACKAGES
      value: "chardet==5.2.0"
```

## Security And Scheduling

The chart exposes standard Kubernetes controls for production placement and
hardening:

```yaml
securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop:
      - ALL

podSecurityContext: {}
nodeSelector: {}
tolerations: []
affinity: {}
topologySpreadConstraints: []
priorityClassName: ""
```

## Probes

Startup, liveness, and readiness probes are enabled by default and use the HTTP
container port through TCP socket checks. Tune probe timings for slow storage or
large existing datastores:

```yaml
probes:
  startup:
    failureThreshold: 30
  liveness:
    periodSeconds: 15
  readiness:
    periodSeconds: 10
```

## Key Values

| Key | Default | Description |
|-----|---------|-------------|
| `image.repository` | `ghcr.io/dgtlmoon/changedetection.io` | changedetection.io image repository |
| `image.tag` | `0.60.3` | changedetection.io image tag |
| `image.pullPolicy` | `IfNotPresent` | Image pull policy |
| `changedetection.port` | `5000` | Application port |
| `changedetection.baseUrl` | `""` | Public base URL |
| `changedetection.fetchWorkers` | `10` | Concurrent fetch workers |
| `changedetection.minimumSecondsRecheckTime` | `""` | Minimum seconds between checks |
| `changedetection.timezone` | `""` | Container timezone via `TZ` |
| `changedetection.locale` | `C` | Locale assigned to `LANG` and `LC_ALL` |
| `changedetection.defaultWatches.enabled` | `false` | Let upstream create sample watches on a fresh datastore |
| `changedetection.extraEnv` | `[]` | Extra environment variables |
| `changedetection.envFrom` | `[]` | Extra envFrom sources |
| `browser.enabled` | `false` | Enable Playwright browser sidecar |
| `browser.image.repository` | `ghcr.io/browserless/chromium` | Browser sidecar image repository |
| `browser.image.tag` | `v2.46.0` | Browser sidecar image tag |
| `persistence.enabled` | `true` | Enable persistence for /datastore |
| `persistence.size` | `10Gi` | PVC size |
| `persistence.storageClass` | `""` | PVC storage class |
| `persistence.existingClaim` | `""` | Existing PVC name |
| `service.type` | `ClusterIP` | Kubernetes Service type |
| `service.port` | `80` | HTTP Service port |
| `service.ipFamilyPolicy` | unset | Optional Service IP family policy |
| `service.ipFamilies` | `[]` | Optional Service IP families |
| `ingress.enabled` | `false` | Enable ingress |
| `gateway.enabled` | `false` | Enable Gateway API HTTPRoute |
| `externalSecrets.enabled` | `false` | Render ExternalSecret resources |
| `externalSecrets.secretStoreRef.name` | `""` | Required SecretStore name when ExternalSecrets is enabled |
| `externalSecrets.target.name` | `""` | Target Secret name, defaults to release-derived name |
| `probes.*.enabled` | `true` | Enable startup, readiness, and liveness probes |
| `resources.requests.cpu` | `100m` | Main container CPU request |
| `resources.requests.memory` | `256Mi` | Main container memory request |
| `resources.limits.cpu` | `1000m` | Main container CPU limit |
| `resources.limits.memory` | `1Gi` | Main container memory limit |
| `podSecurityContext.fsGroup` | `1000` | Writable group for the `/datastore` volume |
| `securityContext.runAsNonRoot` | `true` | Run the main container without root privileges |
| `securityContext.allowPrivilegeEscalation` | `false` | Prevent privilege escalation |
| `securityContext.capabilities.drop` | `[ALL]` | Drop Linux capabilities by default |
| `extraManifests` | `[]` | Additional manifests rendered with the release |

## Upgrade Notes

Version 0.60.3 includes the intervening watch/tag loading, XML parsing,
CSRF/XSS protections, browser and UTF-8 backup fixes since 0.55.8.
Back up the complete `/datastore` before upgrading: `changedetection.json`,
watch/tag directories and snapshots belong together. Restore that backup with
its matching old image for rollback; reverting only the tag does not reverse
storage migrations.

Upstream consistently blocks private, loopback and other restricted target
addresses by default. Existing internal-site monitors may need an explicit opt-in:

```yaml
changedetection:
  extraEnv:
    - name: ALLOW_IANA_RESTRICTED_ADDRESSES
      value: "true"
```

Use that setting only when internal monitoring is intended and application access
is controlled. The chart keeps the upstream restriction enabled by default.
`PLAYWRIGHT_BYPASS_CSP` defaults to `true` upstream; set it to `false` through
`changedetection.extraEnv` when the remote browser does not support CSP bypass.

## Limitations

- **Single instance only** — the JSON datastore requires a single application writer
- **Storage grows** — each snapshot consumes disk space; plan PVC size accordingly
- **Browser rendering costs more** — enabling the browser sidecar increases CPU
  and memory consumption

## Security Scan

🟢 Security Scan: `changedetection`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **87.88%** |

> ✅ Security posture acceptable.

Local details:

| Framework | Score |
|---|---|
| MITRE | 100.00% |
| NSA | 85.00% |
| SOC2 | 80.00% |

The remaining findings are expected for this workload profile: changedetection.io
needs a writable datastore for JSON files and snapshots, NetworkPolicy is supplied by
the platform layer, and ServiceAccount token hardening remains configurable by
cluster policy.

## More Information

- [changedetection.io documentation](https://changedetection.io)
- [changedetection.io releases](https://github.com/dgtlmoon/changedetection.io/releases)
- [Production guide](docs/production.md)
- [Chart design](DESIGN.md)
- [Source code](https://github.com/helmforgedev/charts/tree/main/charts/changedetection)
