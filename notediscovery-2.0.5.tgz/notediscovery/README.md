# NoteDiscovery Helm Chart

Deploy [NoteDiscovery](https://github.com/gamosoft/NoteDiscovery), a
self-hosted Markdown knowledge base with graph view, search, sharing, and MCP
integration.

This chart packages the official `ghcr.io/gamosoft/notediscovery:0.32.1` image
and exposes the runtime settings that matter for Kubernetes: persistent note
storage, generated or externally managed `config.yaml`, optional authentication,
ingress/Gateway API exposure, network policy, pod disruption budget, and
non-root security context.

## Architecture

NoteDiscovery runs as one Python web service listening on port `8000`. The
upstream container stores durable notes and related files under `/app/data` and
reads application settings from `/app/config.yaml`.

The default chart topology is intentionally conservative:

- one Deployment replica with `Recreate` rollout strategy
- one PersistentVolumeClaim mounted at `/app/data`
- generated ConfigMap for unauthenticated `config.yaml`
- ServiceAccount token automount disabled
- non-root container security context

When authentication is enabled, the generated `config.yaml` is stored in a
Kubernetes Secret so `secret_key`, `password`, and `api_key` are not rendered
into a ConfigMap. For GitOps and production, prefer `auth.existingSecret` with a
complete `config.yaml` key.

## Install

```bash
helm repo add helmforge https://repo.helmforge.dev
helm install notediscovery helmforge/notediscovery
```

Forward the service for local validation:

```bash
kubectl port-forward svc/notediscovery 8000:8000
```

Then open `http://127.0.0.1:8000`.

## Production Values

```yaml
notediscovery:
  allowedOrigins:
    - https://notes.example.com
  defaultTheme: dracula

auth:
  enabled: true
  existingSecret: notediscovery-config
  existingSecretKey: config.yaml

ingress:
  enabled: true
  ingressClassName: traefik
  hosts:
    - host: notes.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: notediscovery-tls
      hosts:
        - notes.example.com

persistence:
  enabled: true
  size: 20Gi

resources:
  requests:
    cpu: 100m
    memory: 256Mi
  limits:
    cpu: 1
    memory: 1Gi

networkPolicy:
  enabled: true
  extraEgress:
    - to:
        - ipBlock:
            cidr: 10.0.0.0/8
      ports:
        - protocol: TCP
          port: 8443
```

Create the existing Secret with a complete NoteDiscovery config file:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: notediscovery-config
type: Opaque
stringData:
  config.yaml: |
    app:
      name: "NoteDiscovery"
    server:
      host: "0.0.0.0"
      port: 8000
      reload: false
      allowed_origins:
        - https://notes.example.com
      debug: false
    storage:
      notes_dir: "/app/data"
      plugins_dir: "/app/data/plugins"
    search:
      enabled: true
    ui:
      autosave_delay_ms: 1000
      default_theme: "dracula"
    authentication:
      enabled: true
      secret_key: "replace-with-a-long-random-secret"
      password: "replace-with-a-strong-password"
      session_max_age: 604800
      api_key: ""
```

## Authentication

`auth.enabled=false` is the default so first-time local installs start without
credentials. For any shared or internet-facing deployment, enable authentication
and provide either:

- `auth.secretKey` and `auth.password`, which render into a chart-managed Secret
- `auth.existingSecret`, which must contain a complete `config.yaml`

`auth.existingSecret` is preferred for production because it avoids putting secret values in Helm values files.

## Storage

Back up the PersistentVolumeClaim before upgrades. NoteDiscovery stores notes
and local application data under `/app/data` by default.

The chart blocks `replicaCount > 1` unless `persistence.existingClaim` is set.
Multiple pods require storage semantics chosen by the operator, typically a
shared ReadWriteMany claim; the default generated claim is a single-writer
volume.

## Upgrade Notes

### Upgrading to 0.32.1

NoteDiscovery `0.32.1` is an upstream release containing new features, bug fixes, and stability improvements.
No breaking configuration or schema changes are introduced in this release.
Review the [upstream 0.32.1 release notes](https://github.com/gamosoft/NoteDiscovery/releases/tag/v0.32.1).

### Upgrading to 0.31.7

NoteDiscovery `0.31.7` adds a homepage list view without changing the service,
configuration or persistence contracts. Review the
[upstream 0.31.7 release](https://github.com/gamosoft/NoteDiscovery/releases/tag/v0.31.7)
and back up the data PVC before upgrading.

Generated configuration now stores plugin state under the writable data volume
and bootstraps the official bundled plugins there. Existing Secrets should use
`storage.plugins_dir: "/app/data/plugins"` (or another writable directory).
The chart sets `PLUGINS_DIR` to `notediscovery.pluginsDir`, derived from
`persistence.mountPath` when empty, so the effective path stays consistent for
generated config, existing Secrets, and External Secrets. Bootstrap preserves
files already present on the volume.

Back up the PVC and keep `persistence.mountPath` stable, then apply the new
chart defaults while preserving explicit overrides:

```bash
helm repo update helmforge
helm upgrade notediscovery helmforge/notediscovery \
  --version 1.1.0 \
  --namespace notediscovery \
  --reset-then-reuse-values
```

## Network Policy

`networkPolicy.enabled=true` restricts inbound HTTP traffic to the configured
`networkPolicy.ingressFrom` peers, or to all namespaces when `ingressFrom` is
empty. `networkPolicy.extraEgress` enables egress isolation and appends custom
egress rules after built-in DNS and HTTPS allowances.

## Documentation

- [Storage](docs/storage.md)
- [Authentication](docs/authentication.md)
- [Exposure](docs/exposure.md)
- [MCP integration](docs/mcp.md)
- [Production](docs/production.md)

## Security Scan: `notediscovery`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **87.37%** |

> Security posture acceptable.
