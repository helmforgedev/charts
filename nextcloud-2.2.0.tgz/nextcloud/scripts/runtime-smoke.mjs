// SPDX-License-Identifier: Apache-2.0
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { verifyBackupRecovery } from './backup-recovery.mjs';

const [context, namespace, release] = process.argv.slice(2);
if (context !== 'k3d-helmforge-tests-wsl' || !namespace || !release) {
  throw new Error('Explicit local HelmForge context, namespace and release are required');
}
const kubectl = (...args) => execFileSync('kubectl', [
  '--context', context, '--namespace', namespace, '--request-timeout=120s', ...args,
], { encoding: 'utf8', timeout: 660000, maxBuffer: 4 * 1024 * 1024 });
const selector = `app.kubernetes.io/instance=${release},app.kubernetes.io/component=app`;
const pods = JSON.parse(kubectl('get', 'pods', '-l', selector, '-o', 'json')).items;
const pod = pods.find(item => !item.metadata.deletionTimestamp && item.spec.containers.some(c => c.name === 'nextcloud'));
if (!pod) throw new Error('Nextcloud Pod not found');
const services = JSON.parse(kubectl('get', 'services', '-l', `app.kubernetes.io/instance=${release}`, '-o', 'json')).items;
const service = services.find(item => item.spec.ports.some(p => p.name === 'http'));
if (!service) throw new Error('Nextcloud HTTP service not found');
process.stdout.write(kubectl('exec', pod.metadata.name, '-c', 'nextcloud', '--',
  'php', '/opt/helmforge/smoke.php', service.metadata.name, String(service.spec.ports.find(p => p.name === 'http').port)));
const status = JSON.parse(kubectl('exec', pod.metadata.name, '-c', 'nextcloud', '--', 'php', '/var/www/html/occ', 'status', '--output=json'));
if (!status.installed || status.maintenance || status.needsDbUpgrade) throw new Error('Nextcloud CLI state is unhealthy');
console.log(`Nextcloud ${status.versionstring}: application and CLI checks passed`);
const occ = (...args) => kubectl('exec', pod.metadata.name, '-c', 'nextcloud', '--', 'php', '/var/www/html/occ', ...args);
const config = JSON.parse(kubectl('get', 'configmap', service.metadata.name, '-o', 'json'));
const runtime = JSON.parse(config.data['runtime-settings.json']);
if (runtime.notifyPush?.enabled) {
  const apps = JSON.parse(occ('app:list', '--output=json'));
  // Verify the replacement before changing any retained app in this local test release.
  process.stdout.write(kubectl('exec', pod.metadata.name, '-c', 'nextcloud', '--', 'sh', '-ec',
      'curl --fail --silent --show-error --location --retry 2 --max-time 120 --output /tmp/notify-push-fixture.tar.gz https://github.com/nextcloud-releases/notify_push/releases/download/v1.4.1/notify_push-v1.4.1.tar.gz; ' +
      'echo "0bfda35cba6e21bc6358ede431bde790b039efadae54bbb393560fcff6127e36 /tmp/notify-push-fixture.tar.gz" | sha256sum -c -'));
  if (apps.enabled.notify_push) process.stdout.write(occ('app:disable', 'notify_push'));
  if (apps.enabled.notify_push || apps.disabled.notify_push) process.stdout.write(occ('app:remove', 'notify_push'));
  process.stdout.write(kubectl('exec', pod.metadata.name, '-c', 'nextcloud', '--', 'sh', '-ec',
    'tar -xzf /tmp/notify-push-fixture.tar.gz -C /var/www/html/custom_apps; rm /tmp/notify-push-fixture.tar.gz'));
  process.stdout.write(occ('app:enable', 'notify_push'));
  process.stdout.write(occ('integrity:check-app', 'notify_push'));
  let notifyPushSetup = '';
  for (let attempt = 1; attempt <= 12; attempt++) {
    try {
      notifyPushSetup = occ('notify_push:setup', 'http://127.0.0.1:8080/push');
      break;
    } catch (error) {
      if (attempt === 12) throw error;
      console.log(`notify_push setup not ready (${attempt}/12); retrying in five seconds`);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  process.stdout.write(notifyPushSetup);
  process.stdout.write(execFileSync('kubectl', ['--context', context, '-n', namespace,
    'exec', '-i', pod.metadata.name, '-c', 'nextcloud', '--', 'php'], {
    input: readFileSync(new URL('./push-smoke.php', import.meta.url)),
    encoding: 'utf8', timeout: 120000,
  }));
}
if (runtime.cron.enabled) {
  const cronjobs = JSON.parse(kubectl('get', 'cronjobs', '-l', `app.kubernetes.io/instance=${release},app.kubernetes.io/component=cron`, '-o', 'json')).items;
  if (cronjobs.length !== 1) throw new Error(`Expected one Nextcloud CronJob, found ${cronjobs.length}`);
  const cronjob = cronjobs[0];
  const wasSuspended = Boolean(cronjob.spec.suspend);
  const systemConfig = JSON.parse(occ('config:list', 'system', '--output=json')).system;
  const updateCheckerWasConfigured = Object.hasOwn(systemConfig, 'updatechecker');
  const updateCheckerWasEnabled = systemConfig.updatechecker ?? true;
  const debugWasConfigured = Object.hasOwn(systemConfig, 'debug');
  const debugWasEnabled = systemConfig.debug ?? false;
  const job = `${cronjob.metadata.name.slice(0, 39)}-smoke-${Date.now()}`;
  let suspendedBySmoke = false;
  let updateCheckerChanged = false;
  let debugChanged = false;
  let jobCreated = false;
  try {
    if (!wasSuspended) {
      kubectl('patch', 'cronjob', cronjob.metadata.name, '--type=merge', '-p', '{"spec":{"suspend":true}}');
      suspendedBySmoke = true;
    }
    // A scheduled Job can be admitted between Helm readiness and this smoke.
    // Remove that test-namespace-only race before starting the controlled cycle.
    kubectl('delete', 'jobs', '-l', `app.kubernetes.io/instance=${release},app.kubernetes.io/component=cron`,
      '--ignore-not-found=true', '--wait=true');
    // A local cluster must not make the CronJob gate depend on the availability
    // or latency of Nextcloud's external update service. Debug mode also skips
    // the upstream CLI-only random jitter that precedes the update-check guard.
    if (updateCheckerWasEnabled) {
      process.stdout.write(occ('config:system:set', 'updatechecker', '--type=boolean', '--value=false'));
      updateCheckerChanged = true;
    }
    if (!debugWasEnabled) {
      process.stdout.write(occ('config:system:set', 'debug', '--type=boolean', '--value=true'));
      debugChanged = true;
    }
    kubectl('create', 'job', job, `--from=cronjob/${cronjob.metadata.name}`);
    jobCreated = true;
    kubectl('wait', '--for=condition=complete', `job/${job}`, '--timeout=600s');
    const jobPods = JSON.parse(kubectl('get', 'pods', '-l', `job-name=${job}`, '-o', 'json')).items;
    const successfulPod = jobPods.find(item => item.status.phase === 'Succeeded');
    if (!successfulPod) throw new Error(`Completed CronJob ${job} has no successful Pod`);
    const log = kubectl('logs', successfulPod.metadata.name, '-c', 'cron');
    if (!log.includes('Nextcloud background jobs completed successfully')) {
      throw new Error(`CronJob did not report a completed background-job cycle: ${log}`);
    }
  } finally {
    try {
      if (jobCreated) kubectl('delete', 'job', job, '--ignore-not-found=true', '--wait=true');
    } finally {
      try {
        if (updateCheckerChanged) {
          if (updateCheckerWasConfigured) process.stdout.write(occ('config:system:set', 'updatechecker', '--type=boolean', '--value=true'));
          else process.stdout.write(occ('config:system:delete', 'updatechecker'));
        }
      } finally {
        try {
          if (debugChanged) {
            if (debugWasConfigured) process.stdout.write(occ('config:system:set', 'debug', '--type=boolean', '--value=false'));
            else process.stdout.write(occ('config:system:delete', 'debug'));
          }
        } finally {
          if (suspendedBySmoke) {
            kubectl('patch', 'cronjob', cronjob.metadata.name, '--type=merge', '-p', '{"spec":{"suspend":false}}');
          }
        }
      }
    }
  }
  console.log('Kubernetes CronJob background cycle completed successfully');
}
const external = JSON.parse(kubectl('get', 'externalsecrets', '-o', 'json')).items;
for (const item of external) {
  if (!item.status?.conditions?.some(c => c.type === 'Ready' && c.status === 'True')) throw new Error('ExternalSecret is not Ready');
}
const backupCronjobs = JSON.parse(kubectl('get', 'cronjobs', '-l', `app.kubernetes.io/instance=${release},app.kubernetes.io/component=backup`, '-o', 'json')).items;
if (backupCronjobs.length > 0) {
  const secret = pod.spec.containers.find(c => c.name === 'nextcloud').env.find(e => e.name === 'NEXTCLOUD_ADMIN_PASSWORD').valueFrom.secretKeyRef.name;
  verifyBackupRecovery(context, namespace, release, service.metadata.name, secret, backupCronjobs[0].metadata.name);
}
