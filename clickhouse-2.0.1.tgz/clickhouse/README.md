# ClickHouse

Fast column-oriented OLAP database with production-safe standalone defaults.

## Installation

```bash
helm repo add helmforge https://repo.helmforge.dev
helm install clickhouse helmforge/clickhouse
```

```bash
helm install clickhouse oci://ghcr.io/helmforgedev/helm/clickhouse
```

## Features

- Official ClickHouse image pinned to `26.8.2`.
- StatefulSet with persistent data volume.
- Client Service exposing HTTP `8123` and native TCP `9000`.
- Headless Service for stable pod DNS.
- Built-in Prometheus metrics endpoint.
- ServiceMonitor support.
- External Secrets integration for the initial password.
- NetworkPolicy and dual-stack Service fields.
- Explicit guardrail blocking unsafe Helm-only replication.

## Quick Start

```yaml
persistence:
  size: 20Gi
```

## Production Example

```yaml
clickhouse:
  database: analytics
  user: analytics
  existingSecret: clickhouse-auth
persistence:
  size: 200Gi
metrics:
  enabled: true
  serviceMonitor:
    enabled: true
networkPolicy:
  enabled: true
```

## Configuration

| Parameter | Description | Default |
| --- | --- | --- |
| `replicaCount` | ClickHouse pod count. Must remain `1` | `1` |
| `image.repository` | Official image repository | `docker.io/clickhouse/clickhouse-server` |
| `image.tag` | Official full-version tag | `26.8.2` |
| `clickhouse.database` | Initial database | `default` |
| `clickhouse.user` | Initial user | `default` |
| `clickhouse.password` | Initial password | `""` |
| `persistence.enabled` | Persist data volume | `true` |
| `persistence.size` | Data PVC size | `20Gi` |
| `metrics.enabled` | Built-in Prometheus endpoint | `false` |
| `networkPolicy.enabled` | Render NetworkPolicy | `false` |
| `service.ipFamilyPolicy` | Service dual-stack policy | `""` |

## Examples

- [Standalone](examples/standalone.yaml)
- [Production](examples/production.yaml)
- [External Secrets](examples/external-secrets.yaml)
- [Metrics](examples/metrics.yaml)

## Architecture Guides

- [Production](docs/production.md)
- [Observability](docs/observability.md)
- [External Secrets](docs/external-secrets.md)

## Security Scan

### Security Scan: `clickhouse`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **89.39%** |

Security posture acceptable.

Local details:

- Tool: Kubescape v4.0.13
- Command: `kubescape scan framework mitre,nsa,soc2 .tmp/clickhouse-render.yaml`
- Result: 0 critical failed resources, resource summary score 89.39%.

## Operator Boundary

ClickHouse replication needs Keeper or ZooKeeper, cluster definitions, and
cluster-aware operations. This chart intentionally blocks `replicaCount > 1`.
Use the ClickHouse Operator or Altinity operator stack for sharded or replicated
clusters.

## Upgrade Notes

ClickHouse 26.8.2 follows the monthly 26.7 release and carries the August LTS
designation. It changes the default text-index disk format to v2 and updates
aggregation, constraint handling, query correctness and merge behavior. Test
existing table engines and application queries, take a verified backup, and
plan rollback before allowing a new version to write production data.
Operators that coordinate mixed-version replicas must review text_index_serialization_version
compatibility before enabling the new format; this chart remains standalone.
The experimental disk-backed Keeper feature is not enabled by this chart.
See the [official 26.8 presentation](https://presentations.clickhouse.com/2026-release-26.8/)
and [26.8.2 release](https://github.com/ClickHouse/ClickHouse/releases/tag/v26.8.2.7-lts).

Earlier 26.7 releases moved ClickHouse from 26.6 to 26.7 stable. Review the upstream
[ClickHouse 26.7 release notes](https://github.com/ClickHouse/ClickHouse/releases/tag/v26.7.5.10-stable)
and backward-incompatible changes before upgrading production workloads.
Important changes include explicit credentials for user SQL that accesses S3,
rejection of ZIP/ZIPX backups on object storage, stricter
`AggregatingMergeTree` dimensions, removal of XML `resources` and
`workload_classifiers`, and startup rejection of legacy
`insert_deduplication_version` values. StatefulSet rolling updates reuse the
existing data volume; take a verified backup and test application queries and
restore procedures first.

The Helm test now authenticates through the configured Secret, verifies the
running version, and executes an `EXPLAIN ANALYZE` query introduced in 26.7.

<!-- @AI-METADATA
type: chart-readme
title: ClickHouse Chart
description: Production-ready standalone ClickHouse Helm chart
keywords: clickhouse, database, olap, prometheus
purpose: Chart usage documentation
scope: Chart
relations:
  - charts/clickhouse/values.yaml
path: charts/clickhouse/README.md
version: 1.0
date: 2026-07-06
-->
