// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {execFileSync, spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {readFileSync, writeFileSync} from 'node:fs';
import {setTimeout as delay} from 'node:timers/promises';

const chartYamlPath = new URL('../Chart.yaml', import.meta.url);
const chartAppVersion = readFileSync(chartYamlPath, 'utf8').match(/appVersion:\s*["']?([^"'\s]+)/)?.[1] || '3.3.0';
const [context, namespace, release, version = chartAppVersion, action = 'smoke'] = process.argv.slice(2);
assert.ok(['smoke', 'create', 'verify'].includes(action));
const statePath = process.env.HF_N8N_UPGRADE_STATE;
assert.ok(action === 'smoke' || statePath, 'Upgrade state path required');
const retained = action === 'verify' ? JSON.parse(readFileSync(statePath, 'utf8')) : null;
if (!context?.startsWith('k3d-helmforge-') || !namespace || !release) {
  throw new Error('Explicit HelmForge lab context, namespace and release required');
}
const deadline = Date.now() + 140000;
const target = ['--context', context, '-n', namespace];
const kubectl = args => execFileSync('kubectl', [...target, ...args], {
  encoding: 'utf8', timeout: 15000, stdio: ['ignore', 'pipe', 'pipe'],
});
const pods = JSON.parse(kubectl(['get', 'pods', '-l', `app.kubernetes.io/instance=${release}`, '-o', 'json'])).items;
const pod = pods.find(p => !p.metadata.deletionTimestamp
  && p.status.conditions?.some(c => c.type === 'Ready' && c.status === 'True')
  && p.spec.containers.some(c => c.name === 'n8n'));
assert.ok(pod, 'Ready n8n main pod required');
assert.equal(kubectl(['exec', pod.metadata.name, '-c', 'n8n', '--', 'n8n', '--version']).trim(), version);
const main = pod.spec.containers.find(c => c.name === 'n8n');
const httpPort = main.ports?.find(port => port.name === 'http')?.containerPort;
assert.ok(Number.isInteger(httpPort) && httpPort > 0, 'n8n HTTP listener port required');
assert.equal(main.env.find(env => env.name === 'N8N_PORT')?.value, String(httpPort),
  'N8N_PORT must match the declared HTTP listener');
const python = main.env.some(e => e.name === 'N8N_PYTHON_ENABLED' && e.value === 'true');
const queue = main.env.some(e => e.name === 'EXECUTIONS_MODE' && e.value === 'queue');
const externalRunners = main.env.some(e => e.name === 'N8N_RUNNERS_MODE' && e.value === 'external');
function assertRunnerContract(runnerPod) {
  const processContainer = runnerPod.spec.containers.find(container => ['n8n', 'worker'].includes(container.name));
  const runner = runnerPod.spec.containers.find(container => container.name === 'task-runners');
  assert.ok(processContainer && runner, `External task runner contract missing in ${runnerPod.metadata.name}`);
  const brokerPort = processContainer.env.find(env => env.name === 'N8N_RUNNERS_BROKER_PORT')?.value;
  assert.match(brokerPort ?? '', /^\d+$/, 'Task broker port must be configured');
  assert.equal(runner.env.find(env => env.name === 'N8N_RUNNERS_TASK_BROKER_URI')?.value,
    `http://127.0.0.1:${brokerPort}`);
  const healthPort = runner.ports?.find(port => port.name === 'runner-health')?.containerPort;
  assert.ok(Number.isInteger(healthPort) && healthPort > 0, 'Task runner health port required');
  assert.equal(runner.env.find(env => env.name === 'N8N_RUNNERS_LAUNCHER_HEALTH_CHECK_PORT')?.value,
    String(healthPort));
}
if (externalRunners) {
  assert.equal(main.ports?.find(port => port.name === 'runners')?.containerPort,
    Number(main.env.find(env => env.name === 'N8N_RUNNERS_BROKER_PORT')?.value));
  assertRunnerContract(pod);
}
if (queue) {
  const runnerPods = pods.filter(candidate => candidate.spec.containers.some(container => container.name === 'task-runners'));
  assert.ok(runnerPods.length >= 2, 'Queue profile requires task runners in main and worker pods');
  for (const runnerPod of runnerPods) {
    const runner = runnerPod.spec.containers.find(container => container.name === 'task-runners');
    assertRunnerContract(runnerPod);
    assert.ok(runner.env.some(env => env.name === 'HELMFORGE_TASK_RUNNER_PROFILE' && env.value === 'queue'),
      `Queue task runner ${runnerPod.metadata.name} requires configured extraEnv`);
  }
}
const child = spawn('kubectl', [...target, 'port-forward', `pod/${pod.metadata.name}`, `:${httpPort}`, '--address=127.0.0.1'], {
  windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'],
});
let output = '', error;
child.stdout.on('data', chunk => { output += chunk; });
child.stderr.on('data', () => {});
child.on('error', caught => { error = caught; });
try {
  for (let i = 0; i < 150 && !/127\.0\.0\.1:(\d+) ->/.test(output) && !error; i++) await delay(100);
  if (error) throw error;
  const port = output.match(/127\.0\.0\.1:(\d+) ->/)?.[1];
  assert.ok(port);
  const base = `http://127.0.0.1:${port}`, cookies = new Map();
  async function request(route, method = 'GET', body) {
    const remaining = deadline - Date.now();
    assert.ok(remaining > 0, 'Runtime deadline reached');
    const response = await fetch(base + route, {
      // CLI export blocks the local event loop; do not reuse an expired HTTP socket.
      method, headers: {'Content-Type': 'application/json', Connection: 'close', Cookie: [...cookies].map(([a, b]) => `${a}=${b}`).join('; ')},
      ...(body ? {body: JSON.stringify(body)} : {}), signal: AbortSignal.timeout(Math.min(60000, remaining)),
    });
    for (const cookie of response.headers.getSetCookie()) {
      const pair = cookie.split(';')[0], equals = pair.indexOf('=');
      cookies.set(pair.slice(0, equals), pair.slice(equals + 1));
    }
    assert.ok(response.ok, `${method} ${route}: HTTP ${response.status}`);
    return response.json();
  }
  async function publishedWebhook(route) {
    let lastError;
    for (let attempt = 0; attempt < 20; attempt++) {
      try { return await request(`/webhook/${route}`); }
      catch (caught) {
        if (!caught.message.includes('HTTP 404')) throw caught;
        lastError = caught;
        await delay(250);
      }
    }
    throw lastError;
  }
  await request('/healthz/readiness');
  const ownerPassword = retained?.ownerPassword ?? `Fixture-${randomBytes(18).toString('hex')}!`;
  if (retained) {
    await request('/rest/login', 'POST', {emailOrLdapLoginId: 'runtime@example.invalid', password: ownerPassword});
  } else {
    await request('/rest/owner/setup', 'POST', {
      email: 'runtime@example.invalid', firstName: 'Runtime', lastName: 'Fixture', password: ownerPassword,
    });
  }
  const credentialPassword = retained?.credentialPassword ?? randomBytes(24).toString('hex');
  const credential = retained?.credential ?? (await request('/rest/credentials', 'POST', {
    name: 'HelmForge encryption fixture', type: 'httpBasicAuth',
    data: {user: 'runtime-fixture', password: credentialPassword},
  })).data;
  const routes = retained?.routes ?? [];
  for (const route of routes) {
    const response = await publishedWebhook(route);
    assert.equal((Array.isArray(response) ? response[0] : response).answer, 42, 'Retained published workflow');
  }
  assert.ok(credential.id);
  execFileSync('kubectl', [...target, 'exec', pod.metadata.name, '-c', 'n8n', '--',
    'n8n', 'export:credentials', `--id=${credential.id}`, '--decrypted', '--output=/tmp/helmforge-credential.json'], {
    encoding: 'utf8', timeout: 90000, stdio: ['ignore', 'pipe', 'pipe'],
  });
  const exported = JSON.parse(kubectl(['exec', pod.metadata.name, '-c', 'n8n', '--', 'node', '-e',
    "const fs=require('node:fs');const p='/tmp/helmforge-credential.json';const data=fs.readFileSync(p,'utf8');fs.unlinkSync(p);process.stdout.write(data);"]));
  assert.equal(exported[0].data.password, credentialPassword, 'Persisted credential decryption');
  for (const language of python ? ['javaScript', 'pythonNative'] : ['javaScript']) {
    const route = `helmforge-${randomBytes(8).toString('hex')}`;
    const workflow = {name: `Runtime ${language}`, nodes: [
      {id: 'webhook', name: 'Webhook', type: 'n8n-nodes-base.webhook', typeVersion: 2, position: [0, 0], webhookId: route,
        parameters: {httpMethod: 'GET', path: route, responseMode: 'lastNode', options: {}}},
      {id: 'code', name: 'Code', type: 'n8n-nodes-base.code', typeVersion: 2, position: [240, 0], parameters: {
        language, mode: 'runOnceForAllItems', ...(language === 'javaScript'
          ? {jsCode: 'return [{json: {answer: 6 * 7}}];'} : {pythonCode: 'return [{"json": {"answer": 6 * 7}}]'}),
      }},
    ], connections: {Webhook: {main: [[{node: 'Code', type: 'main', index: 0}]]}}, settings: {executionOrder: 'v1'}};
    const created = (await request('/rest/workflows', 'POST', workflow)).data;
    assert.ok(created.id && created.versionId);
    await request(`/rest/workflows/${created.id}/activate`, 'POST', {versionId: created.versionId});
    const response = await publishedWebhook(route);
    const result = Array.isArray(response) ? response[0] : response;
    assert.equal(result.answer, 42, `${language} runner result`);
    routes.push(route);
  }
  if (action === 'create') writeFileSync(statePath, JSON.stringify({ownerPassword, credentialPassword, credential: {id: credential.id}, routes}), {mode: 0o600});
  console.log(`PASS: n8n ${version}, readiness, owner authentication, persisted credential decryption${retained ? ', retained login and workflows after upgrade' : ''} and published ${python ? 'JavaScript/Python' : 'JavaScript'} workflow execution${queue ? ' through Redis queue workers' : ''}`);
} finally {
  if (child.exitCode === null) {
    if (process.platform === 'win32') {
      try { execFileSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], {stdio: 'ignore'}); }
      catch (cleanupError) {
        let exists = true;
        try { process.kill(child.pid, 0); }
        catch (error) { if (error.code === 'ESRCH') exists = false; else throw error; }
        if (exists) throw cleanupError;
      }
    } else child.kill('SIGTERM');
  }
}
