{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{- define "homarr.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "homarr.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "homarr.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "homarr.labels" -}}
helm.sh/chart: {{ include "homarr.chart" . }}
{{ include "homarr.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "homarr.selectorLabels" -}}
app.kubernetes.io/name: {{ include "homarr.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "homarr.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "homarr.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "homarr.image" -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end }}

{{- define "homarr.validate" -}}
{{/* Triggers database selection validation through homarr.databaseMode; the return value is unused. */}}
{{- $databaseMode := include "homarr.databaseMode" . -}}
{{- if and .Values.homarr.enableKubernetes (not .Values.serviceAccount.automountServiceAccountToken) -}}
{{- fail "homarr.enableKubernetes=true requires serviceAccount.automountServiceAccountToken=true and scoped RBAC" -}}
{{- end -}}
{{- end }}

{{/* ======================================================================== */}}
{{/* Encryption helpers                                                        */}}
{{/* ======================================================================== */}}

{{- define "homarr.encryptionSecretName" -}}
{{- if .Values.encryption.existingSecret -}}
  {{- .Values.encryption.existingSecret -}}
{{- else -}}
  {{- printf "%s-encryption" (include "homarr.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "homarr.encryptionSecretKey" -}}
{{- if .Values.encryption.existingSecret -}}
  {{- .Values.encryption.existingSecretKey | default "secret-encryption-key" -}}
{{- else -}}
  secret-encryption-key
{{- end -}}
{{- end -}}

{{/* ======================================================================== */}}
{{/* Database helpers                                                          */}}
{{/* ======================================================================== */}}

{{- define "homarr.databaseMode" -}}
{{- $mode := .Values.database.mode | default "auto" -}}
{{- $legacyMysqlEnabled := dig "enabled" false (.Values.mysql | default dict) -}}
{{- if $legacyMysqlEnabled -}}
{{- fail "mysql.enabled is not supported by Homarr v2. Convert the MySQL database to SQLite and validate the converted SQLite deployment before upgrading." -}}
{{- end -}}
{{- if not (has $mode (list "auto" "sqlite" "external" "postgresql")) -}}
{{- fail (printf "database.mode must be one of: auto, sqlite, external, postgresql (got %s)" $mode) -}}
{{- end -}}
{{- $hasExternal := ne (.Values.database.external.host | default "") "" -}}
{{- $hasExternalCredentials := or (ne (.Values.database.external.password | default "") "") (ne (.Values.database.external.existingSecret | default "") "") -}}
{{- $hasPostgresql := .Values.postgresql.enabled | default false -}}
{{- if and $hasPostgresql (hasKey .Values.postgresql "primary") -}}
{{- fail "postgresql.primary.* is not supported by the HelmForge PostgreSQL 2.x dependency used by this chart. Migrate PostgreSQL values to postgresql.standalone.* before upgrading." -}}
{{- end -}}
{{- $vendor := .Values.database.external.vendor | default "postgres" -}}
{{- if ne $vendor "postgres" -}}
{{- fail (printf "database.external.vendor must be postgres for Homarr v2 (got %s)" $vendor) -}}
{{- end -}}
{{- if and $hasExternal (not $hasExternalCredentials) -}}
{{- fail "database.external.password or database.external.existingSecret is required when database.external.host is set" -}}
{{- end -}}
{{- if and $hasExternalCredentials (not $hasExternal) -}}
{{- fail "database.external.host is required when external database credentials are configured" -}}
{{- end -}}
{{- if eq $mode "auto" -}}
  {{- $count := 0 -}}
  {{- if $hasExternal -}}{{- $count = add1 $count -}}{{- end -}}
  {{- if $hasPostgresql -}}{{- $count = add1 $count -}}{{- end -}}
  {{- if gt $count 1 -}}
    {{- fail "homarr database selection is ambiguous: configure only one of database.external.host or postgresql.enabled" -}}
  {{- end -}}
  {{- if $hasExternal -}}external
  {{- else if $hasPostgresql -}}postgresql
  {{- else -}}sqlite
  {{- end -}}
{{- else -}}
  {{- if and (eq $mode "sqlite") (or $hasExternal $hasPostgresql) -}}
    {{- fail "database.mode=sqlite cannot be combined with database.external or postgresql.enabled" -}}
  {{- end -}}
  {{- if and (eq $mode "external") (not $hasExternal) -}}
    {{- fail "database.mode=external requires database.external.host and database credentials" -}}
  {{- end -}}
  {{- if and (eq $mode "external") $hasPostgresql -}}
    {{- fail "database.mode=external cannot be combined with postgresql.enabled" -}}
  {{- end -}}
  {{- if and (eq $mode "postgresql") (not $hasPostgresql) -}}
    {{- fail "database.mode=postgresql requires postgresql.enabled=true" -}}
  {{- end -}}
  {{- if and (eq $mode "postgresql") $hasExternal -}}
    {{- fail "database.mode=postgresql cannot be combined with database.external" -}}
  {{- end -}}
  {{- $mode -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databaseVendor" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "external" -}}
{{- .Values.database.external.vendor | default "postgres" -}}
{{- else if eq $mode "postgresql" -}}
postgres
{{- else -}}
sqlite3
{{- end -}}
{{- end -}}

{{/*
Homarr DB_DRIVER value: better-sqlite3 or node-postgres
*/}}
{{- define "homarr.dbDriver" -}}
{{- $vendor := include "homarr.databaseVendor" . -}}
{{- if eq $vendor "sqlite3" -}}better-sqlite3
{{- else -}}node-postgres
{{- end -}}
{{- end -}}

{{/*
Homarr DB_DIALECT value: sqlite or postgresql
*/}}
{{- define "homarr.dbDialect" -}}
{{- $vendor := include "homarr.databaseVendor" . -}}
{{- if eq $vendor "sqlite3" -}}sqlite
{{- else -}}postgresql
{{- end -}}
{{- end -}}

{{- define "homarr.databaseHost" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "external" -}}
{{- .Values.database.external.host -}}
{{- else if eq $mode "postgresql" -}}
{{- printf "%s-postgresql" .Release.Name -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databasePort" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "external" -}}
{{- if .Values.database.external.port -}}
{{- .Values.database.external.port | toString -}}
{{- else -}}
5432
{{- end -}}
{{- else if eq $mode "postgresql" -}}
5432
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databaseName" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "external" -}}
{{- .Values.database.external.name -}}
{{- else if eq $mode "postgresql" -}}
{{- .Values.postgresql.auth.database -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databaseUsername" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "external" -}}
{{- .Values.database.external.username -}}
{{- else if eq $mode "postgresql" -}}
{{- .Values.postgresql.auth.username -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databasePasswordValue" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "external" -}}
{{- .Values.database.external.password -}}
{{- else if eq $mode "postgresql" -}}
{{- .Values.postgresql.auth.password -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{/*
Database URL for SQLite. PostgreSQL uses discrete env vars so passwords
do not need URL encoding inside a rendered connection string.
*/}}
{{- define "homarr.dbUrl" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if eq $mode "sqlite" -}}
{{- .Values.database.sqlite.path -}}
{{- else -}}
{{- "" -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databaseSecretName" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if and (eq $mode "external") .Values.database.external.existingSecret -}}
  {{- .Values.database.external.existingSecret -}}
{{- else if eq $mode "postgresql" -}}
  {{- include "homarr.postgresqlSecretName" . -}}
{{- else -}}
  {{- printf "%s-database" (include "homarr.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "homarr.databaseSecretKey" -}}
{{- $mode := include "homarr.databaseMode" . -}}
{{- if and (eq $mode "external") .Values.database.external.existingSecret -}}
  {{- .Values.database.external.existingSecretPasswordKey | default "database-password" -}}
{{- else if eq $mode "postgresql" -}}
  {{- .Values.postgresql.auth.existingSecretUserPasswordKey | default "user-password" -}}
{{- else -}}
  database-password
{{- end -}}
{{- end -}}

{{- define "homarr.postgresqlSecretName" -}}
{{- $postgresqlName := .Values.postgresql.nameOverride | default "postgresql" | trunc 63 | trimSuffix "-" -}}
{{- $baseName := printf "%s-%s" .Release.Name $postgresqlName | trunc 63 | trimSuffix "-" -}}
{{- if .Values.postgresql.fullnameOverride -}}
  {{- $baseName = .Values.postgresql.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- $defaultName := printf "%s-auth" ($baseName | trunc 58 | trimSuffix "-") | trunc 63 | trimSuffix "-" -}}
{{- if .Values.postgresql.auth.existingSecret -}}
{{- .Values.postgresql.auth.existingSecret -}}
{{- else if and (dig "externalSecrets" "enabled" false .Values.postgresql) (dig "externalSecrets" "auth" "enabled" false .Values.postgresql) -}}
{{- dig "externalSecrets" "auth" "targetName" "" .Values.postgresql | default $defaultName -}}
{{- else -}}
{{- $defaultName -}}
{{- end -}}
{{- end -}}

{{- define "homarr.shouldRunPostgresqlUpgradeJob" -}}
{{- if and .Values.postgresql.enabled .Values.postgresqlUpgradeJob.enabled -}}
  {{- if not .Values.postgresqlUpgradeJob.requireExistingResources -}}
true
  {{- else -}}
    {{- $secret := lookup "v1" "Secret" .Release.Namespace (include "homarr.postgresqlSecretName" .) -}}
    {{- $service := lookup "v1" "Service" .Release.Namespace (include "homarr.databaseHost" .) -}}
    {{- if and $secret $service -}}true{{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/* ======================================================================== */}}
{{/* Backup helpers                                                            */}}
{{/* ======================================================================== */}}

{{- define "homarr.backupSecretName" -}}
{{- if .Values.backup.s3.existingSecret -}}
  {{- .Values.backup.s3.existingSecret -}}
{{- else -}}
  {{- printf "%s-backup-s3" (include "homarr.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "homarr.backupDatabaseHost" -}}
{{- if .Values.backup.database.host -}}
  {{- .Values.backup.database.host -}}
{{- else -}}
  {{- include "homarr.databaseHost" . -}}
{{- end -}}
{{- end -}}

{{- define "homarr.backupDatabasePort" -}}
{{- if .Values.backup.database.port -}}
  {{- .Values.backup.database.port | toString -}}
{{- else -}}
  {{- include "homarr.databasePort" . -}}
{{- end -}}
{{- end -}}

{{- define "homarr.backupDatabaseName" -}}
{{- if .Values.backup.database.name -}}
  {{- .Values.backup.database.name -}}
{{- else -}}
  {{- include "homarr.databaseName" . -}}
{{- end -}}
{{- end -}}

{{- define "homarr.backupDatabaseUsername" -}}
{{- if .Values.backup.database.username -}}
  {{- .Values.backup.database.username -}}
{{- else -}}
  {{- include "homarr.databaseUsername" . -}}
{{- end -}}
{{- end -}}

{{- define "homarr.backupDatabasePasswordSecretName" -}}
{{- if .Values.backup.database.existingSecret -}}
  {{- .Values.backup.database.existingSecret -}}
{{- else if .Values.backup.database.password -}}
  {{- printf "%s-backup-db" (include "homarr.fullname" .) -}}
{{- else -}}
  {{- include "homarr.databaseSecretName" . -}}
{{- end -}}
{{- end -}}

{{- define "homarr.backupDatabasePasswordSecretKey" -}}
{{- if .Values.backup.database.existingSecret -}}
  {{- .Values.backup.database.existingSecretPasswordKey | default "database-password" -}}
{{- else if .Values.backup.database.password -}}
  database-password
{{- else -}}
  {{- include "homarr.databaseSecretKey" . -}}
{{- end -}}
{{- end -}}
