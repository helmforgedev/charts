{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{- define "heimdall.validate" -}}
{{- if or (not (trim .Values.image.repository)) (not (trim .Values.image.tag)) -}}
{{- fail "image.repository and image.tag must not be empty" -}}
{{- end -}}
{{- if and .Values.ingress.enabled (not .Values.ingress.hosts) -}}
{{- fail "ingress.hosts must contain at least one host when ingress.enabled is true" -}}
{{- end -}}
{{- range $key := list "app.kubernetes.io/name" "app.kubernetes.io/instance" "app.kubernetes.io/component" -}}
{{- if hasKey $.Values.podLabels $key -}}
{{- fail (printf "podLabels must not override required label %s" $key) -}}
{{- end -}}
{{- end -}}
{{- if .Values.backup.enabled -}}
{{- if not (trim .Values.backup.s3.endpoint) -}}
{{- fail "backup.s3.endpoint is required when backup.enabled is true" -}}
{{- end -}}
{{- if not (trim .Values.backup.s3.bucket) -}}
{{- fail "backup.s3.bucket is required when backup.enabled is true" -}}
{{- end -}}
{{- if and .Values.backup.s3.credentialsFromPodIdentity (not (trim .Values.backup.s3.region)) -}}
{{- fail "backup.s3.region is required when backup.s3.credentialsFromPodIdentity is true" -}}
{{- end -}}
{{- if and .Values.backup.s3.credentialsFromPodIdentity (not .Values.backup.serviceAccount.create) (not (trim .Values.backup.serviceAccount.name)) -}}
{{- fail "backup.serviceAccount.name is required when backup.serviceAccount.create is false" -}}
{{- end -}}
{{- if and (not .Values.backup.s3.credentialsFromPodIdentity) (not .Values.backup.s3.existingSecret) (or (not .Values.backup.s3.accessKey) (not .Values.backup.s3.secretKey)) -}}
{{- fail "backup S3 credentials are required when workload identity is disabled" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "heimdall.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "heimdall.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "heimdall.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "heimdall.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "heimdall.labels" -}}
helm.sh/chart: {{ include "heimdall.chart" . }}
{{ include "heimdall.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "heimdall.selectorLabels" -}}
app.kubernetes.io/name: {{ include "heimdall.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "heimdall.renderAnnotations" -}}
{{- $common := deepCopy (.root.Values.commonAnnotations | default dict) -}}
{{- $specific := .specific | default dict -}}
{{- $required := .required | default dict -}}
{{- $annotations := mergeOverwrite $common $specific $required -}}
{{- with $annotations }}
annotations:
{{ toYaml . | indent 2 }}
{{- end -}}
{{- end -}}

{{- define "heimdall.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "heimdall.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "heimdall.backupServiceAccountName" -}}
{{- if .Values.backup.serviceAccount.create -}}
{{- default (printf "%s-backup" (include "heimdall.fullname" .)) .Values.backup.serviceAccount.name -}}
{{- else -}}
{{- required "backup.serviceAccount.name is required when backup.serviceAccount.create is false" .Values.backup.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "heimdall.image" -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}

{{/* S3 credentials secret name */}}
{{- define "heimdall.backupSecretName" -}}
{{- if .Values.backup.s3.existingSecret -}}
{{- .Values.backup.s3.existingSecret -}}
{{- else -}}
{{- printf "%s-backup-s3" (include "heimdall.fullname" .) -}}
{{- end -}}
{{- end -}}
