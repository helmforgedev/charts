{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{- define "moodle.name" -}}{{ default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- define "moodle.fullname" -}}
{{- if .Values.fullnameOverride -}}{{ .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else if contains (include "moodle.name" .) .Release.Name -}}{{ .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ printf "%s-%s" .Release.Name (include "moodle.name" .) | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- end -}}
{{- define "moodle.nameWithSuffix" -}}{{ printf "%s%s" (.base | trunc (int (sub 63 (len .suffix))) | trimSuffix "-") .suffix }}{{- end -}}
{{- define "moodle.selectorLabels" -}}
app.kubernetes.io/name: {{ include "moodle.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "moodle.chart" -}}{{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- define "moodle.labels" -}}
helm.sh/chart: {{ include "moodle.chart" . }}
{{ include "moodle.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}
{{- define "moodle.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}{{ default (include "moodle.fullname" .) .Values.serviceAccount.name }}
{{- else -}}{{ default "default" .Values.serviceAccount.name }}{{- end -}}
{{- end -}}
{{- define "moodle.image" -}}{{ printf "%s:%s@%s" .Values.image.repository .Values.image.tag .Values.image.digest }}{{- end -}}
{{- define "moodle.metricsSecret" -}}{{ default (include "moodle.nameWithSuffix" (dict "base" (include "moodle.fullname" .) "suffix" "-metrics")) .Values.metrics.existingSecret }}{{- end -}}
{{- define "moodle.secretName" -}}{{ default (include "moodle.nameWithSuffix" (dict "base" (include "moodle.fullname" .) "suffix" "-admin")) .Values.moodle.existingSecret }}{{- end -}}
{{- define "moodle.dataClaim" -}}{{ default (include "moodle.nameWithSuffix" (dict "base" (include "moodle.fullname" .) "suffix" "-data")) .Values.persistence.existingClaim }}{{- end -}}
{{- define "moodle.dbHost" -}}
{{- if .Values.postgresql.enabled -}}{{ include "postgresql.primaryServiceName" .Subcharts.postgresql }}{{- else if .Values.mysql.enabled -}}{{ include "mysql.sourceServiceName" .Subcharts.mysql }}{{- else if .Values.mariadb.enabled -}}{{ include "mariadb.sourceServiceName" .Subcharts.mariadb }}{{- else -}}{{ .Values.database.host }}{{- end -}}
{{- end -}}
{{- define "moodle.dbBundled" -}}{{ if or .Values.postgresql.enabled .Values.mysql.enabled .Values.mariadb.enabled }}true{{ end }}{{- end -}}
{{- define "moodle.dbPort" -}}
{{- if .Values.postgresql.enabled }}{{ .Subcharts.postgresql.Values.service.port }}{{ else if .Values.mysql.enabled }}{{ .Subcharts.mysql.Values.service.port }}{{ else if .Values.mariadb.enabled }}{{ .Subcharts.mariadb.Values.service.port }}{{ else }}{{ default (ternary 5432 3306 (eq .Values.database.type "postgresql")) .Values.database.port }}{{ end -}}
{{- end -}}
{{- define "moodle.dbName" -}}{{ if include "moodle.dbBundled" . }}{{ (index .Values .Values.database.type).auth.database }}{{ else }}{{ .Values.database.name }}{{ end }}{{- end -}}
{{- define "moodle.dbUser" -}}{{ if include "moodle.dbBundled" . }}{{ (index .Values .Values.database.type).auth.username }}{{ else }}{{ .Values.database.username }}{{ end }}{{- end -}}
{{- define "moodle.dbSecret" -}}{{ if include "moodle.dbBundled" . }}{{ include (printf "%s.secretName" .Values.database.type) (index .Subcharts .Values.database.type) }}{{ else }}{{ .Values.database.existingSecret }}{{ end }}{{- end -}}
{{- define "moodle.dbKey" -}}{{ if include "moodle.dbBundled" . }}{{ (index .Values .Values.database.type).auth.existingSecretUserPasswordKey }}{{ else }}{{ .Values.database.existingSecretPasswordKey }}{{ end }}{{- end -}}
{{- define "moodle.redisHost" -}}{{ if .Values.redis.enabled }}{{ include "redis.clientServiceName" .Subcharts.redis }}{{ else }}{{ .Values.sessions.host }}{{ end }}{{- end -}}
{{- define "moodle.redisSecret" -}}{{ if .Values.redis.enabled }}{{ include "redis.secretName" .Subcharts.redis }}{{ else }}{{ .Values.sessions.existingSecret }}{{ end }}{{- end -}}
{{- define "moodle.redisKey" -}}{{ if .Values.redis.enabled }}{{ .Values.redis.auth.existingSecretPasswordKey }}{{ else }}{{ .Values.sessions.existingSecretPasswordKey }}{{ end }}{{- end -}}
{{- define "moodle.externalSecretName" -}}{{ if .item.fullnameOverride }}{{ .item.fullnameOverride }}{{ else if .item.name }}{{ include "moodle.nameWithSuffix" (dict "base" (include "moodle.fullname" .root) "suffix" (printf "-%s" .item.name)) }}{{ else }}{{ include "moodle.secretName" .root }}{{ end }}{{- end -}}
{{- define "moodle.httpRouteName" -}}{{ default (include "moodle.fullname" .root) .route.name }}{{- end -}}
{{- define "moodle.validate" -}}
{{- $enabled := 0 -}}
{{- range $engine := list "postgresql" "mysql" "mariadb" -}}
{{- if (index $.Values $engine).enabled -}}
{{- $enabled = add $enabled 1 -}}
{{- if ne $.Values.database.type $engine }}{{ fail (printf "%s.enabled requires database.type=%s and other database subcharts disabled" $engine $engine) }}{{ end -}}
{{- if eq (include "moodle.fullname" $) (include (printf "%s.fullname" $engine) (index $.Subcharts $engine)) }}{{ fail (printf "Moodle and bundled %s resource names collide; set %s.fullnameOverride to a distinct name" $engine $engine) }}{{ end -}}
{{- end -}}
{{- end -}}
{{- if gt $enabled 1 }}{{ fail "Enable only one database subchart" }}{{ end -}}
{{- if and .Values.metrics.prometheusRule.enabled (not .Values.metrics.serviceMonitor.enabled) }}{{ fail "metrics.prometheusRule.enabled requires metrics.serviceMonitor.enabled=true" }}{{ end -}}
{{- if and .Values.metrics.serviceMonitor.enabled (not .Values.metrics.enabled) }}{{ fail "metrics.serviceMonitor.enabled requires metrics.enabled=true" }}{{ end -}}
{{- if and .Values.ingress.enabled (empty .Values.ingress.hosts) }}{{ fail "ingress.hosts must contain at least one host when ingress.enabled=true" }}{{ end -}}
{{- range $labels := list .Values.podLabels .Values.commonLabels -}}
{{- if or (hasKey $labels "app.kubernetes.io/name") (hasKey $labels "app.kubernetes.io/instance") }}{{ fail "podLabels and commonLabels must not override selector labels" }}{{ end -}}
{{- end -}}
{{- if and .Values.externalSecrets.enabled (empty .Values.externalSecrets.items) }}{{ fail "externalSecrets.items must contain at least one item when externalSecrets.enabled=true" }}{{ end -}}
{{- if and .Values.gatewayAPI.enabled (empty .Values.gatewayAPI.httpRoutes) }}{{ fail "gatewayAPI.httpRoutes must not be empty" }}{{ end -}}
{{- if not (include "moodle.dbBundled" .) -}}
{{- if or (empty .Values.database.host) (empty .Values.database.existingSecret) }}{{ fail "External database requires database.host and database.existingSecret" }}{{ end -}}
{{- end -}}
{{- if and .Values.sessions.enabled (not .Values.redis.enabled) (empty .Values.sessions.host) }}{{ fail "Redis sessions require redis.enabled or sessions.host" }}{{ end -}}
{{- if and .Values.redis.enabled (or (not .Values.sessions.enabled) (ne .Values.redis.architecture "standalone")) }}{{ fail "Bundled Redis requires sessions.enabled=true and redis.architecture=standalone" }}{{ end -}}
{{- if or (gt (int .Values.replicaCount) 1) .Values.autoscaling.enabled -}}
{{- if or (not .Values.persistence.enabled) (not (has "ReadWriteMany" .Values.persistence.accessModes)) (not .Values.sessions.enabled) }}{{ fail "Multiple replicas and autoscaling require persistent ReadWriteMany moodledata and Redis sessions" }}{{ end -}}
{{- end -}}
{{- if and .Values.pdb.enabled (not .Values.autoscaling.enabled) (lt (int .Values.replicaCount) 2) }}{{ fail "pdb.enabled requires multiple replicas" }}{{ end -}}
{{- if and .Values.moodle.sslProxy (not (hasPrefix "https://" .Values.moodle.wwwroot)) }}{{ fail "moodle.sslProxy requires an HTTPS moodle.wwwroot" }}{{ end -}}
{{- if and (eq .Values.database.type "postgresql") (hasPrefix "verify-" .Values.database.sslMode) (empty .Values.database.tlsSecret) }}{{ fail "Verified PostgreSQL TLS requires database.tlsSecret" }}{{ end -}}
{{- if and (ne .Values.database.type "postgresql") (eq .Values.database.mysqlSslMode "verify-full") (empty .Values.database.tlsSecret) }}{{ fail "Verified MySQL/MariaDB TLS requires database.tlsSecret" }}{{ end -}}
{{- if and (eq .Values.source.mode "archive") (empty .Values.source.sha256) }}{{ fail "source.sha256 is required for archive mode" }}{{ end -}}
{{- end -}}
