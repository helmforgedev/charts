<!-- SPDX-License-Identifier: Apache-2.0 -->

# SonarQube

SonarQube Community Build for Kubernetes using the official Docker image.
It supports embedded evaluation mode, HelmForge PostgreSQL, external PostgreSQL, plugin automation, and the community branch plugin.

## Install

### HTTPS repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install sonarqube helmforge/sonarqube -f values.yaml
```

### OCI registry

```bash
helm install sonarqube oci://ghcr.io/helmforgedev/helm/sonarqube -f values.yaml
```

## Features

- official `docker.io/library/sonarqube` image
- `embedded` mode for disposable local validation
- `postgresql` mode backed by the HelmForge PostgreSQL subchart
- `external` mode for PostgreSQL-backed production deployments
- generated, existing, or External Secrets Operator-backed database password handling
- optional monitoring passcode secret handling
- plugin download init container with persistent extensions volume
- bundled PostgreSQL wait init container to avoid first-start connection races
- first-class community branch plugin wiring, including Java agents and webapp replacement
- Gateway API `HTTPRoute`, Ingress, and dual-stack Service fields
- default non-root pod security context, dropped Linux capabilities, and read-only root filesystem
- optional NetworkPolicy, PodDisruptionBudget, persistence, extra containers, and extra volumes
- optional extra manifests for small companion resources and self-contained CI fixtures
- Helm test pod that validates the SonarQube system status endpoint

## Architecture

The chart deploys one SonarQube Community Build pod behind a named-port Service.
It connects to embedded evaluation storage, the optional HelmForge PostgreSQL
dependency, or an external PostgreSQL service. Persistent volumes hold data and
extensions; an optional init container installs optionally checksum-verified
plugins before the application starts. See [DESIGN.md](DESIGN.md) for trust
boundaries, backup ownership, observability, and known gaps.

## Examples

Reusable configurations are available in [`examples/`](examples/): bundled
PostgreSQL, external PostgreSQL, production exposure, and the community branch
plugin. The snippets below show the main contracts directly.

## Database Modes

The default `auto` mode uses external settings when provided, then `postgresql.enabled`, and otherwise falls back to embedded evaluation mode. The embedded mode is intentionally scoped to disposable evaluation.

Bundled HelmForge PostgreSQL:

```yaml
sonarqube:
  databaseMode: postgresql

postgresql:
  enabled: true
  auth:
    database: sonarqube
    username: sonar
    password: change-me
```

External PostgreSQL:

```yaml
sonarqube:
  databaseMode: external

database:
  external:
    jdbcUrl: jdbc:postgresql://postgresql.database.svc.cluster.local:5432/sonarqube
    username: sonar
    existingSecret: sonarqube-database
    existingSecretPasswordKey: jdbc-password
```

## External Secrets

```yaml
sonarqube:
  databaseMode: external

database:
  external:
    jdbcUrl: jdbc:postgresql://postgresql.database.svc.cluster.local:5432/sonarqube
    username: sonar

externalSecrets:
  enabled: true
  secretStoreRef:
    name: platform-secrets
    kind: ClusterSecretStore
  database:
    enabled: true
    passwordRemoteRef:
      key: sonarqube/database
      property: password
```

## Community Branch Plugin

The chart can install the community branch plugin and patch the SonarQube web application during startup.

```yaml
communityBranchPlugin:
  enabled: true
  version: "26.4.0"
  jarSha256: ""
  webappSha256: ""
```

The chart pins plugin `26.4.0` independently from the SonarQube image release.
This combination is covered by the chart's plugin validation scenario; review
upstream compatibility notes before selecting another plugin or image version.

See [Community Branch Plugin](docs/community-branch-plugin.md).

Additional plugins accept an optional SHA-256 checksum. URLs are supplied to the
installer through environment variables so shell metacharacters are not
interpreted:

```yaml
plugins:
  enabled: true
  install:
    - name: sonar-auth-oidc
      url: https://artifacts.example.com/sonar-auth-oidc.jar
      sha256: 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
```

## Exposure

Ingress:

```yaml
ingress:
  enabled: true
  ingressClassName: nginx
  hosts:
    - host: sonarqube.example.com
      paths:
        - path: /
          pathType: Prefix
```

Gateway API:

```yaml
gatewayAPI:
  enabled: true
  parentRefs:
    - name: public-gateway
      namespace: gateway-system
  hostnames:
    - sonarqube.example.com
```

Dual-stack Service:

```yaml
service:
  ipFamilyPolicy: PreferDualStack
  ipFamilies:
    - IPv4
    - IPv6
```

## Network Policy

Enable NetworkPolicy after confirming the required ingress controller, database, DNS, plugin download, and external service paths for your cluster.

```yaml
networkPolicy:
  enabled: true
  egress:
    enabled: true
    extraEgress:
      - to:
          - ipBlock:
              cidr: 10.80.0.0/16
        ports:
          - protocol: TCP
            port: 443
```

## Configuration

### Main Values

| Key | Default | Description |
|-----|---------|-------------|
| `image.repository` | `docker.io/library/sonarqube` | Official SonarQube image repository |
| `image.tag` | `26.8.0.126808-community` | SonarQube Community Build image tag |
| `containerPorts.http` | `9000` | Real SonarQube listener port, wired through `SONAR_WEB_PORT` |
| `service.port` | `9000` | Client-facing Service port; targets the named application port |
| `sonarqube.databaseMode` | `auto` | `auto`, `embedded`, `postgresql`, or `external` |
| `postgresql.enabled` | `false` | Deploy HelmForge PostgreSQL as a subchart |
| `waitForDatabase.enabled` | `true` | Wait for bundled PostgreSQL before starting SonarQube |
| `database.external.jdbcUrl` | `""` | JDBC URL when using external mode |
| `database.external.existingSecret` | `""` | Existing database password Secret |
| `externalSecrets.enabled` | `false` | Render ExternalSecret resources |
| `plugins.enabled` | `false` | Enable plugin download init container |
| `communityBranchPlugin.enabled` | `false` | Install and wire the branch plugin |
| `communityBranchPlugin.jarSha256` | `""` | Optional plugin JAR checksum |
| `communityBranchPlugin.webappSha256` | `""` | Optional patched webapp checksum |
| `persistence.data.enabled` | `true` | Persist SonarQube data |
| `persistence.extensions.enabled` | `true` | Persist installed plugins |
| `service.ipFamilyPolicy` | `~` | Optional Kubernetes Service IP family policy |
| `ingress.enabled` | `false` | Render Ingress |
| `gatewayAPI.enabled` | `false` | Render Gateway API HTTPRoute |
| `networkPolicy.enabled` | `false` | Render NetworkPolicy |
| `networkPolicy.egress.extraEgress` | `[]` | Additional complete NetworkPolicy egress rules |
| `pdb.enabled` | `false` | Render PodDisruptionBudget |
| `extraManifests` | `[]` | Additional Kubernetes manifests rendered with the release |

## Production Notes

Before production use, read [Production](docs/production.md).
SonarQube embeds Elasticsearch and requires host kernel settings for production bootstrap checks.
The chart defaults to disabled bootstrap checks for k3d and evaluation; production clusters should set the host requirements and use bundled or external PostgreSQL.

Back up PostgreSQL together with the data and extensions volumes. The logs volume
is optional and is not required to restore application state. The chart does not
schedule backups or restores.

## Troubleshooting

- If the pod remains in `Init`, inspect the database wait or plugin installer init
  container logs with `kubectl logs <pod> -c <container>`.
- If readiness fails, query the configured context path followed by
  `/api/system/status` through the Service and confirm it reports `UP`.
- If plugin installation fails, verify outbound access, artifact compatibility,
  and the configured SHA-256 checksum.
- If production bootstrap checks fail, prepare the node kernel and process limits
  documented in [Production](docs/production.md).

## References

- [SonarQube Community Build](https://docs.sonarsource.com/sonarqube-community-build/)
- [Official SonarQube Docker image](https://hub.docker.com/_/sonarqube)
- [SonarQube Docker source](https://github.com/SonarSource/docker-sonarqube)
- [Community branch plugin](https://github.com/mc1arke/sonarqube-community-branch-plugin)

### Security Scan: `sonarqube`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **92.42425%** |

Security posture acceptable.
