# MongoDB Sharded Cluster

## When to use

Use `sharded` when a single replica set is no longer enough for data volume, throughput, or horizontal distribution requirements.

Common cases:

- large datasets that should be distributed across shards
- workloads with sustained throughput beyond one replica set's practical limits
- multi-tenant or partitionable domains with a clear shard key strategy
- teams already comfortable operating mongos, config servers, and shard replica sets

## What this architecture delivers

- `mongos` routers for client access
- config server replica set
- multiple shard replica sets
- automatic cluster bootstrap and shard registration via Helm hook job
- optional metrics on the deployed components

## What it does not deliver

- automatic shard key design
- application-level query optimization
- simplified operations comparable to standalone or replica set modes

## Environment requirements

- persistent volumes for config servers and shard members
- a clear shard key strategy before production rollout
- applications connecting through `mongos`
- enough cluster capacity to run config servers, multiple shard members, and routers reliably
- an operator-managed authentication bootstrap if the sharded cluster must run with auth enabled

## Operational guidance

`sharded` is the most capable and the most operationally demanding architecture
in this chart. It should be chosen because the workload needs sharding, not
because sharding sounds more robust. The right question is whether the workload
truly needs data distribution, not only failover.

## Common risks

- choosing sharding before validating that a replica set is sufficient
- defining a poor shard key and creating hotspots
- under-sizing config servers or shard storage
- bypassing `mongos` and connecting directly to shard members from applications

## Production practices

- keep config servers at 3 members
- run at least 2 `mongos` replicas for router availability
- size shard replica sets according to write volume and storage growth
- distribute config servers, routers, and shard members across failure domains
- use persistent storage everywhere
- treat the chart's built-in sharded example as an unauthenticated lab topology
- monitor chunk distribution, balancer behavior, replication lag, router health, and disk growth
- test expansion and shard-add operations before doing them in production

## Most relevant values

| Parameter | Description |
|-----------|-------------|
| `architecture` | Must be `sharded` |
| `sharded.mongos.replicaCount` | Number of mongos routers |
| `sharded.configServer.replicaCount` | Config server members |
| `sharded.configServer.persistence.*` | Config server storage |
| `sharded.shards.count` | Number of shards |
| `sharded.shards.membersPerShard` | Members per shard replica set |
| `sharded.shards.persistence.*` | Storage per shard member |
| `sharded.initJob.asHook` | Run `sharded-init` as a post-install hook (default `true`) |
| `sharded.initJob.resources` | Resources for the `sharded-init` bootstrap Job (prefer ≥256Mi/512Mi) |
| `initContainerResources` | Resources for `init-keyfile` on mongos/configsvr/shards |
| `auth.existingKeySecret` | Existing key file secret for internal auth |
| `metrics.enabled` | Exporter sidecar |

When `sharded.initJob.asHook` is `false`, confirm that the existing Job is gone before changing `sharded.initJob.resources` or, with authentication enabled,
`initContainerResources`. Wait for TTL cleanup or delete the completed Job before retrying. Kubernetes will not update an existing Job's Pod template.

## Example

```yaml
architecture: sharded

auth:
  enabled: false

sharded:
  mongos:
    replicaCount: 2
  configServer:
    replicaCount: 3
    persistence:
      size: 20Gi
  shards:
    count: 2
    membersPerShard: 3
    persistence:
      size: 200Gi

metrics:
  enabled: true
```

## When not to use

- when the real need is only failover and redundancy
- when the application does not need shard-based scale
- when the environment requires turnkey root-user initialization through `MONGO_INITDB_ROOT_*`
- when the team is not ready to operate shard keys, balancer behavior, and multi-component MongoDB topology
