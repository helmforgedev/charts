# Ingress and Domain

## Why it matters

Vaultwarden relies on a correct public domain for features such as attachment links and client-facing URLs.

## Recommended pattern

- set `domain` to the external HTTPS URL
- enable ingress with the same hostname
- terminate TLS at ingress or reverse proxy
- if the public URL includes a path or non-default port, keep that exact external URL in `domain`
- the chart automatically prefixes health probe paths with the path component from `domain`

## Domain examples

Public hostname:

```yaml
domain: https://vaultwarden.example.com
```

Public hostname with non-default port:

```yaml
domain: https://vaultwarden.example.com:8443
```

Public hostname behind a path:

```yaml
domain: https://example.com/vaultwarden
```

## Example

```yaml
domain: https://vaultwarden.example.com

ingress:
  enabled: true
  ingressClassName: traefik
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt
  hosts:
    - host: vaultwarden.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - hosts:
        - vaultwarden.example.com
      secretName: vaultwarden-tls
```

## WebSocket note

WebSocket notifications use the same HTTP service and ingress path in this chart. No separate websocket service is required.

For most ingress controllers, the normal HTTP ingress path is enough. If operators use aggressive idle timeouts or proxy buffering defaults, they should validate websocket behavior explicitly after deployment.

The pod binds Vaultwarden/Rocket to `service.targetPort` and the Service exposes it through `service.port`. By default that means:

- `ROCKET_ADDRESS=0.0.0.0`
- `ROCKET_PORT=8085`
- Service port `80`

This keeps the container compatible with `runAsNonRoot` and dropped Linux capabilities while preserving the normal Service and ingress backend port.

## Reverse proxy note

Keep `vaultwarden.proxy.ipHeader` aligned with the actual reverse proxy behavior:

- `X-Real-IP` is a common default
- use `X-Forwarded-For` only when that is what your ingress controller actually forwards
- use `none` if you want Vaultwarden to rely only on the direct remote address

Vaultwarden 1.37.0 and newer also require the direct peer to match
`vaultwarden.proxy.trustedProxies` before accepting that header. The secure default
`local` trusts non-global addresses, which covers most in-cluster ingress paths.
Use explicit IP or CIDR entries when the proxy reaches Vaultwarden from a public
address. Avoid `all` unless every path to the pod is controlled by a trusted proxy.

<!-- @AI-METADATA
type: chart-docs
title: Vaultwarden - Ingress
description: Ingress and domain config

keywords: vaultwarden, ingress, domain, tls

purpose: Ingress and domain configuration with TLS for Vaultwarden
scope: Chart Architecture

relations:
  - charts/vaultwarden/README.md
path: charts/vaultwarden/docs/ingress-and-domain.md
version: 1.0
date: 2026-03-20
-->
