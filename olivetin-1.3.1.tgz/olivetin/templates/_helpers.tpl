{{/* SPDX-License-Identifier: Apache-2.0 */}}

{{- define "olivetin.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "olivetin.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "olivetin.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "olivetin.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "olivetin.labels" -}}
helm.sh/chart: {{ include "olivetin.chart" . }}
{{ include "olivetin.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: helmforge
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "olivetin.selectorLabels" -}}
app.kubernetes.io/name: {{ include "olivetin.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "olivetin.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "olivetin.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "olivetin.httpRouteName" -}}
{{- $root := index . "root" -}}
{{- $route := index . "route" -}}
{{- $fullname := include "olivetin.fullname" $root -}}
{{- $routeName := $route.name | default "" | trunc 32 | trimSuffix "-" -}}
{{- if $routeName -}}
{{- $baseMaxLength := sub 62 (len $routeName) -}}
{{- printf "%s-%s" ($fullname | trunc (int $baseMaxLength) | trimSuffix "-") $routeName | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $fullname -}}
{{- end -}}
{{- end -}}

{{- define "olivetin.externalSecretName" -}}
{{- $root := index . "root" -}}
{{- $item := index . "item" -}}
{{- $fullname := include "olivetin.fullname" $root -}}
{{- $itemName := $item.name | default "external" | trunc 32 | trimSuffix "-" -}}
{{- printf "%s-%s" ($fullname | trunc (int (sub 62 (len $itemName))) | trimSuffix "-") $itemName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "olivetin.image" -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}

{{- define "olivetin.validate" -}}
{{- if and .Values.metrics.serviceMonitor.enabled (not .Values.metrics.enabled) -}}
{{- fail "metrics.enabled must be true when metrics.serviceMonitor.enabled=true" -}}
{{- end -}}
{{- if and .Values.metrics.enabled (eq (int .Values.metrics.port) (int .Values.olivetin.port)) -}}
{{- fail "metrics.port must differ from olivetin.port because OliveTin uses separate listeners" -}}
{{- end -}}
{{- if and .Values.ingress.enabled (empty .Values.ingress.hosts) -}}
{{- fail "ingress.hosts must contain at least one host when ingress.enabled=true" -}}
{{- end -}}
{{- if and .Values.gatewayAPI.enabled (empty .Values.gatewayAPI.httpRoutes) -}}
{{- fail "gatewayAPI.httpRoutes must contain at least one route when gatewayAPI.enabled=true" -}}
{{- end -}}
{{- if and .Values.externalSecrets.enabled (empty .Values.externalSecrets.items) -}}
{{- fail "externalSecrets.items must contain at least one item when externalSecrets.enabled=true" -}}
{{- end -}}
{{- range .Values.olivetin.extraEnv -}}
{{- if eq .name "PORT" -}}
{{- fail "olivetin.extraEnv must not override PORT; use olivetin.port" -}}
{{- end -}}
{{- end -}}
{{- if hasKey .Values.podLabels "app.kubernetes.io/name" -}}
{{- fail "podLabels must not override the selector label app.kubernetes.io/name" -}}
{{- end -}}
{{- if hasKey .Values.podLabels "app.kubernetes.io/instance" -}}
{{- fail "podLabels must not override the selector label app.kubernetes.io/instance" -}}
{{- end -}}
{{- end -}}

{{/* Data PVC claim name */}}
{{- define "olivetin.dataClaimName" -}}
{{- if .Values.persistence.existingClaim -}}
{{- .Values.persistence.existingClaim -}}
{{- else -}}
{{- printf "%s-data" (include "olivetin.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/* ConfigMap checksum annotation */}}
{{- define "olivetin.configChecksum" -}}
checksum/config: {{ (include (print $.Template.BasePath "/configmap.yaml") . | fromYaml).data | toYaml | sha256sum }}
{{- end -}}

{{/*
Render annotations combining commonAnnotations with resource-specific annotations.
Usage:
  {{- include "olivetin.renderAnnotations" (dict "root" . "context" "service") | nindent 2 }}
*/}}
{{- define "olivetin.renderAnnotations" -}}
{{- $root := . -}}
{{- $context := "" -}}
{{- $extra := dict -}}
{{- if kindIs "map" . -}}
  {{- if hasKey . "root" -}}
    {{- $root = .root -}}
    {{- $context = .context | default "" -}}
    {{- $extra = .extra | default dict -}}
  {{- end -}}
{{- end -}}
{{- $specific := dict -}}
{{- if eq $context "service" -}}
  {{- $specific = $root.Values.service.annotations | default dict -}}
{{- else if eq $context "serviceAccount" -}}
  {{- $specific = $root.Values.serviceAccount.annotations | default dict -}}
{{- else if eq $context "ingress" -}}
  {{- $specific = $root.Values.ingress.annotations | default dict -}}
{{- else if eq $context "pvc" -}}
  {{- $specific = $root.Values.persistence.annotations | default dict -}}
{{- else -}}
  {{- $specific = $extra | default dict -}}
{{- end -}}
{{- $merged := merge (deepCopy $specific) ($root.Values.commonAnnotations | default dict) -}}
{{- if $merged }}
annotations:
  {{- toYaml $merged | nindent 2 }}
{{- end }}
{{- end -}}
