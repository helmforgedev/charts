# Scaling and Clustering

## When to use this guide

Read this guide before increasing `replicaCount` above `1` in `mode: production`.

## What scaling means in this chart

Multiple replicas in this chart provide:

- more application instances behind the service
- distributed cache configuration through `KC_CACHE=ispn`
- explicit cache stack selection through `cache.stack`

Multiple replicas in this chart do not provide:

- operator-style cluster lifecycle management
- coordinated failover across application and data layers
- automatic validation of reverse-proxy affinity behavior
- built-in Horizontal Pod Autoscaler behavior

## Current recommendation

For the current chart scope:

- use `replicaCount: 1` when the environment is small, disposable, or operationally simple
- use multiple replicas only with a stable external database, explicit ingress behavior, and clear rollout procedures
- keep `cache.enabled: true` when `replicaCount > 1`
- keep `cache.stack: jdbc-ping` unless there is a tested reason to move away from it
- keep autoscaling outside the chart until there is a stronger Keycloak-specific operational model
- treat `cache.embeddedNetworkBindPort` as an immutable rollout setting; when
  changing it, set `deployment.strategy.type: Recreate` for that rollout so
  old and new pods cannot form separate cache clusters on different ports
- the chart applies the configured cache transport port from the first replica,
  so later scale-out does not change the listener implicitly

## Database bootstrap

Fresh multi-replica startup must serialize the initial Liquibase migration. The
bundled PostgreSQL and MySQL configurations pre-create Liquibase's bookkeeping
tables during database initialization so every Keycloak replica uses the same
lock before applying schema changes.

For an external empty PostgreSQL database, bootstrap the first Keycloak replica
before scaling out, or have the database administrator create both
`databasechangelog` and `databasechangeloglock` as described by the upstream
Keycloak migration guide. Starting multiple replicas concurrently against an
empty database can race while creating those bookkeeping tables.

Bundled and external MySQL use an explicit staged-bootstrap contract because
concurrent Keycloak schema initialization can deadlock on MySQL's Liquibase row
lock. Start with `replicaCount: 1` and
`database.mysqlSchemaInitialized: false`, wait for Keycloak to become ready,
then set `database.mysqlSchemaInitialized: true` while increasing the replica
count. Use the same two-step values transition in GitOps. An existing initialized
schema may set the confirmation to `true` on its first chart deployment.
Bundled PostgreSQL supports a fresh multi-replica installation with its
pre-created bookkeeping tables when Keycloak uses the default `public` schema.
If `database.external.schema` selects another schema, pre-create both
bookkeeping tables in that schema or initialize Keycloak with one replica before
scaling out.

## About `jdbc-ping`

`jdbc-ping` is the current recommended stack in this chart because it keeps node discovery tied to the shared production database instead of requiring Kubernetes-specific discovery plugins.

That helps keep the chart smaller and easier to reason about, but it has limits:

- it is discovery and cache transport plumbing, not a full cluster control plane
- it depends on a healthy shared database
- it does not remove the need for careful rolling updates
- it does not replace reverse-proxy correctness or sticky-session behavior

## Scheduling recommendations

When running multiple replicas in production:

- use at least two or three replicas depending on the failure domain policy
- add anti-affinity or topology spread constraints
- use a `PodDisruptionBudget`
- avoid single-node packing for all replicas

The chart now applies scheduling defaults automatically when all of these are true:

- `replicaCount > 1`
- `cache.multiReplicaDefaults.enabled: true`
- `affinity` is not set explicitly
- `topologySpreadConstraints` is not set explicitly

Default behavior:

- soft pod anti-affinity on `kubernetes.io/hostname`
- topology spread on `kubernetes.io/hostname` with `ScheduleAnyway`

If the environment needs stricter placement, define `affinity` or `topologySpreadConstraints` explicitly and the chart will stop injecting the defaults.

The chart already exposes:

- `affinity`
- `topologySpreadConstraints`
- `pdb`
- `priorityClassName`

## Probe tuning

The chart exposes configurable management probes:

- `probes.liveness`
- `probes.readiness`
- `probes.startup`

Use the defaults first. Increase startup timing only when the environment consistently needs more time for image pull, JVM bootstrap, or cluster convergence.

For environments with heavier provider or theme loading, the chart also exposes:

- `probes.profile: heavy-startup`

That profile keeps the same probe structure but gives the pod more time to become healthy during startup.

## Rollout and rollback guidance

For production rollouts:

- update one Keycloak version at a time
- for patch releases in the same 26.6 minor stream, use rolling updates but still validate readiness, proxy behavior, and database logs before widening traffic
- validate readiness on the management service
- validate public login and admin console access before widening traffic
- confirm the database schema migration path is understood before rollout
- keep a rollback plan for image, chart values, ingress, and proxy behavior together
- keep `terminationGracePeriodSeconds` high enough for graceful HTTP shutdown and proxy connection draining

If providers or themes are mounted:

- confirm compatibility against the target Keycloak version before rollout
- expect restart or rollout behavior to matter more than in a plain image-only deployment

## Readiness expectations

Application readiness is only one part of production health. Before calling a rollout successful, confirm:

- the public hostname serves the expected discovery and login endpoints
- the admin hostname reaches the intended admin flows
- management health remains healthy during and after the rollout
- session behavior at the ingress layer matches the chosen controller settings

## Example production baseline

```yaml
mode: production

replicaCount: 3

cache:
  enabled: true
  stack: jdbc-ping

pdb:
  enabled: true
  minAvailable: 1
```

## Official product references

- [Keycloak caching and transport stacks](https://www.keycloak.org/server/caching)
- [Keycloak production configuration](https://www.keycloak.org/server/configuration-production)
- [Keycloak release notes](https://www.keycloak.org/docs/latest/release_notes/index.html)

<!-- @AI-METADATA
type: chart-docs
title: Keycloak - Scaling
description: Multi-replica with cache and clustering

keywords: keycloak, scaling, clustering, jdbc-ping

purpose: Multi-replica Keycloak setup with Infinispan cache and JDBC-based clustering
scope: Chart Architecture

relations:
  - charts/keycloak/README.md
  - charts/keycloak/docs/production-capacity.md
path: charts/keycloak/docs/scaling-and-clustering.md
version: 1.0
date: 2026-03-20
-->
