# Metabase Helm Chart

Deploy [Metabase](https://www.metabase.com) on Kubernetes using the official
[metabase/metabase](https://hub.docker.com/r/metabase/metabase) Docker image.
Open-source BI platform with visual data exploration, SQL editor, and shareable dashboards connecting to 60+ databases.

## Features

- **Visual data exploration** — point-and-click queries, no SQL required
- **SQL editor** — native SQL with autocomplete and snippets
- **60+ database connectors** — PostgreSQL, MySQL, BigQuery, Redshift, and more
- **PostgreSQL metadata store** — bundled subchart or external database
- **Backups** — optional PostgreSQL dump CronJob for S3-compatible object storage
- **Auto-generated encryption key** — protects saved database credentials
- **JVM tuning** — configurable JAVA_OPTS for memory optimization
- **Ingress support** — TLS with cert-manager
- **Gateway API** — HTTPRoute for clusters running Envoy Gateway or similar
- **Dual-stack networking** — IPv4/IPv6 service support
- **External Secrets Operator** — ExternalSecret for Vault, AWS Secrets Manager, and more

## Installation

**HTTPS repository:**

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install metabase helmforge/metabase -f values.yaml
```

**OCI registry:**

```bash
helm install metabase oci://ghcr.io/helmforgedev/helm/metabase -f values.yaml
```

## Basic Example

```yaml
# values.yaml — default values deploy with bundled PostgreSQL
# No configuration needed for a basic setup
```

After deploying, access Metabase:

```bash
kubectl port-forward svc/<release>-metabase 3000:80
# Open http://localhost:3000 to complete the setup wizard
```

## External Database

```yaml
postgresql:
  enabled: false

database:
  external:
    host: postgres.example.com
    name: metabase
    username: metabase
    existingSecret: metabase-db-credentials
```

## JVM Tuning

```yaml
metabase:
  javaOpts: "-Xmx2g -Xms1g"

resources:
  requests:
    memory: 2Gi
  limits:
    memory: 3Gi
```

## Air-Gapped or Proxied Registries

The `wait-for-db` init container image is configurable separately from the main
Metabase image, so proxy-based environments can mirror both images:

```yaml
image:
  repository: registry.example.com/proxy/metabase/metabase
  tag: v0.63.14

waitForDatabase:
  image:
    repository: registry.example.com/proxy/library/busybox
    tag: "1.37"
```

Use `extraInitContainers` with `extraVolumes` and `extraVolumeMounts` when you
need to prepare files before Metabase starts, for example JDBC drivers mounted
into a shared plugin directory.

## Dual-Stack Service

```yaml
service:
  ipFamilyPolicy: PreferDualStack
  ipFamilies:
    - IPv4
    - IPv6
```

## Gateway API (HTTPRoute)

Requires Gateway API CRDs and a compatible controller (e.g. Envoy Gateway).

```yaml
gateway:
  enabled: true
  parentRefs:
    - name: envoy-gateway
      namespace: envoy-gateway-system
  hostnames:
    - metabase.example.com
```

> **Note:** `gateway.parentRefs` is required when `gateway.enabled=true`.
> Existing releases that still carry `gatewayAPI.enabled`, `gatewayAPI.gatewayName`,
> and `gatewayAPI.gatewayNamespace` from older chart values remain supported as a
> deprecated upgrade alias. New configuration should use `gateway.parentRefs`.

## External Secrets Operator (ESO)

Requires ESO installed. Set `metabase.existingSecret` so the chart-managed Secret is suppressed and the ExternalSecret is the single source of truth.

```yaml
metabase:
  existingSecret: metabase-eso-secret
  existingSecretKey: encryption-secret-key

externalSecrets:
  enabled: true
  secretStoreRef:
    name: vault-backend
    kind: ClusterSecretStore
  data:
    - secretKey: encryption-secret-key
      remoteRef:
        key: metabase/credentials
        property: encryption-secret-key
```

## Key Values

| Key | Default | Description |
|-----|---------|-------------|
| `image.repository` | `docker.io/metabase/metabase` | Metabase container image repository |
| `image.tag` | `v0.63.14` | Metabase container image tag |
| `waitForDatabase.image.repository` | `docker.io/library/busybox` | Wait-for-db init container image repository |
| `waitForDatabase.image.tag` | `1.37` | Wait-for-db init container image tag |
| `waitForDatabase.image.pullPolicy` | `IfNotPresent` | Wait-for-db init container image pull policy |
| `metabase.port` | `3000` | Application port |
| `metabase.encryptionSecretKey` | `""` | Encryption key (auto-generated) |
| `metabase.siteUrl` | `""` | Public site URL |
| `metabase.aiFeaturesEnabled` | `false` | Enable Metabase AI features after configuring a supported provider |
| `metabase.javaTimezone` | `UTC` | Java timezone |
| `metabase.javaOpts` | `""` | JVM memory options |
| `probes.startup.initialDelaySeconds` | `90` | Startup probe delay for first-run migrations and PostgreSQL bootstrap |
| `postgresql.enabled` | `true` | Deploy HelmForge PostgreSQL subchart (`2.0.4`) |
| `postgresql.standalone.persistence.size` | `8Gi` | PostgreSQL standalone PVC size |
| `resources.requests.memory` | `512Mi` | Metabase memory request |
| `resources.limits.memory` | `2Gi` | Metabase memory limit |
| `ingress.enabled` | `false` | Enable ingress |
| `service.port` | `80` | Service port |
| `service.ipFamilyPolicy` | `~` | IP family policy (`SingleStack`, `PreferDualStack`, `RequireDualStack`) |
| `service.ipFamilies` | `[]` | IP families override (`IPv4`, `IPv6`) |
| `extraInitContainers` | `[]` | Additional init containers rendered after `wait-for-db` |
| `gateway.enabled` | `false` | Enable Gateway API HTTPRoute |
| `gateway.parentRefs` | `[]` | Gateway parentRefs (required when `gateway.enabled=true`) |
| `gateway.hostnames` | `[]` | HTTPRoute hostnames |
| `gateway.path` | `/` | HTTPRoute path match value |
| `gateway.pathType` | `PathPrefix` | HTTPRoute path match type |
| `externalSecrets.enabled` | `false` | Render ExternalSecret resource |
| `externalSecrets.apiVersion` | `external-secrets.io/v1` | ExternalSecret API version |
| `externalSecrets.refreshInterval` | `"0"` | Refresh interval (`"0"` = one-time sync) |
| `externalSecrets.secretStoreRef.name` | `""` | SecretStore name (required when enabled) |
| `externalSecrets.secretStoreRef.kind` | `SecretStore` | SecretStore kind |
| `externalSecrets.data` | `[]` | Remote key mappings (must include encryption key entry) |

## Upgrade Notes

Metabase `v0.63.14` is the public maintenance release that incorporates the
security-hardening changes from private releases 63.3 through 63.13, plus
administration, database, and querying fixes. Back up the Metabase application
database and review the [official Metabase 63 changelog](https://www.metabase.com/changelog/63#metabase-6314)
before upgrading. Keep the encryption key stable and validate the `/api/health`
endpoint after rollout.

## Examples

- [Production](examples/production.yaml)
- [External PostgreSQL](examples/external-db.yaml)
- [S3 backup](examples/backup.yaml)

## More Information

- [Chart design](DESIGN.md)
- [Database and backups](docs/database.md)
- [Production operations](docs/production.md)
- [Metabase documentation](https://www.metabase.com/docs/latest/)
- [Source code](https://github.com/helmforgedev/charts/tree/main/charts/metabase)

### 🟢 Security Scan: `metabase`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **86.36364%** |

> ✅ Security posture acceptable.

<!-- @AI-METADATA
type: chart-readme
title: Metabase Helm Chart
description: README for the Metabase open-source BI platform Helm chart

keywords: metabase, bi, analytics, dashboard, visualization, postgresql, gateway-api, external-secrets, dual-stack

purpose: Chart installation, configuration, and usage documentation
scope: Chart

relations:
  - charts/metabase/DESIGN.md
  - charts/metabase/docs/database.md
  - charts/metabase/docs/production.md
  - charts/metabase/examples/production.yaml
  - charts/metabase/examples/external-db.yaml
  - charts/metabase/examples/backup.yaml
  - charts/metabase/values.yaml
path: charts/metabase/README.md
version: 1.2
date: 2026-06-02
-->
