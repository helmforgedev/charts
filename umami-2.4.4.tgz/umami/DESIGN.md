# Umami Chart Design

This chart packages Umami as a single web Deployment backed by PostgreSQL. The chart keeps the default install small for local use while exposing the controls needed for production deployments.

## Scope

The chart runs Umami web analytics as one Deployment backed by the
HelmForge PostgreSQL subchart or an external PostgreSQL server, with
optional Ingress or Gateway API exposure, External Secrets, NetworkPolicy,
PodDisruptionBudget, and S3 backups of the database.

Goals:

- Keep a working default install for development and demos.
- Support production deployments without raw template overrides.
- Prefer structured values for common Umami runtime settings.
- Support both bundled and external PostgreSQL.
- Allow platform-owned secrets through External Secrets Operator.
- Support modern Kubernetes exposure through Gateway API while keeping Ingress.
- Make network, availability, and backup controls explicit.

## Architecture

### Default topology

```mermaid
flowchart LR
  user[kubectl port-forward] --> svc[Service ClusterIP<br/>release-umami:80]
  svc --> deploy[Umami Deployment<br/>1 replica]
  deploy -->|DATABASE_URL| pg[(PostgreSQL<br/>HelmForge chart)]
```

Default installs generate the application and database secrets and do not expose Umami publicly.

### Production topology

```mermaid
flowchart LR
  internet[Internet] -->|HTTPS| edge[Gateway or Ingress]
  edge --> route[HTTPRoute<br/>analytics.example.com]
  route --> svc[Service<br/>ClusterIP or dual-stack]
  svc --> deploy[Umami Deployment<br/>2+ replicas, PDB, resources]
  deploy --> db[(Managed PostgreSQL<br/>or database operator)]
```

Recommended production values use a stable APP_SECRET, external PostgreSQL, explicit resource requests, Gateway API or Ingress TLS, a PDB, and egress-aware NetworkPolicy.

### External database preparation

Umami's first migration creates `pgcrypto`. Some PostgreSQL services allow the application owner to create extensions,
while others require an administrative user. The chart supports an optional `prepare-external-db` init container for the
second case.

```mermaid
flowchart TB
  admin[Admin Secret<br/>postgres-password] -->|valueFrom| wait[wait-for-db]
  wait -->|ready| prepare[prepare-external-db<br/>postgres client]
  prepare -->|CREATE EXTENSION| ext[(External PostgreSQL<br/>umami database)]
  prepare -->|success| app[Umami container]
```

This is opt-in and only active when `postgresql.enabled=false`. It lets operators keep the runtime Umami user least-privileged while still preparing required extensions during installation.

### External Secrets

```mermaid
flowchart LR
  es[ExternalSecret<br/>external-secrets.io] -->|reconciled by| eso[External Secrets Operator]
  eso -->|reads| backend[(Secret backend<br/>Vault, AWS, GCP)]
  eso -->|writes| secret[Kubernetes Secret<br/>app, db, backup credentials]
  secret -->|envFrom and valueFrom| app[Umami Deployment]
  secret -->|envFrom and valueFrom| backup[Backup CronJob]
```

The chart renders `external-secrets.io/v1` resources only when enabled. It never requires External Secrets Operator for default installs.

### Backups

```mermaid
flowchart LR
  cron[Backup CronJob<br/>postgres tools] -->|pg_dump| pg[(PostgreSQL<br/>bundled or external)]
  cron -->|upload| s3[(S3-compatible<br/>object storage)]
```

The backup job is optional and designed for smaller self-hosted installations.
Production teams should still validate restores and may prefer database-native backups from their PostgreSQL operator
or managed database service.

## Design Choices

### Runtime configuration

The chart maps common Umami environment variables to structured values. This makes production values easier to review than large `extraEnv` blocks:

- `APP_SECRET` from generated, existing, or external-managed Secret.
- `DATABASE_URL` composed by chart helpers.
- `DISABLE_TELEMETRY` and `DISABLE_UPDATES` default to true.
- `FORCE_SSL`, `CLIENT_IP_HEADER`, `COLLECT_API_ENDPOINT`, `TRACKER_SCRIPT_NAME`, `ALLOWED_FRAME_URLS`, and related settings are optional structured values.

`extraEnv` remains available for upstream settings that are not modeled yet.
`extraInitContainers` can prepare shared volumes before Umami starts, and pairs
with `extraVolumes` and `extraVolumeMounts` for cases such as GeoIP databases or
organization-owned assets.
`BASE_PATH` is intentionally not modeled because Umami v3 treats it as a build-time setting for the stock image.

## Security Boundary

- Pods run as the image user `nextjs` (uid 1001) with `runAsNonRoot`, no
  privilege escalation, every capability dropped, `RuntimeDefault` seccomp,
  and no ServiceAccount token. The container security context also applies to
  the chart init containers (`wait-for-db`, `prepare-external-db`), but not to
  `extraInitContainers`, which are rendered as provided. The root filesystem
  stays writable because the upstream startup scripts write inside the image
  tree.
- Umami's first migration creates the `admin` user with the upstream default
  password `umami`. The chart cannot set it; change it immediately after the
  first login and keep the instance private until then.
- Secrets can be user-provided or managed by External Secrets Operator.
- NetworkPolicy is opt-in because clusters and CNIs vary.
- Public exposure is opt-in through Ingress or Gateway API.
- Production examples avoid embedding secret values in Helm values.

## Observability Boundary

- Startup, liveness, and readiness probes call `/api/heartbeat`, which
  confirms the Next.js server answers; it does not check PostgreSQL.
- Logs go to the container stdout; `umami.debug` enables upstream debug
  namespaces.
- Umami exposes no Prometheus endpoint, so the chart ships no ServiceMonitor.

## Production Boundary

Umami is stateless at the pod layer. Horizontal scaling depends on a shared PostgreSQL database and a stable APP_SECRET. Enable:

- `replicaCount: 2` or higher
- `pdb.enabled: true`
- production resources
- external PostgreSQL or a highly available PostgreSQL operator
- `database.external.init.enabled` when the application user cannot create required extensions

## Dual Stack

The Service supports `ipFamilyPolicy` and `ipFamilies`. The chart does not force dual-stack by default because the Kubernetes cluster and CNI must provide IPv6 support.

## Gateway API

Gateway API support renders an `HTTPRoute` using `gateway.networking.k8s.io/v1`.
The chart expects the cluster to already provide Gateway API CRDs and a Gateway implementation.
Ingress remains available for clusters that have not adopted Gateway API.

## Current Gaps and Improvement Candidates

- The initial `admin` password cannot be seeded from a Secret.
- `gatewayAPI` renders a single HTTPRoute from `parentRefs`, `hostnames`, and
  `matches` instead of the `gatewayAPI.httpRoutes` list used by newer charts.
- The backup CronJob dumps PostgreSQL only and does not reuse the application
  security context.

## Explicit Non-Goals

- Building custom Umami images, for example to change `BASE_PATH`.
- Managing PostgreSQL high availability; use a PostgreSQL operator or a
  managed service.
- Installing Gateway API CRDs, a Gateway implementation, or External Secrets
  Operator.

## Validation Strategy

Chart changes should be validated with:

- `helm lint`
- `helm lint --strict`
- `helm unittest`
- render of every `ci/*.yaml`
- `kubeconform -strict`
- `ah lint`
- K3D install with bundled PostgreSQL
- K3D install with external PostgreSQL
- pod logs and namespace events inspection

Generated dependency artifacts such as `Chart.lock` and `charts/` are not committed in this repository workflow.
