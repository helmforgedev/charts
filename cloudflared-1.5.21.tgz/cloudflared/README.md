# Cloudflare Tunnel (cloudflared) Helm Chart

Deploy [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/) on Kubernetes using the official
[cloudflare/cloudflared](https://hub.docker.com/r/cloudflare/cloudflared) Docker image.
Secure, outbound-only connections between your cluster and Cloudflare's network require no open ports or public IP.

## Features

- **Zero-trust networking** — no inbound firewall rules needed
- **Remotely-managed** — configure routes in the Cloudflare dashboard
- **Quick tunnel default** — installable demo and smoke-test mode without a token
- **High availability ready** — production values can enable 2+ replicas with PodDisruptionBudget
- **Prometheus metrics** — `/ready` and `/metrics` on port 2000
- **ServiceMonitor** — optional Prometheus Operator integration
- **Existing secrets** — bring your own Secret for the tunnel token
- **External Secrets** — optional External Secrets Operator integration for tunnel tokens
- **Quick tunnel mode** — optional ephemeral mode for demos and smoke tests

## Architecture

Cloudflared initiates outbound connections from the Deployment to Cloudflare's
edge. Managed tunnels and URL-mode quick tunnels proxy requests to the
configured origin URL, which can be a cluster-internal Service. The default
quick tunnel uses cloudflared's built-in hello-world origin and does not use a
tunnel token or cluster origin Service. The chart does not render Kubernetes
Ingress or configure Cloudflare hostnames and routes. See
[DESIGN.md](DESIGN.md) for the topology and responsibility boundaries.

## Installation

**HTTPS repository:**

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install cloudflared helmforge/cloudflared -f values.yaml
```

**OCI registry:**

```bash
helm install cloudflared oci://ghcr.io/helmforgedev/helm/cloudflared -f values.yaml
```

## Quick Start

Default installs run an ephemeral quick tunnel for demos and smoke tests. For a
managed Cloudflare Tunnel, create a tunnel in the
[Cloudflare dashboard](https://one.dash.cloudflare.com) under **Networks → Tunnels**,
copy the tunnel token, and deploy:

```yaml
# values.yaml
tunnel:
  quickTunnel:
    enabled: false
  token: "eyJhIjoiY2Y..."
```

Then configure public hostnames in the dashboard to route traffic to your
Kubernetes services (for example, `http://my-service.default.svc:80`).

## Using an Existing Secret

```yaml
tunnel:
  quickTunnel:
    enabled: false
  existingSecret: my-tunnel-secret
  existingSecretKey: token
```

Create the secret beforehand:

```bash
kubectl create secret generic my-tunnel-secret \
  --from-literal=token=eyJhIjoiY2Y...
```

## External Secrets

When your cluster already runs External Secrets Operator, render an `ExternalSecret`
for the tunnel token and point the Deployment at the generated Kubernetes Secret:

```yaml
tunnel:
  quickTunnel:
    enabled: false
  existingSecret: cloudflared-tunnel-token

externalSecrets:
  enabled: true
  secretStoreRef:
    name: platform-secrets
    kind: ClusterSecretStore
  data:
    - secretKey: token
      remoteRef:
        key: cloudflared/tunnel
        property: token
```

## Quick Tunnel Mode

Quick tunnel mode runs an ephemeral tunnel without a Cloudflare-managed tunnel token.
It is enabled by default for tokenless installs. Use it for demos and smoke
tests only; production deployments should set `tunnel.quickTunnel.enabled=false`
and use `tunnel.token` or `tunnel.existingSecret`.

```yaml
tunnel:
  quickTunnel:
    enabled: true
```

## Production Example

```yaml
tunnel:
  quickTunnel:
    enabled: false
  existingSecret: cloudflare-tunnel

replicaCount: 2

pdb:
  enabled: true
  minAvailable: 1

resources:
  requests:
    cpu: 50m
    memory: 64Mi
  limits:
    memory: 128Mi

serviceMonitor:
  enabled: true
  labels:
    release: prometheus

topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: DoNotSchedule
    labelSelector:
      matchLabels:
        app.kubernetes.io/name: cloudflared
```

## Default Values

| Key | Default | Description |
|-----|---------|-------------|
| `tunnel.token` | `""` | Tunnel token from Cloudflare dashboard |
| `tunnel.existingSecret` | `""` | Existing secret with tunnel token |
| `tunnel.existingSecretKey` | `token` | Key in the existing secret |
| `tunnel.quickTunnel.enabled` | `true` | Enable ephemeral quick tunnel mode for demos and smoke tests |
| `tunnel.quickTunnel.helloWorld` | `true` | Use cloudflared's built-in hello-world origin |
| `tunnel.quickTunnel.url` | `http://localhost:8080` | Origin URL for quick tunnel URL mode |
| `externalSecrets.enabled` | `false` | Render an ExternalSecret for the tunnel token |
| `externalSecrets.secretStoreRef.name` | `""` | SecretStore or ClusterSecretStore name |
| `externalSecrets.secretStoreRef.kind` | `SecretStore` | Secret store kind |
| `externalSecrets.data` | `[]` | ExternalSecret data mappings |
| `replicaCount` | `1` | Number of replicas |
| `cloudflared.logLevel` | `info` | Log level |
| `cloudflared.noAutoupdate` | `true` | Disable auto-update |
| `cloudflared.metricsPort` | `2000` | Metrics listen port |
| `cloudflared.extraArgs` | `[]` | Extra cloudflared arguments |
| `pdb.enabled` | `false` | Create PodDisruptionBudget |
| `pdb.minAvailable` | `1` | Min available during disruption |
| `metrics.enabled` | `true` | Expose metrics service |
| `serviceMonitor.enabled` | `false` | Create Prometheus ServiceMonitor |
| `service.port` | `2000` | Metrics service port |
| `service.ipFamilyPolicy` | `""` | Service IP family policy |
| `service.ipFamilies` | `[]` | Ordered list of Service IP families |
| `resources.requests.cpu` | `50m` | Default CPU request |
| `resources.requests.memory` | `64Mi` | Default memory request |
| `resources.limits.cpu` | `250m` | Default CPU limit |
| `resources.limits.memory` | `128Mi` | Default memory limit |
| `securityContext.runAsUser` | `65532` | Non-root container user |

## Important Notes

- **Do not use HPA** — downscaling terminates active tunnel connections
- **Routing is dashboard-managed** — this chart does not configure ingress rules; use the Cloudflare dashboard to map public hostnames to internal services
- **No ingress template** — cloudflared replaces traditional ingress controllers

## Upgrade Notes

Cloudflared 2026.10.1 retains the existing quick-tunnel and managed-token
contracts. It improves QUIC request cancellation and DNS resolution retries.
The new normalized-path access-rule behavior is present but disabled by default,
so the forwarded request path and existing ingress selection remain unchanged.

Review the
[official 2026.10.1 release](https://github.com/cloudflare/cloudflared/releases/tag/2026.10.1)
before production rollout.

For chart upgrades, pin the target version and preserve tunnel mode, Secret name
and key, replica count, disruption budget, metrics port, and transport options.
Use `--reuse-values` only after auditing existing overrides. With
`--reset-values`, restate every non-default tunnel, Secret, availability,
transport, and monitoring setting. A chart upgrade must not rotate or replace a
managed tunnel token.

## Troubleshooting

Inspect Pod events and cloudflared logs first. A failing readiness probe means no
active edge connection; verify DNS and outbound access for the selected HTTP/2
or QUIC transport. If the tunnel connects but traffic fails, validate the Public
Hostname route and cluster origin Service independently. Authentication errors
usually indicate a changed Secret name, key, or token. Metrics availability on
port 2000 does not prove that a public hostname reaches its origin.

## Security Scan

### Security Scan: `cloudflared`

| Framework | Score |
|---|---|
| MITRE + NSA + SOC2 | **87.88%** |

Security posture acceptable. Verified with Kubescape 4.0.14 against rendered default manifests.

Local details:

| Framework | Score |
|---|---|
| MITRE | 100.00% |
| NSA | 85.00% |
| SOC2 | 80.00% |

The rendered-manifest scan reports non-root, service-account token mapping,
and network-isolation findings. The container explicitly runs as UID 65532;
the chart does not create a NetworkPolicy. Review the service account and
platform network policies for the deployment environment.

## More Information

- [Cloudflare Tunnel documentation](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)
- [Kubernetes deployment guide](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/deploy-tunnels/deployment-guides/kubernetes/)
- [Architecture overview](docs/architecture.md)

The startup probe allows 180 seconds of failed readiness checks, plus its initial
delay, so edge registration retries and protocol fallback can complete without
a premature container restart. Readiness still requires a live tunnel.

Quick tunnels use HTTP/2 by default so the demo does not require outbound UDP.
Set `tunnel.quickTunnel.protocol` to `auto` or `quic` when appropriate. This
setting applies only to ephemeral quick tunnels; managed tunnels retain the
upstream transport default and can use `cloudflared.extraArgs` for overrides.
