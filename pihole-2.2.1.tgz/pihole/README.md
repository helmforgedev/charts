<!-- SPDX-License-Identifier: Apache-2.0 -->

# Pi-hole DNS Sinkhole

A Helm chart for deploying [Pi-hole](https://pi-hole.net/) on Kubernetes using the official [pihole/pihole](https://hub.docker.com/r/pihole/pihole) container image.

## Installation

### HTTPS Repository

```bash
helm repo add helmforge https://repo.helmforge.dev
helm repo update
helm install pihole helmforge/pihole
```

### OCI Registry

```bash
helm install pihole oci://ghcr.io/helmforgedev/helm/pihole
```

## Quick Start

```bash
helm install pihole oci://ghcr.io/helmforgedev/helm/pihole \
  --set admin.password=changeme \
  --set serviceDns.loadBalancerIP=192.168.1.53
```

## Features

- **Network-Wide Ad Blocking** — DNS-level filtering for all devices on the network
- **Custom DNS Records** — Local A records, CNAME records, and dnsmasq configuration
- **Unbound Sidecar** — Optional recursive DNS resolver eliminating third-party DNS dependency
- **Pi-hole v6+ Support** — Uses `FTLCONF_` environment variables for modern configuration
- **Prometheus Metrics** — pihole-exporter sidecar with ServiceMonitor support
- **Ingress Support** — Configurable ingress with TLS for the web admin interface
- **DHCP Support** — Optional DHCP server with hostNetwork mode
- **DNSSEC Validation** — Optional DNS Security Extensions
- **Configurable Listeners** — DNS and web ports configure Pi-hole FTL itself
- **Immutable Images** — All workload and backup images are pinned by digest
- **Ingress Policy** — NetworkPolicy limits inbound traffic to declared ports

### Security Scan: `pihole`

Every PR runs Kubescape against the rendered default manifests using the MITRE,
NSA, and SOC2 frameworks. The authoritative score is posted on the PR. The
chart drops all capabilities before adding only the official image's required
runtime set, disables privilege escalation and API token mounting, uses
runtime-default seccomp, pins images by digest, and creates an ingress
NetworkPolicy. Root bootstrap and writable Pi-hole configuration remain
documented upstream constraints.

| Framework | Score |
| --- | --- |
| MITRE + NSA + SOC2 | 90.90909% |

## Configuration

### Minimal (Simple Setup)

```yaml
admin:
  password: "change-me"

serviceDns:
  type: LoadBalancer
  loadBalancerIP: "192.168.1.53"
```

### Production (Full Setup)

```yaml
pihole:
  timezone: America/Sao_Paulo
  dnssec: true

admin:
  existingSecret: pihole-admin
  existingSecretKey: password

unbound:
  enabled: true
  resources:
    requests:
      cpu: 50m
      memory: 64Mi
    limits:
      cpu: 200m
      memory: 128Mi

dns:
  customRecords:
    - "192.168.1.1 router.home"
    - "192.168.1.10 nas.home"
  cnameRecords:
    - "cname=media.home,nas.home"

persistence:
  enabled: true
  size: 2Gi

resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 500m
    memory: 512Mi

serviceDns:
  type: LoadBalancer
  loadBalancerIP: "192.168.1.53"
  externalTrafficPolicy: Local

ingress:
  enabled: true
  ingressClassName: traefik
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: pihole.home
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: pihole-tls
      hosts:
        - pihole.home

metrics:
  enabled: true
  serviceMonitor:
    enabled: true
    labels:
      release: prometheus
```

## Parameters

### Pi-hole

| Key | Default | Description |
|-----|---------|-------------|
| `image.repository` | `docker.io/pihole/pihole` | Pi-hole container image repository |
| `image.tag` | `2026.10.0` | Pi-hole container image tag (official upstream release 2026.10.0) |
| `image.digest` | pinned SHA-256 | Immutable Pi-hole image digest |
| `image.pullPolicy` | `IfNotPresent` | Pi-hole image pull policy |
| `containerPorts.dns` | `53` | Pi-hole FTL DNS listener port (TCP and UDP) |
| `containerPorts.http` | `80` | Primary Pi-hole FTL HTTP listener used by the Service, probes, and metrics |
| `pihole.timezone` | `UTC` | Timezone for logs and scheduled tasks |
| `pihole.upstreamDns` | `8.8.8.8;8.8.4.4` | Upstream DNS servers (semicolon-delimited) |
| `pihole.listeningMode` | `ALL` | DNS listening mode (LOCAL, ALL, SINGLE, BIND) |
| `pihole.webserverPort` | `""` | Full FTL `webserver.port` value; empty derives from `containerPorts.http` |
| `pihole.dnssec` | `false` | Enable DNSSEC validation |
| `pihole.ftl.rateLimit` | `1000` | Rate limiting query count per client; set to `0` to disable |
| `pihole.ftl.rateLimitInterval` | `60` | Rate limiting interval in seconds |
| `pihole.extraEnv` | `[]` | Additional environment variables |

Image tags and digests form a pair. When overriding any image tag, also set
the matching digest to the digest published for that exact tag; Kubernetes
resolves the digest as the deployed image identity.

### Admin

| Key | Default | Description |
|-----|---------|-------------|
| `admin.password` | `""` | Web admin password (auto-generated if empty) |
| `admin.existingSecret` | `""` | Existing secret for admin password |
| `admin.existingSecretKey` | `password` | Key in existing secret |

### DNS Records

| Key | Default | Description |
|-----|---------|-------------|
| `dns.customRecords` | `[]` | Custom local DNS A records ("IP HOSTNAME") |
| `dns.cnameRecords` | `[]` | Custom CNAME records (dnsmasq format) |
| `dns.customDnsmasq` | `[]` | Custom dnsmasq configuration lines |
| `dns.adlists` | `[]` | Blocklist URLs for gravity database |
| `dns.whitelist` | `[]` | Whitelisted domains |
| `dns.blacklist` | `[]` | Blacklisted domains |
| `dns.regex` | `[]` | Regex filters for blocking |

### Gravity

| Key | Default | Description |
|-----|---------|-------------|
| `gravity.enabled` | `true` | Reconcile Pi-hole gravity schema and Helm-managed lists before Pi-hole starts |
| `gravity.updateOnInit` | `true` | Run `pihole -g` in a follow-up init container after Helm-managed lists are reconciled |
| `gravity.resources` | requests `50m/64Mi`, limits `200m/128Mi` | Resources for the gravity schema/list init container |
| `gravity.updateResources` | requests `100m/128Mi`, limits `500m/512Mi` | Resources for the gravity update init container |

### Persistence

| Key | Default | Description |
|-----|---------|-------------|
| `persistence.enabled` | `true` | Enable persistent storage |
| `persistence.storageClass` | `""` | Storage class |
| `persistence.accessMode` | `ReadWriteOnce` | PVC access mode |
| `persistence.size` | `1Gi` | PVC size |
| `persistence.existingClaim` | `""` | Use existing PVC |

### Services

| Key | Default | Description |
|-----|---------|-------------|
| `hostNetwork` | `false` | Use host network for the main Pi-hole pod |
| `dnsPolicy` | `""` | Pod DNS policy; defaults to `ClusterFirstWithHostNet` when host networking is enabled |
| `serviceDns.type` | `LoadBalancer` | DNS service type |
| `serviceDns.port` | `53` | DNS port |
| `serviceDns.loadBalancerIP` | — | Fixed IP for DNS stability |
| `serviceDns.externalTrafficPolicy` | — | External traffic policy |
| `serviceWeb.type` | `ClusterIP` | Web admin service type |
| `serviceWeb.port` | `80` | Web admin port |

`serviceDns.port` and `serviceWeb.port` are client-facing Service ports.
`containerPorts.dns` changes the Pi-hole FTL DNS listener.
`containerPorts.http` is the primary unencrypted web listener targeted by the
Web Service, HTTP probes, and metrics exporter. For multiple IPv4, IPv6, HTTP,
or HTTPS listeners, set `pihole.webserverPort` to the complete FTL value and
include `containerPorts.http` as a directly served HTTP listener bound to all
pod interfaces. Do not add `r` or `s` to that primary listener or bind it to a
specific address; Service probes and the metrics exporter require direct HTTP.
Redirect, TLS, and address-specific listeners may be added separately. For
example:

```yaml
containerPorts:
  http: 9090
pihole:
  webserverPort: "9090o,[::]:9090o,9091os,[::]:9091os"
```

The chart Web Service and default NetworkPolicy expose only
`containerPorts.http`; additional FTL listeners such as HTTPS 9091 are not
routed through that Service. With `hostNetwork`, reach them directly through
the node and enforce access with the node firewall. For ordinary pod
networking, terminate TLS at an Ingress or Gateway that targets the primary
HTTP listener.

DHCP remains on protocol-defined UDP port 67.

### Security and Resources

| Key | Default | Description |
|-----|---------|-------------|
| `resources` | requests `100m/128Mi`, limits `500m/512Mi` | CPU and memory resources for the Pi-hole container |
| `podSecurityContext.seccompProfile.type` | `RuntimeDefault` | Enables the Kubernetes default seccomp profile |
| `securityContext.allowPrivilegeEscalation` | `false` | Prevents privilege escalation while preserving required Pi-hole capabilities |
| `securityContext.capabilities.add` | image runtime set | Capabilities required for image setup, privilege drop, FTL file capabilities, DNS binding, and shutdown |
| `serviceAccount.automountServiceAccountToken` | `false` | Keeps Kubernetes API tokens out of the pod unless explicitly needed |
| `networkPolicy.enabled` | `true` | Restrict ingress to declared Pi-hole pod ports |
| `networkPolicy.ingressFrom` | `[]` | Optional source peers; empty allows LAN and cluster clients |

NetworkPolicy enforcement for `dhcp.hostNetwork: true` depends on the cluster
network plugin. Verify host-network policy behavior and use node-level controls
when the Pi-hole listeners must be restricted.

### Ingress

| Key | Default | Description |
|-----|---------|-------------|
| `ingress.enabled` | `false` | Enable ingress |
| `ingress.ingressClassName` | `""` | Ingress class (traefik, nginx, etc.) |
| `ingress.hosts` | `[]` | Ingress hosts and paths |
| `ingress.tls` | `[]` | TLS configuration |

### Metrics

| Key | Default | Description |
|-----|---------|-------------|
| `metrics.enabled` | `false` | Enable pihole-exporter sidecar |
| `metrics.image.tag` | `v1.2.0` | pihole-exporter version |
| `metrics.port` | `9617` | Metrics port |
| `metrics.resources` | requests `25m/64Mi`, limits `100m/128Mi` | Resources for the pihole-exporter sidecar |
| `metrics.serviceMonitor.enabled` | `false` | Create ServiceMonitor |
| `metrics.serviceMonitor.interval` | `30s` | Scrape interval |

### Backup

| Key | Default | Description |
|-----|---------|-------------|
| `backup.enabled` | `false` | Enable scheduled S3-compatible backups |
| `backup.schedule` | `0 3 * * *` | Backup CronJob schedule |
| `backup.include.gravity` | `true` | Include the gravity database |
| `backup.include.customDns` | `true` | Include custom DNS records |
| `backup.include.dnsmasq` | `true` | Include dnsmasq configuration |
| `backup.resources` | requests `50m/64Mi`, limits `250m/256Mi` | Resources for backup and upload containers |
| `backup.s3.endpoint` | `""` | S3-compatible endpoint URL |
| `backup.s3.bucket` | `""` | Target bucket name |
| `backup.s3.existingSecret` | `""` | Existing Secret with `access-key` and `secret-key` |

### Unbound

| Key | Default | Description |
|-----|---------|-------------|
| `unbound.enabled` | `false` | Enable Unbound sidecar |
| `unbound.image.tag` | `1.22.0` | Unbound version |
| `unbound.port` | `5335` | Unbound listening port |
| `unbound.resources` | requests `50m/64Mi`, limits `200m/128Mi` | Resources for Unbound |

### DHCP

| Key | Default | Description |
|-----|---------|-------------|
| `dhcp.enabled` | `false` | Enable the Pi-hole DHCP server and expose UDP 67 |
| `dhcp.hostNetwork` | `false` | Use host network for DHCP |
| `dhcp.start` | `""` | First IPv4 address in the lease range (required when enabled) |
| `dhcp.end` | `""` | Last IPv4 address in the lease range (required when enabled) |
| `dhcp.router` | `""` | Router address advertised to clients (required when enabled) |
| `dhcp.leaseTime` | `24h` | Lease duration accepted by Pi-hole FTL |

### Scheduling

| Key | Default | Description |
|-----|---------|-------------|
| `nodeSelector` | `{}` | Node selector |
| `tolerations` | `[]` | Tolerations |
| `affinity` | `{}` | Affinity rules |
| `topologySpreadConstraints` | `[]` | Topology spread |
| `priorityClassName` | `""` | Priority class |
| `terminationGracePeriodSeconds` | `30` | Shutdown grace period |

## Resources Generated

| Resource | Condition | Description |
|----------|-----------|-------------|
| Deployment | Always | Pi-hole server (single replica, Recreate strategy) |
| Service (DNS) | Always | DNS ports TCP/UDP 53 (LoadBalancer by default) |
| Service (Web) | Always | Web admin port 80 (ClusterIP by default) |
| PersistentVolumeClaim | `persistence.enabled` | Pi-hole data volume |
| Secret | No `admin.existingSecret` | Admin password |
| ConfigMap | Custom DNS/dnsmasq config | DNS records and dnsmasq config |
| Ingress | `ingress.enabled` | Web admin ingress |
| ServiceAccount | `serviceAccount.create` | Dedicated SA |
| ServiceMonitor | `metrics.serviceMonitor.enabled` | Prometheus scrape config |

## Examples

- [Simple](examples/simple.yaml) — minimal deployment with fixed DNS IP
- [Production](examples/production.yaml) — Unbound, ingress, metrics, custom DNS
- [Custom DNS](examples/custom-dns.yaml) — local DNS records and conditional forwarding

## Architecture Guides

- [Design rationale](DESIGN.md) — scope, security, production boundaries, and known gaps
- [Unbound Recursive DNS](docs/unbound.md) — privacy-focused recursive DNS resolution
- [Operations guide](docs/operations.md) — backup, upgrades, runtime verification, and troubleshooting

## Upgrade Notes

### Upgrading to 2026.10.0

Pi-hole 2026.10.0 includes FTL 6.8, Web 6.6.1, Core 6.5, and fixes for
17 published security advisories. The Docker release also prevents Secret-backed
web passwords from appearing in shell traces and makes FTL and release downloads
fail closed. Back up the persistent data and verify DNS, admin login, gravity
updates, and any enabled Unbound or DHCP workflow after rollout.

Chart 2.2.0 changed `securityContext.capabilities` to drop all capabilities
before adding the complete set required by the official image. Helm replaces
custom arrays during an upgrade, so a `securityContext.capabilities.add`
override copied from chart 2.1.x removes the new required defaults and prevents
Pi-hole from starting. Inspect stored overrides with `helm get values <release>
-n <namespace>`, remove the old capability override, then upgrade with
`--reset-values` and pass the other intended overrides again. Do not use
`--reuse-values` or `--reset-then-reuse-values` for this migration because both
retain the stored capability override. When `dhcp.enabled` is true, the chart
now adds `NET_ADMIN` automatically.

Upstream release notes: [Pi-hole 2026.10.0](https://github.com/pi-hole/docker-pi-hole/releases/tag/2026.10.0).

### Upgrading to 2026.09.0

Pi-hole `2026.09.0` includes FTL 6.7.1 fixes for remote code execution,
arbitrary file reads, a stack overflow and configuration-validation bypasses.
The API and web interface can no longer change `misc.dnsmasq_lines` or
`webserver.advancedOpts`. Configure them in `pihole.toml`, through environment
variables, or with `pihole-FTL --config`. No chart-specific migration is
required, but back up `/etc/pihole` and `/etc/dnsmasq.d` before rollout.

## Connection

After installation, configure your network to use Pi-hole as DNS:

```bash
# Get DNS LoadBalancer IP
kubectl get svc <release>-pihole-dns -o jsonpath='{.status.loadBalancer.ingress[0].ip}'

# Get admin password
kubectl get secret <release>-pihole -o jsonpath='{.data.password}' | base64 -d

# Access web admin
kubectl port-forward svc/<release>-pihole-web 8080:80
# Then visit http://localhost:8080/admin
```

## Troubleshooting

For DNS, listener, gravity, Unbound, DHCP, backup, and recovery diagnostics, see
the [operations guide](docs/operations.md). Start with pod events and all
container logs, then verify the DNS Service EndpointSlice and both UDP and TCP
queries before changing the chart configuration.

## Non-Goals

This chart intentionally does not support:

- **Multi-instance clustering** — Pi-hole does not support clustering natively
- **Gravity Sync** — Use a separate tool or manual sync for multi-instance setups
- **Built-in VPN** — Use a dedicated VPN solution (WireGuard, etc.)
