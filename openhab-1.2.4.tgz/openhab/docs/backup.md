# Automated Backup

The openHAB chart includes an optional automated backup system that uses a Kubernetes CronJob to create compressed
archives of your openHAB data directories and upload them to any S3-compatible object storage.

## How It Works

The backup runs as a two-stage Kubernetes Job:

1. **Backup initContainer** (`alpine`) — runs `backup.sh`:
   - Creates a `.tar.gz` archive of selected directories into a shared `/tmp` volume
   - Excludes `userdata/logs`, `userdata/tmp`, and `userdata/cache` (ephemeral, not needed for restore)

2. **Upload container** (`helmforge/mc`) — runs `upload.sh`:
   - Picks up the archive from `/tmp`
   - Configures the MinIO client with your S3 credentials
   - Uploads the archive to `s3://<bucket>/<prefix>/<filename>`

Both containers run with the same UID/GID (9001) as openHAB, ensuring read
access to the PVCs. They drop all Linux capabilities, use read-only root
filesystems and disable privilege escalation. A dedicated ServiceAccount is
used so backup permissions remain separate from the openHAB workload.

> **Storage access mode:** The backup Job mounts the same PVCs as the openHAB
> StatefulSet. If the Job and StatefulSet can run on different nodes, those
> PVCs must support `ReadWriteMany` (RWX). With `ReadWriteOnce` (RWO), schedule
> the backup Job on the StatefulSet's node, or use a backup mechanism that does
> not require a simultaneous mount (for example, volume snapshots).

## Enabling Backup

```yaml
backup:
  enabled: true
  schedule: "0 3 * * *"  # Daily at 03:00 UTC

  s3:
    endpoint: "https://minio.example.com"
    bucket: "openhab-backups"
    prefix: "prod"
    accessKey: "AKIAEXAMPLE"
    secretKey: "supersecretkey"
```

## What Gets Backed Up

| Directory            | Default | Description                               |
|----------------------|---------|-------------------------------------------|
| `/openhab/userdata`  | Yes     | JSONDB, persistence data, rules state     |
| `/openhab/conf`      | Yes     | Items, things, sitemaps, rules files      |
| `/openhab/addons`    | No      | Drop-in JAR files                         |

**Always excluded from `userdata`:**

- `userdata/logs` — log files (not needed for restore)
- `userdata/tmp` — temporary files
- `userdata/cache` — OSGi bundle cache (rebuilt automatically on startup)

The CronJob does not explicitly include `/openhab/addons`. When addons shares a
claim with `userdata` or `conf`, incidental coverage depends on the configured
subpaths and must not be treated as a backup. Protect unreproducible JAR files
by snapshotting the entire PVC or using a path-aware archive that explicitly
includes the configured addons subpath.

### Backing Up Only Userdata

If you manage `/openhab/conf` via ConfigMaps (GitOps), you can skip it:

```yaml
backup:
  enabled: true
  include:
    userdata: true
    conf: false
```

## Using an Existing Secret

To avoid storing S3 credentials in your `values.yaml`, create a Secret manually and reference it:

```bash
kubectl create secret generic my-s3-credentials \
  --from-literal=access-key=AKIAEXAMPLE \
  --from-literal=secret-key=supersecretkey \
  -n openhab
```

```yaml
backup:
  enabled: true
  s3:
    endpoint: "https://minio.example.com"
    bucket: "openhab-backups"
    prefix: "prod"
    existingSecret: "my-s3-credentials"
```

## Using IRSA

The uploader can use ambient AWS credentials without creating or referencing a
static credential Secret. Configure the dedicated backup ServiceAccount and an
AWS region:

```yaml
backup:
  enabled: true
  serviceAccount:
    annotations:
      eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/openhab-backup
  s3:
    endpoint: "https://s3.amazonaws.com"
    bucket: "openhab-backups"
    prefix: "prod"
    region: "us-east-1"
    credentialsFromPodIdentity: true
```

Set `backup.serviceAccount.automountServiceAccountToken: true` only when your
identity integration explicitly requires the default Kubernetes API token;
IRSA normally receives its projected token from the EKS admission webhook.

## Using EKS Pod Identity

Keep `backup.s3.credentialsFromPodIdentity: true` and the same endpoint,
bucket, prefix, and region values shown above, but omit the ServiceAccount role
annotation. The cluster must run the EKS Pod Identity Agent add-on. Create the
association for the rendered backup ServiceAccount in its actual namespace.
For release `my-openhab`, the default name is `my-openhab-backup`:

```bash
aws eks create-pod-identity-association \
  --cluster-name <cluster-name> \
  --namespace <namespace> \
  --service-account my-openhab-backup \
  --role-arn <role-arn>
```

If `fullnameOverride` or `backup.serviceAccount.name` is set, use the
ServiceAccount name rendered by the chart instead.

## S3 Compatibility

The uploader uses the MinIO client (`mc`), which is compatible with any S3-compatible service:

| Provider        | Endpoint format                         |
|-----------------|-----------------------------------------|
| MinIO           | `https://minio.example.com`             |
| AWS S3          | `https://s3.amazonaws.com`              |
| Cloudflare R2   | `https://<account>.r2.cloudflarestorage.com` |
| Backblaze B2    | `https://s3.<region>.backblazeb2.com`   |
| DigitalOcean Spaces | `https://<region>.digitaloceanspaces.com` |

## Archive Naming

Archives follow this pattern:

```text
<archivePrefix>-backup-<YYYY-MM-DD-HHmmss>.tar.gz
```

Default example: `openhab-backup-2025-01-15-030000.tar.gz`

You can change the prefix:

```yaml
backup:
  archivePrefix: myhome
```

## Resource Limits

Backup containers use these resource requests and limits by default:

```yaml
backup:
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
    limits:
      cpu: 500m
      memory: 256Mi
```

## Suspending Backups

To temporarily pause backups without deleting the CronJob:

```yaml
backup:
  enabled: true
  suspend: true
```

## Viewing Backup History

```bash
# List recent backup jobs
kubectl get jobs -n openhab -l app.kubernetes.io/component=backup

# View logs from the latest backup run
kubectl logs -n openhab -l app.kubernetes.io/component=backup --tail=50

# Check job status
kubectl describe cronjob openhab-backup -n openhab
```

## Restore Process

To restore from a backup:

1. Download the archive from your S3 bucket
2. Scale down openHAB to 0 replicas (required — openHAB holds locks on its data):

```bash
kubectl scale statefulset openhab -n openhab --replicas=0
```

1. Extract the archive into the PVC via a temporary pod:

```bash
cat > restore-overrides.json <<'EOF'
{
  "spec": {
    "volumes": [
      {
        "name": "userdata",
        "persistentVolumeClaim": {
          "claimName": "openhab-userdata"
        }
      }
    ],
    "containers": [
      {
        "name": "restore",
        "image": "alpine",
        "command": ["sh"],
        "stdin": true,
        "tty": true,
        "volumeMounts": [
          {
            "name": "userdata",
            "mountPath": "/openhab/userdata"
          }
        ]
      }
    ]
  }
}
EOF

kubectl run restore --rm -it --image=alpine --restart=Never \
  --overrides="$(cat restore-overrides.json)" -- sh

# Inside the pod:
tar -xzf /path/to/openhab-backup-<timestamp>.tar.gz -C /
exit
```

1. Scale openHAB back to 1:

```bash
kubectl scale statefulset openhab -n openhab --replicas=1
```
